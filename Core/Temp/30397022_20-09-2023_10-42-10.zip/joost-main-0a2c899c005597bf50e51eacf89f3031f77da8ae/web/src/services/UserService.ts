import { Injector } from 'react-service-injector';
import { ApiService } from './ApiService';
import { User } from './TimeChimpService';

export interface BuzzyUser {
  email: string;
  displayName: string;
}

export class UserService {
  private readonly api: ApiService;

  constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  public getTimeChimpUsers(): Promise<User[]> {
    return this.api.jsonGet('/timechimp/hours/users?tag=Loondienst');
  }

  public getBuzzyUsers(): Promise<BuzzyUser[]> {
    return this.api.jsonGet('/users/buzzy');
  }
}
