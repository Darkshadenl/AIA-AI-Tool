import { Controller, Get, Param } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ApiTags } from '@nestjs/swagger';
import { AlpacaService, AlpacaItem, parseDate, AlpacaProject, AlpacaTask } from './alpaca.service';

@Controller('api/alpaca')
@Authenticated()
@ApiTags('Time Tracking')
export class AlpacaController {
  public constructor(private readonly alpaca: AlpacaService) {}

  @Get('projects')
  public getProjects(): Promise<AlpacaProject[]> {
    return this.alpaca.getProjects();
  }

  @Get('project/:project/tasks')
  public getTasks(@Param('project') project: number): Promise<AlpacaTask[]> {
    return this.alpaca.getProjectTasks([project]);
  }

  @Get('project/:project/:start/:end')
  public getWeek(
    @Param('project') project: number,
    @Param('start') start: string,
    @Param('end') end: string
  ): Promise<AlpacaItem[]> {
    const startDate = parseDate(start);
    const endDate = parseDate(end);
    return this.alpaca.getProjectItems([project], startDate, endDate);
  }
}
