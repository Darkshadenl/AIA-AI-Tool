import React, { ReactElement, ReactNode, useContext, useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { User } from '../services/TimeChimpService';
import { BuzzyUser, UserService } from '../services/UserService';

const Context = React.createContext<
  { authUser: AuthUser; timeChimpUsers: User[]; buzzyUsers: BuzzyUser[] } | undefined
>(undefined);

export interface AuthUser {
  email: string;
  firstName: string;
  lastName: string;
  picture: string;
  timeChimpId?: number;
  contractWorkWeekHours: number;
}

export function UserDataProvider({ children }: { children: ReactNode }): ReactElement | null {
  const [authUser, setAuthUser] = useState<AuthUser>();
  const [timeChimpUsers, setTimeChimpUsers] = useState<User[]>([]);
  const [buzzyUsers, setBuzzyUsers] = useState<BuzzyUser[]>([]);
  const users = useService(UserService);
  useEffect(() => {
    if (!authUser) {
      fetch('/auth/me')
        .then((r) => r.json())
        .then((result) => {
          if (result.error) {
            window.location.href =
              '/auth/login?redirect=' +
              encodeURIComponent(`${window.location.pathname}${window.location.search}${window.location.hash}`);
          } else {
            users.getTimeChimpUsers().then((newUsers) => {
              setTimeChimpUsers(newUsers.sort((a, b) => (a.displayName > b.displayName ? 1 : -1)));
              setAuthUser(result);
            });
            users.getBuzzyUsers().then((newUsers) => {
              setBuzzyUsers(newUsers.sort((a, b) => (a.displayName > b.displayName ? 1 : -1)));
            });
          }
        });
    }
  }, [authUser, timeChimpUsers, users]);

  if (!authUser || !users) {
    // TODO: fancy loading screen?
    return null;
  }

  return <Context.Provider value={{ authUser, timeChimpUsers, buzzyUsers }}>{children}</Context.Provider>;
}

export function useAuthUser(): AuthUser {
  const data = useContext(Context);
  if (!data) {
    throw new Error('Called useUserData from outside a UserDataProvider');
  }
  return data.authUser;
}

export function useUsers(): User[] {
  const data = useContext(Context);
  if (!data) {
    throw new Error('Called useUsers from outside a UserDataProvider');
  }
  return data.timeChimpUsers;
}

export function useUser(timeChimpId: number): User {
  // TODO catch if user is not in the list anymore
  const users = useUsers();
  const user = users.find((user) => user.id === timeChimpId);
  if (!user) {
    throw new Error(`Called useUser, but no matching user was found for id ${timeChimpId}`);
  }
  return user;
}

export function useTimeChimpUser(): User {
  const { timeChimpId } = useAuthUser();
  if (!timeChimpId) {
    throw new Error('Called useCurrentUser, but no TimeChimp was set');
  }
  return useUser(timeChimpId);
}

export function useBuzzyUser() {
  const { email } = useAuthUser();
  const data = useContext(Context);
  const buzzyUsers = data?.buzzyUsers || [];
  return buzzyUsers.find((b: { email: string }) => b.email.toLowerCase() === email.toLowerCase());
}
