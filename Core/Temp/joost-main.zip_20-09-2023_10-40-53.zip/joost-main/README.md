# Joost

## Prerequisites

* This project uses a pro license for the fontawesome icons (`@fortawesome/fontawesome-pro`). For this license a token is needed, this token can be found in the CI/CD settings in Gitlab. Copy the (contents of the) npmrc_file variable to a local `.npmrc`  file in de root van de repository.

## Installation

### Configuration

The server is configured using a set of variables. These are read from the environment, or from the file `server/.env`.
The  `server/.env.example` contains the required variables you need to specify. You can start by first copying it:
```shell
cp server/.env.example server/.env
```
And then provide values for the required variables within it:

| Variable                | Description                                                                                                                                                                                                                                                                                                         | Required | Default                   |
|:------------------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|---------------------------|
| TIMECHIMP_TOKEN         | Used to get data from TimeChimp such as declared hours, rides and expenses. Copy from the Joost environment file for enviroment _test [^1]. The source for the API key can be retrieved from https://app.timechimp.com/#/settings/preferences, but you need to be administrator (Beheerder) to generate an API key. | true     |                           |
| AZURE_AD_CLIENT_SECRET  | Click on Joost within <em>app-registrations</em>. Open <em>Owners</em>. Have an existing owner add you as owner. <em>Open Certificates & Secrets</em>. Add <em>new client secret</em>. Chose firstname_secret for the description, select an expires value and <em>add</em>. Then copy the <em>value</em>.          | true     |                           |
| AZURE_AD_INSTANCE_ID    | Copy from the Joost environment file for enviroment _test_[^1].                                                                                                                                                                                                                                                     | true     |                           |
| AUTH0_CLIENT_SECRET     | Used to get presence info from Buzzy. Copy from the Joost environment for environment _test_[^1].                                                                                                                                                                                                                   | true     |                           |
| GOOGLE_DISTANCE_API_KEY | Used to get the distances when creating mileages from the Google Distance API.                                                                                                                                                                                                                                      | false    |                           |
| MQTT_URL                | The url to connect to MQTT to get home assistent data used for the plants and climate.                                                                                                                                                                                                                              | false    | mqtt://joost.infi.nl:1883 |
| MQTT_USERNAME           | The username to connect to MQTT.                                                                                                                                                                                                                                                                                    | true     |                           |
| MQTT_PASSWORD           | The password to connect to MQTT.                                                                                                                                                                                                                                                                                    | true     |                           |

[^1]: Gitlab environment variables can be found at: <em>Gitlab</em>: <em>Settings > CI/CD > Variables > JOOST_ENVIRONMENT_FILE (for example for test)</em>. Press the <em>pencil</em> and copy the value. 

All other variables in this file are optional. Type typescript configuration options and environment variables can be found in `server/src/configuration.ts`.
The Slack token can be retrieved from: https://api.slack.com/apps/A02JZ4P1PS7/oauth.

### Setup with docker-compose
The easiest way to build and start is using docker-compose, so you don't have to prepare your local environment. Prerequisites:
* docker 24 or greater
* docker compose version 2.19 or greater

```shell
docker compose up -d
```

### Setup directly on your OS
Alternatively you can build and start directly on your OS. Prerequisites:
* node@18

Then build and start as follows:

```shell
# Install all dependencies.
yarn

# Build the projects.
yarn build

# Start the server and web app.
yarn start

# Run the linter and formatter.
yarn clean
```

## Running
The frontend runs on http://localhost:3000, and the backend runs on http://localhost:3001.