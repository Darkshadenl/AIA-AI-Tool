import { Module } from '@nestjs/common';
import { SlackService } from './slack.service';
import { ConfigService } from '@nestjs/config';

@Module({
  providers: [SlackService, ConfigService],
  exports: [SlackService],
})
export class SlackModule {}
