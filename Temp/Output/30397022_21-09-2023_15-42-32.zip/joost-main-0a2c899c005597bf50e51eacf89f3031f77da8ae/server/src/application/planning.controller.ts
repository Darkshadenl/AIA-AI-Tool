import { Controller, Get, Param, Post, Body, Query } from '@nestjs/common';
import { DateTime } from 'luxon';
import { PlanningService } from '~/domain';
import { BuzzyAdapter } from '~/infrastructure/buzzy';

@Controller('api/planning')
export class PlanningController {
  public constructor(private readonly service: PlanningService, private readonly buzzy: BuzzyAdapter) {}

  @Get('location/:location/:start/:end')
  public getLocationPlanning(
    @Param('location') location: string,
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('includeEvents') includeEvents?: boolean
  ) {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    return this.service.getLocationPlanning(location, startDate, endDate, includeEvents);
  }

  @Get('user/:email/:start/:end')
  public getUserPlanning(@Param('email') email: string, @Param('start') start: string, @Param('end') end: string) {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    return this.service.getUserPlanning(email, startDate, endDate);
  }

  @Post('/user/:email/:date')
  public postDayPlanning(
    @Param('email') email: string,
    @Param('date') date: string,
    @Body() { dayParts }: { dayParts: string[] }
  ) {
    return this.buzzy.setDayStatus(email, date, dayParts);
  }
}
