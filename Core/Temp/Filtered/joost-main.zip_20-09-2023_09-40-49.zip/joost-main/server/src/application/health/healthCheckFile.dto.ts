import { Expose } from 'class-transformer';

export class HealthCheckFileDto {
  @Expose()
  public id: string;

  @Expose()
  public name: string;

  @Expose()
  public date: string;
}
