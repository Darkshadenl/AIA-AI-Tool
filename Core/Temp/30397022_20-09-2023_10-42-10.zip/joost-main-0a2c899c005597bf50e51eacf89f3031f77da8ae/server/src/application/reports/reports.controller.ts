import { Controller, Get, Param, Query } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ApiTags } from '@nestjs/swagger';
import { ReportsService } from './reports.service';

@Authenticated()
@Controller('api/reports')
@ApiTags('Reports')
export class ReportsController {
  public constructor(private readonly reportService: ReportsService) {}

  @Get('mileage/range/:start/:end')
  public async generateMileageReport(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<Buffer> {
    return this.reportService.generateMileageReport(start, end, userId);
  }

  @Get('mileage/preview/range/:start/:end')
  public async generateMileagePreviewReport(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<Buffer> {
    return this.reportService.generateMileageReport(start, end, userId, true);
  }

  @Get('expense/range/:start/:end')
  public async generateExpenseReport(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<Buffer> {
    return this.reportService.generateExpenseReport(start, end, userId);
  }

  @Get('expense/preview/range/:start/:end')
  public async generateExpensePreviewReport(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<Buffer> {
    return this.reportService.generateExpenseReport(start, end, userId, true);
  }
}
