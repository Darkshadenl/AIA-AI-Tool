import { Result } from '../services/TimeChimpService';
import { ReactNode } from 'react';

const Currency = ({ children }: { children?: number }) => (
  <>
    {children?.toLocaleString('nl-NL', {
      style: 'currency',
      currency: 'EUR',
    }) || <i className="fas fa-spin fa-refresh" />}
  </>
);

export interface Props {
  results?: Result;
  title: ReactNode | undefined;
}

export const FinancialResults = ({ results, title }: Props) => (
  <>
    {title ? (
      <div className="financialPageTitle">
        <h2>{title}</h2>
      </div>
    ) : null}
    <div className="columns financialResults">
      <div className="column">
        <p className="heading">Revenue</p>
        <p className="title">
          <Currency>{results?.revenue}</Currency>
        </p>
      </div>
      <div className="column">
        <p className="heading">Costs</p>
        <p className="title">
          <Currency>{results?.costs}</Currency>
        </p>
      </div>
      <div className="column">
        <p className="heading">Margin</p>
        <p className="title">
          {results?.marginPercentage ? (
            `${results.marginPercentage.toFixed(1)} %`
          ) : (
            <i className="fas fa-spin fa-refresh" />
          )}
        </p>
      </div>
      <div className="column">
        <p className="heading">Hourly rate</p>
        <p className="title">
          <Currency>{results?.hourlyRate}</Currency>
        </p>
      </div>
    </div>
  </>
);
