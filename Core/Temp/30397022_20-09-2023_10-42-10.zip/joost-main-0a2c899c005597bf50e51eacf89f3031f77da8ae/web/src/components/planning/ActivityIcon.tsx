import React from 'react';

const icons: Record<string, string> = {
  available: 'chair-office',
  otherlocation: 'building-columns',
  extern: 'building',
  home: 'house',
  leave: 'umbrella-beach',
  sick: 'bed',
  unavailable: 'square-xmark',
};

interface Props {
  activity: string;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
  size?: 'small' | 'medium' | 'large' | '';
  classes?: string;
}

export const ActivityIcon = ({ activity, onClick, size = '', classes = '' }: Props) => {
  let sizeClass = '';

  if (size === 'small') {
    sizeClass = 'is-size-5';
  } else if (size === 'medium') {
    sizeClass = 'is-size-4';
  } else if (size === 'large') {
    sizeClass = 'is-size-3';
  }
  return <i onClick={onClick} className={`icon fa-regular fa-${icons[activity]}  ${sizeClass} ${classes}`}></i>;
};
