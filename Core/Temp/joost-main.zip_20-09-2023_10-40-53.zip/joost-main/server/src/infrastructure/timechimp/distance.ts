import { Expose } from 'class-transformer';

export class DistanceDto {
  @Expose()
  public text: string;
  @Expose()
  public value: string;
}

export class ElementDto {
  @Expose()
  public distance: DistanceDto;
  @Expose()
  public status: string;
}

export class RowDto {
  @Expose()
  public elements: ElementDto[];
}

export const NOT_FOUND = 'NOT_FOUND';

export class GoogleDistanceDto {
  @Expose()
  public destination_addresses: string[];
  @Expose()
  public origin_addresses: string[];
  @Expose()
  public rows: RowDto[];
  @Expose()
  public status: string;
}
