import { Expose } from 'class-transformer';

export class ResultDto {
  @Expose()
  public billableHours: number;

  @Expose()
  public revenue: number;

  @Expose()
  public costs: number;

  @Expose()
  public marginPercentage: number;

  @Expose()
  public hourlyRate: number;
}

export class ResultsDto {
  @Expose()
  public startDate: string;

  @Expose()
  public endDate: string;

  @Expose()
  public external: ResultDto;

  @Expose()
  public internal: ResultDto;

  @Expose()
  public total: ResultDto;
}
