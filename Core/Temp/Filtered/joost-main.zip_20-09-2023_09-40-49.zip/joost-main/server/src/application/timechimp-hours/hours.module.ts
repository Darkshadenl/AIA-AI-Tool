import { Module } from '@nestjs/common';
import { HoursController } from './hours.controller';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';

@Module({
  imports: [TimeChimpModule],
  controllers: [HoursController],
})
export class HoursModule {}
