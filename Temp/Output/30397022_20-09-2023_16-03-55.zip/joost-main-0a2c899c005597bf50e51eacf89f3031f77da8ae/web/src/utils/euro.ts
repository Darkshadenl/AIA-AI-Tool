export function formatEuro(euros: number): string {
  return Intl.NumberFormat('nl-NL', {
    style: 'currency',
    currency: 'EUR',
  }).format(euros);
}
