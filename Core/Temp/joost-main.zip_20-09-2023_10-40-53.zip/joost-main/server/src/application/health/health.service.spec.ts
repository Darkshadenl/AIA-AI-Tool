import { HealthService } from './health.service';

const healthService = new HealthService();

describe('HealthService', () => {
  describe('parseHealthCheck', () => {
    it('parses the csv data', () => {
      const content = `# 2022-10-21

            Participant,Stress,Comments: Stress,Fun,Comments: Fun
some.person@infi.nl,0,"Dit is stress",1,
another@infi.nl,1,,-1,"No fun :("
`;

      const result = healthService.parseHealthCheck(content);

      expect(result.dimensions).toStrictEqual(['Stress', 'Fun']);
      expect(result.entries).toStrictEqual([
        {
          participant: 'Some Person',
          dimensions: {
            Stress: {
              score: 1,
              comments: 'Dit is stress',
            },
            Fun: {
              score: 8,
              comments: '',
            },
          },
        },
        {
          participant: 'Another',
          dimensions: {
            Stress: {
              score: 8,
              comments: '',
            },
            Fun: {
              score: 0,
              comments: 'No fun :(',
            },
          },
        },
      ]);
      expect(result.healthPercentage).toBe(53);
      expect(result.scoreCounts).toStrictEqual({
        0: 1,
        1: 1,
        8: 2,
      });
    });

    it('leaves out a participant if they did not respond in any dimension', () => {
      const content = `# 2022-10-21

            Participant,Stress,Comments: Stress
some.person@infi.nl,0,
another@infi.nl,,
`;

      const result = healthService.parseHealthCheck(content);

      expect(result.entries).toStrictEqual([
        {
          participant: 'Some Person',
          dimensions: {
            Stress: {
              score: 1,
              comments: '',
            },
          },
        },
      ]);
    });
  });
});
