import {
  CallHandler,
  ExecutionContext,
  HttpException,
  InternalServerErrorException,
  Logger,
  NestInterceptor,
  StreamableFile,
} from '@nestjs/common';
import { instanceToInstance, instanceToPlain } from 'class-transformer';
import { catchError, map } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

export class TransformerInterceptor implements NestInterceptor {
  private static logger = new Logger(TransformerInterceptor.name);

  private static handleError(err: unknown): Observable<never> {
    if (err instanceof HttpException) {
      TransformerInterceptor.logger.error(`HTTP ${err.getStatus()}: ${err.message}`);
      return throwError(() => instanceToInstance(err));
    }

    if (err instanceof Error) {
      TransformerInterceptor.logger.error(err.stack);
      return throwError(() => new InternalServerErrorException(err.message));
    }

    TransformerInterceptor.logger.error(err);
    return throwError(() => instanceToPlain(err));
  }

  public intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    return next.handle().pipe(
      map((data: unknown): unknown => {
        if (data instanceof StreamableFile) {
          return data;
        }

        return instanceToPlain(data);
      }),
      catchError(TransformerInterceptor.handleError)
    );
  }
}
