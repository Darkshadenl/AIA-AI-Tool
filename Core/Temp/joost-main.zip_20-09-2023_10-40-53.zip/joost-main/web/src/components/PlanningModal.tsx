import React, { PropsWithChildren, useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { ModalContext } from '../pages/PlanningPage';
import { Planning, PlanningService } from '../services/PlanningService';
import { Modal, Props } from './Modal';
import { ActivityIcon } from './planning/ActivityIcon';
import { AppointmentList } from './planning/AppointmentList';
import { activityDescription } from './planning/UserPlanning';

export interface PlanningModalProps extends Props {
  content: Planning;
  loadingEvents: boolean;
  loadingSelectedUserEvents: boolean;
  updateParentEvent: () => void;
}

/**
 * Modal for showing the planning of a day. Uses the ModalContext (React.useContext) close the modal.
 * @param active boolean to show or hide the modal
 * @param content DayPlanning object with the planning for a day
 * @param updateParentEvent callback function to update the parent page
 * @param loadingEvents true until events are loaded
 * @param loadingSelectedUserEvents if all events are not loaded, bypass with loading of specific user events
 * @constructor
 */
export const PlanningModal = ({
  active,
  content,
  updateParentEvent,
  loadingEvents,
  loadingSelectedUserEvents,
}: PropsWithChildren<PlanningModalProps>) => {
  const { handleCloseModal } = React.useContext(ModalContext);
  const planningService = useService(PlanningService);
  const [dayState, setDayState] = useState({
    morning: '',
    afternoon: '',
  });

  useEffect(() => {
    setDayState({
      morning: content.dayParts[0],
      afternoon: content.dayParts[1],
    });
  }, [content]);

  const handleAnimations = (eventCurrentTarget: EventTarget & HTMLDivElement) => {
    eventCurrentTarget.classList.add('select_animation');
    setTimeout(() => {
      eventCurrentTarget.classList.remove('select_animation');
    }, 1000);
  };

  const updateDay = async ([morning, afternoon]: [string, string]) => {
    if (dayState) {
      const isoDate = content.date.toISODate();
      if (isoDate !== null) {
        await planningService.setDayStatus(content.email, isoDate, [morning, afternoon]);
        setDayState({ morning, afternoon });
      }
    }
    updateParentEvent();
  };

  return (
    <Modal onClose={() => handleCloseModal()} active={active}>
      {dayState && (
        <div className="modall">
          <div className="modalHeaderContainer bordered">
            <div className="modalHeader">
              <div className="weekday">{content.date.toLocaleString({ weekday: 'long' })}</div>
              <div>{content.date.toISODate()}</div>
            </div>
            <div className="modalSubHeader">
              {Object.entries(activityDescription).map(([activity, description]) => (
                <span key={activity} className={`${activity} activity`}>
                  <ActivityIcon activity={activity} />: {description}
                </span>
              ))}
            </div>
          </div>
          <div className="modalContentContainer">
            <div className="column">
              <div>
                <div className={'icon_header'}>
                  <span>Morning:</span>{' '}
                  <ActivityIcon size={'medium'} classes={dayState.morning} activity={dayState.morning} />
                </div>
                <div className={'icon_container'}>
                  {Object.entries(activityDescription).map(([activity, description]) => (
                    <span key={activity} className={`${activity}`}>
                      <ActivityIcon
                        size={'small'}
                        activity={activity}
                        onClick={(event) => {
                          updateDay([activity, dayState.afternoon]);
                          handleAnimations(event.currentTarget);
                        }}
                      />
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="column">
              <div>
                <div className={'icon_header'}>
                  <span>Afternoon:</span>{' '}
                  <ActivityIcon size={'medium'} classes={dayState.afternoon} activity={dayState.afternoon} />
                </div>
                <div className={'icon_container'}>
                  {Object.entries(activityDescription).map(([activity, description]) => (
                    <span key={activity} className={`${activity}`}>
                      <ActivityIcon
                        size={'small'}
                        activity={activity}
                        onClick={(event) => {
                          updateDay([dayState.morning, activity]);
                          handleAnimations(event.currentTarget);
                        }}
                      />
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="modalCalendarContainer">
            <div className="calendar">
              {loadingEvents && loadingSelectedUserEvents ? (
                <span className="loadingCalendar">Loading... </span>
              ) : (
                <AppointmentList appointments={content.events || []} />
              )}
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
};
