import React from 'react';
import { ModalContext } from '../../pages/PlanningPage';
import { Planning } from '../../services/PlanningService';
import { ActivityIcon } from './ActivityIcon';

interface Props {
  planning: Planning[];
  weekday: number;
  userName: string;
}

export const UserPlanningCell = ({ planning, weekday, userName }: Props) => {
  const { handleOpenModal } = React.useContext(ModalContext);
  return (
    <>
      {planning
        .filter((planning) => planning.weekday === weekday && planning.email === userName)
        .map((planning) => {
          let activity: React.JSX.Element;

          if (planning.dayParts[0] !== planning.dayParts[1]) {
            activity = (
              <>
                <span className={planning.dayParts[0]}>
                  <ActivityIcon activity={planning.dayParts[0]} />
                </span>{' '}
                /{' '}
                <span className={planning.dayParts[1]}>
                  <ActivityIcon activity={planning.dayParts[1]} />
                </span>
              </>
            );
          } else {
            activity = (
              <span className={planning.dayParts[0]}>
                <ActivityIcon activity={planning.dayParts[0]} />
              </span>
            );
          }

          return (
            <td
              key={weekday + '-' + userName}
              className={`row-${planning.dayParts[0]}-${planning.dayParts[1]}`}
              onClick={() => handleOpenModal(userName, weekday)}
            >
              <div className="activity">{activity}</div>
            </td>
          );
        })}
    </>
  );
};
