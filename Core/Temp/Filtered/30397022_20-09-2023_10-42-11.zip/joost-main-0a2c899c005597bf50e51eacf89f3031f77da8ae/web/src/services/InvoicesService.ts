import { Injector } from 'react-service-injector';
import { ApiService } from './ApiService';

interface CrossInvoiceHour {
  id: string;
  durationHours: number;
  startDateTimeStr: string;
  endDateTimeStr: string;
  employeeId: string;
  employeeName: string;
  customerId: string;
  customerName: string;
  projectName: string;
  rate: number;
  serviceId: string;
  serviceName: string;
  supplierId: string;
  typeId: string;
  typeLabel: string;
  supplierName: string;
  supplierMyOrganizationProfileId: string;
  isInvoiced: boolean;
  vendorId: string;
  vendorName: string;
}

interface CrossInvoiceServiceHours {
  name: string;
  totalAmount: number;
  totalDuration: number;
  hours: CrossInvoiceHour[];
}

interface CrossInvoiceProjectHours {
  name: string;
  totalAmount: number;
  totalDuration: number;
  services: CrossInvoiceServiceHours[];
}

export interface CrossInvoiceHours {
  vendorId: string;
  vendorName: string;
  supplierId: string;
  supplierName: string;
  supplierMyOrganizationProfileId: string;
  totalAmount: number;
  totalDuration: number;
  projects: CrossInvoiceProjectHours[];
}

interface CreateInvoiceLineDto {
  vat_class_id: string;
  revenue_group_id: string;
  date: string;
  description: string;
  amount: number;
  price: number;
}

export interface CreateInvoiceDto {
  payment_term_id: string;
  invoice_lines: CreateInvoiceLineDto[];
  status_id: string;
  my_organization_profile_id: string;
  organization_id: string;
  person_id?: string;
  date?: string;
  subject?: string;
  reference?: string;
  project_id?: string;
  comments?: string;
  sending_method: 'email';
}

export class InvoicesService {
  private readonly api: ApiService;

  constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  public getCrossInvoicesForMonth(year: number, month: number) {
    return this.api.jsonGet<{
      invoices: CreateInvoiceDto[];
      invoiced: CrossInvoiceHours[];
      uninvoiced: CrossInvoiceHours[];
    }>(`/hours/cross/invoices/${year}/${month}`);
  }

  public createCrossInvoices(year: number, month: number): Promise<void> {
    return this.api.jsonPost<Record<string, never>, void>(`/hours/cross/invoices/${year}/${month}`, {});
  }
}
