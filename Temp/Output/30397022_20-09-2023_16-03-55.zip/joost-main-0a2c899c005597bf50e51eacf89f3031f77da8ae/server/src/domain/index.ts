import { Module } from '@nestjs/common';
import { BuzzyModule } from '~/infrastructure/buzzy';
import { FilesModule } from '~/infrastructure/files';
import { OutlookModule } from '~/infrastructure/outlook';
import { HourFactory, HourService } from './hour';
import { PlanningService } from './planning';
import { UsersService } from './users.service';
import { TimeChimpModule } from '~/infrastructure/timechimp';

export * from './hour';
export * from './organization.entity';
export * from './planning';
export * from './user.entity';

@Module({
  imports: [FilesModule, BuzzyModule, OutlookModule, TimeChimpModule],
  providers: [HourFactory, HourService, UsersService, HourFactory, PlanningService],
  exports: [HourService, UsersService, PlanningService, HourFactory],
})
export class DomainModule {}
