import { ApiService } from './ApiService';
import { Injector } from 'react-service-injector';

export interface UpdateMileageStatus {
  registrationIds: number[];
  status: number;
}

export enum MileageType {
  Private = 1,
  Business = 2,
  Commute = 3, // Travel from home to work
}

export interface Mileage {
  id: number;
  userId: number;
  customerId: string;
  projectId: string;
  customerName: string;
  projectName: string;
  homeAddress: string;
  fromAddress: string;
  toAddress: string;
  date: Date;
  billable: boolean;
  distance: number;
  status: number;
  type: MileageType;
  notes: string;
}

export enum MileageStatus {
  open = 0,
  invoiced = 3,
}

export class MileageService {
  public static readonly NAME = 'MileageService';

  private readonly api: ApiService;

  public constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  public getMileage(start: string, end: string, userId?: number): Promise<Mileage[]> {
    return this.api.jsonGet(`/mileage/range/${start}/${end}`, { userId });
  }

  public async updateMileageStatuses(toUpdateMileages: UpdateMileageStatus) {
    return await this.api.jsonPost<UpdateMileageStatus, UpdateMileageStatus>('/mileage/status', toUpdateMileages);
  }

  public createMilages(
    mileage: Mileage,
    preview: boolean,
    createReturn: boolean,
    createCommute: boolean,
    homeAddress?: string
  ): Promise<Mileage[]> {
    const params = {
      preview: preview.toString(),
      return: createReturn.toString(),
      commute: createCommute.toString(),
      homeAddress: homeAddress ?? undefined,
    };
    return this.api.jsonPost<Mileage, Mileage[]>('/mileage', mileage, params);
  }

  public appliesToBusinessRules(m: Mileage) {
    return (
      (m.customerName.includes(`Infi Nijmegen`) && !m.billable) ||
      (!m.customerName.includes(`Infi Nijmegen`) && m.billable)
    );
  }
}
