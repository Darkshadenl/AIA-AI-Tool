import { Planning } from '../../services/PlanningService';
import { User } from '../../services/TimeChimpService';
import { ActivityIcon } from './ActivityIcon';
import { UserPlanningCell } from './UserPlanningCell';
import { v4 } from 'uuid';

interface Props {
  planning: Planning[];
  users: User[];
}

export const activityDescription: Record<string, string> = {
  available: 'kantoor',
  home: 'thuis',
  otherlocation: 'infi',
  extern: 'klant',
  leave: 'verlof',
  sick: 'ziek',
  unavailable: 'afwezig',
};

export const UserPlanning = ({ planning, users }: Props) => {
  return (
    <>
      <tbody>
        {users.map((user) => (
          <tr key={user.userName} className={`activity-row`}>
            <th>{user.displayName}</th>
            {Array(5)
              .fill(1)
              .map((_, index) => (
                <UserPlanningCell key={v4()} planning={planning} weekday={index + 1} userName={user.userName} />
              ))}
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <th align="right">Legend</th>
          <th colSpan={5}>
            {Object.entries(activityDescription).map(([activity, description]) => (
              <span key={activity} className={`legend  ${activity}`}>
                <ActivityIcon activity={activity} />: {description}
              </span>
            ))}
          </th>
        </tr>
      </tfoot>
    </>
  );
};
