import { DateTime } from 'luxon';
import { TaskDto } from '~/infrastructure/timechimp/timechimp.dto';
import { TimeDto } from '~/utils/time.dto';
import { FinanceService } from './finance.service';

describe('FinanceService', () => {
  describe('calculateResults', () => {
    it('should calculate results for small numbers', () => {
      const [startDate, endDate] = [DateTime.utc(2022, 10, 3), DateTime.utc(2022, 10, 10)];
      const [internalRevenue, externalRevenue, costs, internalBillableHours, externalBillableHours] = Array(5).fill(1);
      const expected = {
        startDate: '2022-10-03',
        endDate: '2022-10-10',
        internal: {
          revenue: 1,
          costs: 1,
          marginPercentage: 0,
          hourlyRate: 1,
          billableHours: 1,
        },
        external: {
          revenue: 1,
          costs: 1,
          marginPercentage: 0,
          hourlyRate: 1,
          billableHours: 1,
        },
        total: {
          revenue: 2,
          costs: 2,
          marginPercentage: 0,
          hourlyRate: 1,
          billableHours: 2,
        },
      };

      const actual = FinanceService.calculateResults(
        startDate,
        endDate,
        internalRevenue,
        externalRevenue,
        costs,
        internalBillableHours,
        externalBillableHours
      );

      expect(actual).toStrictEqual(expected);
    });

    it('should fail to calculate results for big integers', () => {
      const [startDate, endDate] = [DateTime.utc(2022, 9, 3), DateTime.utc(2022, 10, 3)];
      const [internalRevenue, externalRevenue, costs, internalBillableHours, externalBillableHours] = Array(5).fill(
        Number.MAX_VALUE
      );

      const expected = {
        startDate: '2022-09-03',
        endDate: '2022-10-03',
        internal: {
          revenue: Number.MAX_VALUE,
          costs: Number.MAX_VALUE,
          marginPercentage: 0,
          hourlyRate: 1,
          billableHours: Number.MAX_VALUE,
        },
        external: {
          revenue: Number.MAX_VALUE,
          costs: Number.MAX_VALUE,
          marginPercentage: 0,
          hourlyRate: 1,
          billableHours: Number.MAX_VALUE,
        },
        total: {
          revenue: Infinity,
          costs: Infinity,
          marginPercentage: NaN,
          hourlyRate: NaN,
          billableHours: Infinity,
        },
      };

      const actual = FinanceService.calculateResults(
        startDate,
        endDate,
        internalRevenue,
        externalRevenue,
        costs,
        internalBillableHours,
        externalBillableHours
      );

      expect(actual).toStrictEqual(expected);
    });
  });

  describe('calculateBillableHours', () => {
    const times: TimeDto[] = [
      {
        id: 1,
        customerId: 2,
        customerName: 'Infi Nijmegen B.V.',
        projectId: 4567,
        projectName: 'Intern',
        projectTaskId: 10987,
        taskId: 1,
        taskName: 'Overig',
        userId: 12345,
        userDisplayName: 'Pietje Puck',
        date: '2022-09-06T00:00:00',
        hours: 0.25,
        notes: 'inlezen styling',
        startEnd: '13:15-13:30    ',
        start: '2022-09-06T11:15:00',
        end: '2022-09-06T11:30:00',
        modified: '2022-09-06T15:06:48.367',
      },
      {
        id: 2,
        customerId: 5,
        customerName: 'Infi Utrecht B.V.',
        projectId: 7654,
        projectName: 'Project',
        projectTaskId: 456,
        taskId: 4,
        taskName: 'Development',
        userId: 69,
        userDisplayName: 'Devin Eloper',
        date: '2022-09-06T00:00:00',
        hours: 2.25,
        notes: 'issue x',
        startEnd: '13:15-13:30    ',
        start: '2022-09-06T11:15:00',
        end: '2022-09-06T11:30:00',
        modified: '2022-09-06T15:06:48.367',
      },
      {
        id: 3,
        customerId: 2,
        customerName: 'Infi Nijmegen B.V.',
        projectId: 1234,
        projectName: 'Office Management',
        projectTaskId: 4321,
        taskId: 5,
        taskName: 'Lichten ophangen',
        userId: 4,
        userDisplayName: 'Beun Haas',
        date: '2022-09-06T00:00:00',
        hours: 4,
        notes: 'Pakket openmaken',
        startEnd: '13:15-13:30    ',
        start: '2022-09-06T11:15:00',
        end: '2022-09-06T11:30:00',
        modified: '2022-09-06T15:06:48.367',
      },
      {
        id: 4,
        customerId: 2,
        customerName: 'Picobello B.V.',
        projectId: 1234,
        projectName: 'Development',
        projectTaskId: 4321,
        taskId: 3,
        taskName: 'Verbeteren procces',
        userId: 4,
        userDisplayName: 'Ron Twerp',
        date: '2022-09-06T00:00:00',
        hours: 4,
        notes: 'Was lastig',
        startEnd: '8:15-12:15    ',
        start: '2022-09-06T11:15:00',
        end: '2022-09-06T11:30:00',
        modified: '2022-09-06T15:06:48.367',
      },
    ];

    const tasks: TaskDto[] = [
      {
        id: 1,
        name: 'test',
        billable: false,
        hourlyRate: null,
      },
      {
        id: 2,
        name: 'test',
        billable: false,
        hourlyRate: null,
      },
      {
        id: 3,
        name: 'Testen app',
        billable: true,
        hourlyRate: null,
      },
      {
        id: 4,
        name: 'Bouwen issue X',
        billable: true,
        hourlyRate: null,
      },
      {
        id: 5,
        name: 'Lichten ophangen',
        billable: false,
        hourlyRate: null,
      },
    ];

    it('should combine tasks and times', () => {
      const actual = FinanceService.calculateBillableHours(times, tasks);
      expect(actual).toBe(6.25);
    });

    it('should work with a empty input on times', () => {
      const actual = FinanceService.calculateBillableHours([], tasks);
      expect(actual).toBe(0);
    });

    it('should work with a empty input on tasks', () => {
      const actual = FinanceService.calculateBillableHours(times, []);
      expect(actual).toBe(0);
    });
  });
});
