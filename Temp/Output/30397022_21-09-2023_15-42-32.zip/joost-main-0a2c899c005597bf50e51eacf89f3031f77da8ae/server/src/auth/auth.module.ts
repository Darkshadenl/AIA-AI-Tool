import { CACHE_MANAGER, CacheModule } from '@nestjs/cache-manager';
import { Logger, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportModule } from '@nestjs/passport';
import { Cache } from 'cache-manager';
import * as fsStore from 'cache-manager-fs-hash';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { AuthController } from './auth.controller';
import { Auth0Service } from './auth0.service';
import { AuthenticatedGuard } from './authenticated.guard';
import { LoginGuard } from './login.guard';
import { OICDStrategy, buildOpenIdClient } from './oidc.strategy';
import { StaticAuthentication } from './psk.guard';
import { SessionSerializer } from './session.serializer';

const OIDCStrategyFactory = {
  provide: 'OidcStrategy',
  useFactory: async (configService: ConfigService) => {
    const client = await buildOpenIdClient(configService);
    return new OICDStrategy(configService, client);
  },
  inject: [ConfigService],
};

const Auth0ServiceFactory = {
  provide: Auth0Service,
  useFactory: async (configService: ConfigService, cacheManager: Cache) => {
    return new Auth0Service(configService, new Logger(Auth0Service.name), cacheManager);
  },
  inject: [ConfigService, CACHE_MANAGER],
};

@Module({
  imports: [
    CacheModule.register({
      store: fsStore,
      options: {
        ttl: 23.5 * 60 * 60 * 1000, // Time to live in milliseconds (23.5 hours)
        max: 100,
        path: 'diskcache',
        zip: false,
        fillcallback: () => {
          console.log('cache miss');
        },
      },
    }),
    PassportModule.register({
      session: true,
      defaultStrategy: 'oicd',
    }),
    TimeChimpModule,
  ],
  providers: [
    StaticAuthentication,
    LoginGuard,
    AuthenticatedGuard,
    OIDCStrategyFactory,
    SessionSerializer,
    Auth0ServiceFactory,
  ],
  controllers: [AuthController],
  exports: [Auth0Service],
})
export class AuthModule {}
