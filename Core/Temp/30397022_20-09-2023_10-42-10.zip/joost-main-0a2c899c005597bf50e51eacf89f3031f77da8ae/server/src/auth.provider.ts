import { AuthenticationProvider } from '@microsoft/microsoft-graph-client';
import { User } from './auth/authenticated.request';

export class MSGraphAuthProvider implements AuthenticationProvider {
  private user: User;
  constructor(user: User) {
    this.user = user;
  }

  public getAccessToken(): Promise<string> {
    return Promise.resolve(this.user.accessToken);
  }
}
