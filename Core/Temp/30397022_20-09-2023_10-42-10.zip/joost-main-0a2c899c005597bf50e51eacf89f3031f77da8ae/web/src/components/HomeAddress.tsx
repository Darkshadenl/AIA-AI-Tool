import React from 'react';

export interface Props {
  setHomeAddress: (homeAddress: string) => void;
}

export const HomeAddress = ({ setHomeAddress }: Props) => {
  return (
    <div className="field">
      <label className="label">Home address</label>
      <div className="control">
        <input
          id="homeAddress"
          className="input"
          type="text"
          placeholder="Thuis adres?"
          onChange={(e) => setHomeAddress(e.target.value)}
        />
        <label htmlFor="homeAddress" />
      </div>
    </div>
  );
};
