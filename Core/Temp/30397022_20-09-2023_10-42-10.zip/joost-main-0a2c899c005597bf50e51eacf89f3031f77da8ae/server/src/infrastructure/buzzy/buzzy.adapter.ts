import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DateTime } from 'luxon';
import { Auth0Service } from '~/auth/auth0.service';
import { BuzzyConfig } from '~/configuration';
import { ApiOptions, buildQueryString } from '~/utils/ApiHelpers';

export interface UserDto {
  id: number;
  firstName: string;
  lastName: string;
  displayName: string;
  email: string;
  location: string;
}

interface UsersDto {
  users: UserDto[];
}

export interface BuzzyPlanningDto {
  email: string;
  location: string;
  year: number;
  week: number;
  weekday: number;
  date: string;
  planning: string;
}

@Injectable()
export class BuzzyAdapter {
  private readonly logger = new Logger(BuzzyAdapter.name);

  private readonly config: BuzzyConfig;

  public constructor(config: ConfigService, private readonly auth0Service: Auth0Service) {
    this.config = config.get('buzzy');
  }

  public async getUser(email: string) {
    return (await this.getUsers()).find((user) => user.email.toLowerCase() === email.toLowerCase());
  }

  public async getUsers() {
    return (await this.get<UsersDto>('/api/users')).users;
  }

  public async getUserPlanning(email: string, startDate: DateTime, endDate: DateTime) {
    const start = startDate.toISODate();
    const end = endDate.toISODate();

    return this.get<BuzzyPlanningDto[]>('/api/v2/planning/user', {
      queryParams: { email, start, end },
    });
  }

  public async getLocationPlanning(location: string, startDate: DateTime, endDate: DateTime) {
    const start = startDate.toISODate();
    const end = endDate.toISODate();

    return this.get<BuzzyPlanningDto[]>(`/api/v2/planning/location`, {
      queryParams: { location, start, end },
    });
  }

  public async getDayCounts(location: string, date: DateTime) {
    const planning = await this.getLocationPlanning(location, date.startOf('day'), date.endOf('day'));

    return planning.reduce(
      (day, plan) => {
        day[plan.planning] += 1;
        return day;
      },
      {
        available: 0,
        unavailable: 0,
        home: 0,
        extern: 0,
        leave: 0,
        sick: 0,
        otherlocation: 0,
      }
    );
  }

  private async get<T>(path: string, options: ApiOptions = {}): Promise<T> {
    const accessToken = await this.auth0Service.getAccessToken(this.config.url);

    const queryString = buildQueryString(options.queryParams);
    const url = `${this.config.url}${path}${queryString}`;
    this.logger.log(`GET: ${url}`);

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    const body = await response.json();

    if (response.status >= 400) {
      throw new Error(`Error response from Buzzy API (status ${response.status}):\n${JSON.stringify(body, null, 2)}`);
    }

    return body;
  }

  public async setDayStatus(email: string, dateStr: string, dayParts: string[]) {
    const date = DateTime.fromFormat(dateStr, 'yyyy-MM-dd', { locale: 'en' });
    const user = await this.getUser(email);
    const employeeId = user.id;
    const year = date.weekYear;
    const week = date.weekNumber;
    const day = date.weekdayLong.toLowerCase();
    const status = dayParts[0] !== dayParts[1] ? dayParts.join('-') : dayParts[0];
    const info = '';
    return this.post('/api/v2/setdaystatus', { year, week, employeeId, day, status, info });
  }

  private async post<T, S>(path: string, data: S, options: ApiOptions = {}): Promise<T> {
    const accessToken = await this.auth0Service.getAccessToken(this.config.url);

    const queryString = buildQueryString(options.queryParams);
    const url = `${this.config.url}${path}${queryString}`;
    this.logger.log(`GET: ${url}`);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    try {
      const body = await response.json();

      if (response.status >= 400) {
        throw new Error(`Error response from Buzzy API (status ${response.status}):\n${JSON.stringify(body, null, 2)}`);
      }

      return body;
    } catch (e) {
      this.logger.error(e.message, e.stack, { path, response });
      throw e;
    }
  }
}
