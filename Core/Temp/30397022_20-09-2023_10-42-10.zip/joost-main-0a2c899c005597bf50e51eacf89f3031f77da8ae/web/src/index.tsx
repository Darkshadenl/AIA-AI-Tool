import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { BrowserRouter } from 'react-router-dom';
import { Injector, InjectorProvider } from 'react-service-injector';

import './setupHighcharts';
import './index.scss';

const injector = new Injector();
const root = ReactDOM.createRoot(document.getElementById('root') as HTMLElement);
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <InjectorProvider value={injector}>
        <App />
      </InjectorProvider>
    </BrowserRouter>
  </React.StrictMode>
);
