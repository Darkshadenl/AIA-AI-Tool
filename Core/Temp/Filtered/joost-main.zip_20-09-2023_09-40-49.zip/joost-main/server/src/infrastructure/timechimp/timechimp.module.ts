import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { SlackModule } from '~/infrastructure/slack';
import { DistanceModule } from '~/application/distance/distance.module';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';

@Module({
  imports: [HttpModule, SlackModule, DistanceModule],
  providers: [TimeChimpAdapter],
  exports: [TimeChimpAdapter],
})
export class TimeChimpModule {}
