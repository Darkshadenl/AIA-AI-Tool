export type QueryParam = string | string[] | number | boolean | Date;

export type QueryParams = Record<string, QueryParam | undefined>;

export const buildQueryString = (queryParameters?: Record<string, QueryParam | undefined>): string => {
  let queryString = Object.entries(queryParameters || {})
    // remove undefined and false values
    .filter((pair): pair is [string, QueryParam] => {
      const param = pair[1];
      return param !== undefined && param !== false && !(Array.isArray(param) && param.length === 0);
    })
    .map(([key, value]) => {
      if (value === true) {
        // this is a flag
        return encodeURIComponent(key);
      }
      if (value instanceof Date) {
        return `${encodeURIComponent(key)}=${value.toISOString().slice(0, 10)}`;
      }
      if (Array.isArray(value)) {
        return value.map((v) => `${encodeURIComponent(key)}=${encodeURIComponent(v)}`).join('&');
      }
      return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
    })
    .join('&');

  if (queryString) {
    queryString = `?${queryString}`;
  }

  return queryString;
};

export interface ApiOptions {
  queryParams?: QueryParams;
}
