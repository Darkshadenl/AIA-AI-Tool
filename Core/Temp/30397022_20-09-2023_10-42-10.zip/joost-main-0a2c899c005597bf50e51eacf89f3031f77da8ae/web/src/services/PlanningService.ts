import { DateTime } from 'luxon';
import { Injector } from 'react-service-injector';
import { ApiService } from './ApiService';

export interface UserPlanning {
  email: string;
  year: number;
  week: number;
  monday: string;
  tuesday: string;
  wednesday: string;
  thursday: string;
  friday: string;
}

export interface PhysicalAddress {
  postalCode?: string;
  street?: string;
  city?: string;
}

export interface Assignment {
  id: string;
}

export interface Event {
  iCalUId: string;
  subject: string;
  startDateTime: DateTime;
  endDateTime: DateTime;
  body: string;
  freeBusy: 'unknown' | 'free' | 'tentative' | 'busy' | 'oof' | 'workingElsewhere';
  webLink: string;
  locationAddress: PhysicalAddress;
  locationName: string;
  organizerName: string;
  organizerEmail: string;
  isOof: boolean;
  duration: number;
}

type EventDto = Omit<Event, 'startDateTime' | 'endDateTime'> & {
  startDateTimeStr: string;
  endDateTimeStr: string;
};

export interface Hour {
  id: string;
  durationHours: number;
  startDateTime: DateTime;
  endDateTime: DateTime;
  employeeId: string;
  employeeName: string;
  customerId: string;
  customerName: string;
  projectName: string;
  rate: number;
  serviceId: string;
  serviceName: string;
  supplierId: string;
  supplierName: string;
  typeId: string;
  typeLabel: string;
  supplierMyOrganizationProfileId: string;
  isAbsence: boolean;
  isInvoiced: boolean;
  vendorId: string;
  vendorName: string;
}

type HourDto = Omit<Hour, 'startDateTime' | 'endDateTime'> & {
  startDateTimeStr: string;
  endDateTimeStr: string;
};

export interface Planning {
  id: string;
  date: DateTime;
  weekday: number;
  dayParts: [string, string];
  employer?: string;
  email: string;
  userName?: string;
  assignments?: Assignment[];
  hours?: Hour[];
  events?: Event[];
}

type PlanningDto = Omit<Planning, 'date' | 'events' | 'weekday' | 'hours'> & {
  dateStr: string;
  events: EventDto[];
  hours: HourDto[];
};

export class PlanningService {
  private readonly api: ApiService;

  constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  private fromEventDto({ startDateTimeStr, endDateTimeStr, ...rest }: EventDto): Event {
    return {
      startDateTime: DateTime.fromISO(startDateTimeStr),
      endDateTime: DateTime.fromISO(endDateTimeStr),
      ...rest,
    };
  }
  private fromHourDto({ startDateTimeStr, endDateTimeStr, ...rest }: HourDto): Hour {
    return {
      startDateTime: DateTime.fromISO(startDateTimeStr),
      endDateTime: DateTime.fromISO(endDateTimeStr),
      ...rest,
    };
  }

  private fromPlanningDto({ dateStr, events: eventsDto, hours: hoursDto, ...rest }: PlanningDto): Planning {
    const date = DateTime.fromISO(dateStr);
    const events = (eventsDto ?? []).map((e) => this.fromEventDto(e));
    const hours = (hoursDto ?? []).map((h) => this.fromHourDto(h));
    const weekday = date.weekday;
    return { ...rest, date, weekday, events, hours };
  }

  public async getLocationPlanning(
    location: string,
    start: string,
    end: string,
    includeEvents: boolean
  ): Promise<Planning[]> {
    return (
      await this.api.jsonGet<PlanningDto[]>(
        `/planning/location/${location}/${start}/${end}?includeEvents=${includeEvents}`
      )
    ).map((p) => this.fromPlanningDto(p));
  }

  public async getUserPlanning(email: string, start: string, end: string): Promise<Planning[]> {
    return (await this.api.jsonGet<PlanningDto[]>(`/planning/user/${email}/${start}/${end}`)).map((p) =>
      this.fromPlanningDto(p)
    );
  }

  public setDayStatus(email: string, date: string, dayParts: string[]): Promise<void> {
    return this.api.jsonPost<{ dayParts: string[] }, void>(`/planning/user/${email}/${date}`, { dayParts });
  }
}
