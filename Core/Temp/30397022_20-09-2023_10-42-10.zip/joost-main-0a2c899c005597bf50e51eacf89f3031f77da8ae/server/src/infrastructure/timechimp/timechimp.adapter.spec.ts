import { HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';
import { AxiosHeaders, AxiosResponse } from 'axios';
import { DateTime } from 'luxon';
import { Observable, of } from 'rxjs';
import { TimeChimpConfig } from '~/configuration';
import { TimeDto } from '~/utils/time.dto';
import { SlackService } from '~/infrastructure/slack';
import { ProjectDto, TaskDto, TimeChimpUserDto } from './timechimp.dto';
import { TimeChimpAdapter } from './timechimp.adapter';
import { DistanceService } from '~/application/distance/distance.service';

jest.mock('@nestjs/axios');

const httpService = new HttpService();
const getMock = jest.spyOn(httpService, 'get');

function getMockResponse<T>(data: T, status = 200, statusText = 'OK'): Observable<AxiosResponse> {
  return of({
    data,
    headers: {},
    config: { headers: new AxiosHeaders(), url: '' },
    status,
    statusText,
  });
}

describe('TimeChimpService', () => {
  let timeChimpService: TimeChimpAdapter;

  beforeEach(() => {
    const timeChimpConfig: TimeChimpConfig = {
      token: '',
      baseUrl: '',
      defaultUser: -42,
      absenceProject: 0,
      absenceTasks: [],
      infiTags: ['Nijmegen', 'Amsterdam', 'Utrecht'],
    };
    const config = new ConfigService({ timeChimp: timeChimpConfig, slack: { token: '1', webhook: '2' } });
    const slack = new SlackService(config);
    const distanceService = new DistanceService(config, httpService);
    timeChimpService = new TimeChimpAdapter(config, httpService, slack, distanceService);
  });

  describe('getUsers', () => {
    it('should return users', async () => {
      const data = [
        {
          id: 1,
          displayName: 'Corneel',
          tagNames: [],
        },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: Partial<TimeChimpUserDto>[] = data;

      const actual = await timeChimpService.getUsers();
      expect(actual).toEqual(expected);
    });
  });

  describe('getProjects', () => {
    it('should return projects', async () => {
      const data = [
        {
          id: 1,
          name: 'Joost',
          customerId: 1,
          customerName: 'Infi Nijmegen',
          hourlyRate: 0,
          projectTasks: [
            {
              id: 1,
              projectId: 1,
              taskId: -1,
              taskName: 'Intern',
              hourlyRate: null,
            },
          ],
          invoiceMethod: 2,
          tagNames: [],
        },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: ProjectDto[] = data;

      const actual = await timeChimpService.getProjects();
      expect(actual).toEqual(expected);
    });
  });

  describe('getTasks', () => {
    it('should return tasks', async () => {
      const data = [
        {
          id: 1,
          name: 'task 1',
          billable: true,
          hourlyRate: null,
        },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: TaskDto[] = data;

      const actual = await timeChimpService.getTasks();
      expect(actual).toEqual(expected);
    });
  });

  describe('getTimes', () => {
    it('should return items', async () => {
      const data = [
        {
          id: 42,
          customerId: 1,
          customerName: 'testklant',
          projectId: 1000,
          projectName: 'test project',
          projectTaskId: 100,
          taskId: -10,
          taskName: 'test taak',
          userId: -100,
          userDisplayName: 'test user',
          date: '2021-01-27T00:00:00',
          hours: 10,
          notes: 'test notes',
          startEnd: '20:00-20:45    ',
          start: '2021-09-27T18:00:00',
          end: '2021-09-27T18:45:00',
          modified: '2021-10-13T13:03:37.407',
        },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: TimeDto[] = data;

      const actual = await timeChimpService.getTimes({ startDate: DateTime.now(), endDate: DateTime.now() });
      expect(actual).toEqual(expected);
    });
  });
});
