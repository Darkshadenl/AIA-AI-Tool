import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { HomeassistantAdapter } from './homeassistant.adapter';
import { SlackModule } from '~/infrastructure/slack';
import { MqttModule } from '~/infrastructure/mqtt';

@Module({
  imports: [MqttModule, SlackModule],
  providers: [HomeassistantAdapter, ConfigService],
  exports: [HomeassistantAdapter],
})
export class HomeassistantModule {}
