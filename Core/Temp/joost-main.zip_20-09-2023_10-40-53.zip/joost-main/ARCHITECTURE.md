# ARCHITECTURE

## Server

Nestjs met domain driven design

3 lagen:

- Infrastructure
- Domain
- Application

### Infrastructure

Hierin zitten services die basis functionaliteit aanbieden aan de domain laag: denk bv aan een slack service en mqtt service

Hierin zitten ook modules die adapters implementere die koppelen met externe apis:

- Simplicate
- Buzzy
- Timechimp
- Outlook
- Homeassistant

Verder zitten er een aantal adapter is voor infrastructuur componenten

- Pdf
- Slack
- Files
- Mqtt

### Domain

#### Entiteiten & Aggregates

- user
- organization
- hour
- planning

Een entiteit is een domein entiteit die een relatie heeft met 1 van de onderliggende systemen. Bv een Hour kan geregistreerd zijn in simplicate of in timechimp.
Elke entiteit heeft factory methods om van een adapter dto een entiteit te maken.

Bv `HourEntity.fromSimplicate` en `HourEntity.fromTimeChimp`

Een aggregate is een domein entiteit die een relatie heeft met meerdere onderliggende systemen. Bv een Planning representeert de planning van een gebruiker op 1 dag. Hierin wordt informatie uit Buzzy, Simplicate (Assignments) en Outlook (Events en meetings) gecombineerd.

### Application

#### Cron
