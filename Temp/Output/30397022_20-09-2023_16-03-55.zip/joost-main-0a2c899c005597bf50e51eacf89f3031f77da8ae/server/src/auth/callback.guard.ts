import { ExecutionContext, Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class CallbackGuard extends AuthGuard('oidc') {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    try {
      const result = (await super.canActivate(context)) as boolean;
      const request = context.switchToHttp().getRequest();
      await super.logIn(request);
      return result;
    } catch (e) {
      console.error(e);
      const response = context.switchToHttp().getResponse();
      response.clearCookie('connect.sid');
    }
  }
}
