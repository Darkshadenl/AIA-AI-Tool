import { Logger, Module } from '@nestjs/common';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { AbsencesController } from './absences.controller';

@Module({
  imports: [TimeChimpModule],
  providers: [Logger],
  controllers: [AbsencesController],
})
export class AbsencesModule {}
