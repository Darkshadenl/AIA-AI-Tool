import { Module } from '@nestjs/common';
import { MSGraphAuthProvider } from '~/auth.provider';
import { OutlookAdapter } from './outlook.adapter';

@Module({
  providers: [OutlookAdapter, MSGraphAuthProvider],
  exports: [OutlookAdapter, MSGraphAuthProvider],
})
export class OutlookModule {}
