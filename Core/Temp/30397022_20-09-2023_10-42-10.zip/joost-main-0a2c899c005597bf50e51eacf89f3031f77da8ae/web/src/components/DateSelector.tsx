import React from 'react';

export interface Props {
  label?: string;
  startDate?: Date;
  setDateSelected: (date: Date) => void;
}

export const dateToString = (date: Date): string => {
  return `${date.getFullYear()}-${('0' + (date.getMonth() + 1)).slice(-2)}-${('0' + date.getDate()).slice(-2)}`;
};

export const DateSelector = ({ label, startDate, setDateSelected }: Props) => {
  let defaultDate = startDate;
  defaultDate ??= new Date();
  label ??= 'Date';
  return (
    <div className="field">
      <div className="control">
        <label className="label">{label}</label>
        <input
          type="date"
          className="input"
          defaultValue={dateToString(defaultDate)}
          onChange={(e) => setDateSelected(new Date(e.currentTarget.value))}
        />
      </div>
    </div>
  );
};
