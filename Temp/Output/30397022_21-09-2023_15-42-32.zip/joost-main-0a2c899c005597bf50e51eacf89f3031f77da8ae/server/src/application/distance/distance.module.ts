import { Module } from '@nestjs/common';
import { DistanceService } from '~/application/distance/distance.service';
import { HttpModule } from '@nestjs/axios';

@Module({
  imports: [HttpModule],
  providers: [DistanceService],
  exports: [DistanceService],
})
export class DistanceModule {}
