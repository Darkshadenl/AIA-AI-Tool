import { Customer } from '../services/TimeChimpService';

export interface Props {
  customers: Customer[];
  customerSelected?: Customer;
  setCustomerSelected: (customer: Customer) => void;
  label: string;
}

const hasAddress = (customer: Customer): boolean => {
  return customer.address != null && customer.city != null;
};

const getAddress = (customer: Customer): string => {
  return hasAddress(customer) ? customer.address + ' ' + customer.city : '';
};

export const CustomerSelector = ({ label, customers, customerSelected, setCustomerSelected }: Props) => {
  return (
    <div className="field">
      <label className="label">{label}</label>
      <div className="select">
        <select
          className="select"
          defaultValue={customerSelected?.id}
          onChange={(e) => {
            customers.filter((c) => c.id === parseInt(e.target.value)).map((c) => setCustomerSelected(c));
          }}
        >
          {customers
            .filter((c) => hasAddress(c))
            .map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({getAddress(c)})
              </option>
            ))}
        </select>
      </div>
    </div>
  );
};
