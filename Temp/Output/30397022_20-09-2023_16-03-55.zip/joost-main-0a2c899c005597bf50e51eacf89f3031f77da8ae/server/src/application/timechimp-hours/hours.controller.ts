import { Body, Controller, Delete, Get, HttpCode, Param, Post, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { DateTime } from 'luxon';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ProjectDto, TaskDto } from '~/infrastructure/timechimp';
import { TimeChimpUserDto } from '~/infrastructure/timechimp/timechimp.dto';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';
import { CreateTime, TimeDto } from '~/utils/time.dto';

@Authenticated()
@Controller('api/timechimp/hours')
@ApiTags('Time Tracking')
export class HoursController {
  public constructor(private readonly timeChimp: TimeChimpAdapter) {}

  @Get('users')
  public getUsers(@Query('tag') tag?: string): Promise<TimeChimpUserDto[]> {
    return this.timeChimp.getUsers().then((users) => users.filter((user) => !tag || user.tagNames.includes(tag)));
  }

  @Get('projects')
  public getProjects(): Promise<ProjectDto[]> {
    return this.timeChimp.getProjects();
  }

  @Get('projects/customer/:customerId')
  public getProjectsByCustomer(@Param('customerId') customerId: number): Promise<ProjectDto[]> {
    return this.timeChimp.getProjectsForCustomer({ customerId });
  }

  @Get('tasks')
  public getTasks(): Promise<TaskDto[]> {
    return this.timeChimp.getTasks();
  }

  @Get('week/:weekYear/:weekNumber')
  public getWeek(@Param('weekYear') weekYear: number, @Param('weekNumber') weekNumber: number): Promise<TimeDto[]> {
    const startDate = DateTime.fromObject({ weekYear, weekNumber }).startOf('week');
    const endDate = startDate.endOf('week');
    return this.timeChimp.getTimes({ startDate, endDate });
  }

  @Get('month/:year/:month')
  public getMonth(@Param('year') year: number, @Param('month') month: number): Promise<TimeDto[]> {
    const startDate = DateTime.fromObject({ year, month }).startOf('month');
    const endDate = startDate.endOf('month');
    return this.timeChimp.getTimes({ startDate, endDate });
  }

  @Get('/range/:start/:end')
  public getDateRange(@Param('start') start: string, @Param('end') end: string): Promise<TimeDto[]> {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    return this.timeChimp.getTimes({ startDate, endDate });
  }

  @Get('/:id/:start/:end')
  public getItems(
    @Param('id') id: number,
    @Param('start') start: string,
    @Param('end') end: string
  ): Promise<TimeDto[]> {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    return this.timeChimp.getTimesForProject({ id, startDate, endDate });
  }

  @Post('/time')
  public postItem(@Body() time: CreateTime): Promise<TimeDto> {
    return this.timeChimp.postTime(time);
  }

  @Delete('/time')
  @HttpCode(204)
  public deleteItem(@Body() { id }: { id: number }): Promise<void> {
    return this.timeChimp.deleteTime(id);
  }
}
