import { ApiService } from './ApiService';
import { Injector } from 'react-service-injector';

export interface Expense {
  id: number;
  userId: number;
  customerName: string;
  projectName: string;
  categoryName: string;
  date: Date;
  billable: boolean;
  rate: number;
  tax: number;
  status: number;
  attachment: string;
}

export interface UpdateExpenses {
  registrationIds: number[];
  status: number;
}

export interface ExpenseAndStatus {
  expense: Expense;
  needsCheck: boolean;
}

export enum expenseStatus {
  invoiced = 3,
}

export class ExpensesService {
  private readonly api: ApiService;

  public constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  public getExpenses(start: string, end: string, userId?: number): Promise<Expense[]> {
    return this.api.jsonGet(`/expenses/range/${start}/${end}`, { userId });
  }

  public async updateExpenses(toBeUpdatedExpenses: UpdateExpenses) {
    return await this.api.jsonPost<UpdateExpenses, UpdateExpenses>('/expenses/updateExpenses', toBeUpdatedExpenses);
  }

  public confomsToBusinessRules(expense: Expense) {
    const customerName = expense.customerName;
    const billable = expense.billable;
    const tax = expense.tax;

    if (customerName.includes('Infi Nijmegen B.V.') && billable) return false;
    if (customerName.includes('Infi Nijmegen B.V.') && tax !== 0) return false;
    if (customerName !== 'Infi Nijmegen B.V.' && !billable) return false;
    return true;
  }

  public generateWarningText(expense: Expense) {
    const customerName = expense.customerName;
    const billable = expense.billable;
    const tax = expense.tax;

    if (customerName.includes('Infi Nijmegen B.V.') && billable) return 'Check billability';
    if (customerName.includes('Infi Nijmegen B.V.') && tax !== 0) return 'Check VAT percentage';
    if (customerName !== 'Infi Nijmegen B.V.' && !billable) return 'Check billability';
    return '';
  }
}
