import { Controller, Get, Param, Req } from '@nestjs/common';
import { UsersService } from '~/domain/users.service';
import { Authenticated } from '~/auth/authenticated.decorator';
import { AuthenticatedRequest } from '~/auth/authenticated.request';
import { BuzzyAdapter } from '~/infrastructure/buzzy';

@Authenticated()
@Controller('api/users')
export class UsersController {
  constructor(private readonly service: UsersService, private readonly buzzy: BuzzyAdapter) {}

  @Get()
  async findAll() {
    return this.service.findAll();
  }

  @Get('/self')
  async findSelf(@Req() request: AuthenticatedRequest) {
    return this.service.find(request.user.email.toLocaleLowerCase());
  }

  @Get('buzzy')
  async findBuzzy() {
    return this.buzzy.getUsers();
  }

  @Get(':email')
  async find(@Param('email') email: string) {
    return this.service.find(email);
  }
}
