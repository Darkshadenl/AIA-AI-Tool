import { DateTime } from 'luxon';
import { useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { CreateInvoiceDto, CrossInvoiceHours, InvoicesService } from '../services/InvoicesService';

type Period = 'month' | 'week';

function nowWithOffset(period: Period, offset: number) {
  const now = DateTime.now();
  switch (period) {
    case 'month':
      return now.plus({
        month: offset,
      });
    case 'week':
      return now.plus({
        week: offset,
      });
  }
}

function describePeriod(period: Period, offset: number) {
  const then = nowWithOffset(period, offset);
  switch (period) {
    case 'month':
      return then.toFormat('MMMM');
    case 'week':
      return `Week ${then.weekNumber}`;
  }
}

export const InvoicesPage = () => {
  const invoicesService = useService(InvoicesService);
  const [period] = useState<Period>('month');

  const [offset, setOffset] = useState(0);
  const [invoiced, setInvoicedHours] = useState<CrossInvoiceHours[]>();
  const [uninvoiced, setUninvoicedHours] = useState<CrossInvoiceHours[]>();
  const [invoices, setInvoices] = useState<CreateInvoiceDto[]>();

  useEffect(() => {
    (async () => {
      setInvoicedHours([]);
      setUninvoicedHours([]);
      setInvoices([]);
      const date = nowWithOffset(period, offset);
      const { invoiced, uninvoiced, invoices } = await invoicesService.getCrossInvoicesForMonth(date.year, date.month);
      setInvoicedHours(invoiced);
      setUninvoicedHours(uninvoiced);
      setInvoices(invoices);
    })();
  }, [period, offset, invoicesService]);

  const createInvoices = async () => {
    const date = nowWithOffset(period, offset);
    await invoicesService.createCrossInvoices(date.year, date.month);
  };

  return (
    <>
      <div className="columns">
        <div className="column">
          <h1>Invoices</h1>
        </div>
      </div>
      <div>
        <div className="columns">
          <div className="column">
            <div className="field">
              <label className="label">{describePeriod(period, offset)}</label>
              <div className="buttons">
                <button className="button is-square" onClick={() => setOffset(offset - 1)}>
                  <i className="fas fa-arrow-left" />
                </button>
                <button className="button  is-square" disabled={offset === 0} onClick={() => setOffset(offset + 1)}>
                  <i className="fas fa-arrow-right" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <h2>Cross invoices</h2>
        {invoices && (
          <>
            {invoices.map((invoice) => (
              <>
                <h3>{invoice.subject}</h3>
                <table>
                  <thead>
                    <tr>
                      <th>Datum</th>
                      <th>Customer</th>
                      <th>Project</th>
                      <th>Dienst</th>
                      <th>Type</th>
                      <th>Medewerker</th>
                      <th>Tijd</th>
                      <th>Tarief</th>
                      <th>Bedrag</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoiced
                      ?.filter(
                        (hours) =>
                          hours.supplierMyOrganizationProfileId === invoice.my_organization_profile_id &&
                          hours.vendorId === invoice.organization_id
                      )
                      .flatMap((hours) => hours.projects.flatMap((project) => project.services.flatMap((s) => s.hours)))
                      .map((hour) => (
                        <tr key={hour.id}>
                          <td>{DateTime.fromISO(hour.startDateTimeStr).toFormat('yyyy-MM-dd')}</td>
                          <td>{hour.customerName}</td>
                          <td>{hour.projectName}</td>
                          <td>{hour.serviceName}</td>
                          <td>{hour.typeLabel}</td>
                          <td>{hour.employeeName}</td>
                          <td>{hour.durationHours}</td>
                          <td>{hour.rate}</td>
                          <td>{hour.durationHours * hour.rate}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </>
            ))}
            <button className="button submit-button mx-1" onClick={createInvoices}>
              Create
            </button>
          </>
        )}
        {uninvoiced && (
          <>
            <h3>Uninvoiced</h3>
            <table>
              <thead>
                <tr>
                  <th>Datum</th>
                  <th>Customer</th>
                  <th>Project</th>
                  <th>Dienst</th>
                  <th>Type</th>
                  <th>Medewerker</th>
                  <th>Tijd</th>
                  <th>Tarief</th>
                  <th>Bedrag</th>
                </tr>
              </thead>
              <tbody>
                {uninvoiced
                  ?.flatMap((hours) => hours.projects)
                  ?.flatMap((project) => project.services)
                  ?.flatMap((s) => s.hours)
                  .map((hour) => (
                    <tr key={hour.id}>
                      <td>{DateTime.fromISO(hour.startDateTimeStr).toFormat('yyyy-MM-dd')}</td>
                      <td>{hour.customerName}</td>
                      <td>{hour.projectName}</td>
                      <td>{hour.serviceName}</td>
                      <td>{hour.typeLabel}</td>
                      <td>{hour.employeeName}</td>
                      <td>{hour.durationHours}</td>
                      <td>{hour.rate}</td>
                      <td>{hour.durationHours * hour.rate}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </>
        )}
      </div>
    </>
  );
};
