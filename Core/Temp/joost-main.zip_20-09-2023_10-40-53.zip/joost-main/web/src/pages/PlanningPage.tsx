import { DateTime } from 'luxon';
import React, { useEffect, useMemo, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useService } from 'react-service-injector';
import { ActivityPlanning } from '../components/planning/ActivityPlanning';
import { UserPlanning } from '../components/planning/UserPlanning';
import { useUsers } from '../hooks/useUserData';
import { Planning, PlanningService } from '../services/PlanningService';
import { classNames } from '../utils/classNames';
import { PlanningModal } from '../components/PlanningModal';

interface Props {
  view: 'users' | 'activities';
}

export const PlanningPage = ({ view }: Props) => {
  const users = useUsers();
  const [planning, setPlanning] = useState<Planning[]>([]);
  const planningService = useService(PlanningService);
  const [date, setDate] = useState(DateTime.now());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({} as Planning);
  const [loadingEvents, setLoadingEvents] = useState(true);
  const [loadingSelectedUserEvents, setLoadingSelectedUserEvents] = useState(true);
  const [selectedUsername, setSelectedUsername] = useState<string | null>(null);
  const [reload, setReload] = useState(false);

  const modalHandles = useMemo(() => {
    const handleOpenModal = async (username?: string, weekday?: number) => {
      if (username && weekday && planning.length > 0) {
        setSelectedUsername(username);
        let allUsersPlanningData = planning;

        if (loadingEvents) {
          const start = date.startOf('week').toISODate();
          const end = date.endOf('week').toISODate();
          if (start && end) {
            allUsersPlanningData = await planningService.getUserPlanning(username, start, end);
            setLoadingSelectedUserEvents(false);
          }
        }
        const userPlanningData = allUsersPlanningData.find((p) => p.email === username && p.weekday === weekday);
        if (userPlanningData) {
          setModalContent(userPlanningData);
        } else {
          setModalContent({} as Planning);
        }
      }

      setIsModalOpen(true);
    };

    const handleCloseModal = () => {
      setIsModalOpen(false);
      setLoadingSelectedUserEvents(true);
    };

    return { handleOpenModal, handleCloseModal };
  }, [date, loadingEvents, planning, planningService]);

  useEffect(() => {
    if (isModalOpen && !loadingEvents) {
      const relevantData = planning.find((p) => p.email === selectedUsername && p.weekday === modalContent.weekday);
      if (relevantData) {
        setModalContent(relevantData);
      }
    }
  }, [isModalOpen, loadingEvents, modalContent.weekday, planning, selectedUsername]);

  useEffect(() => {
    const start = date.startOf('week').toISODate();
    const end = date.endOf('week').toISODate();
    let active = true;

    if (start && end) {
      planningService.getLocationPlanning('nijmegen', start, end, false).then((result) => {
        if (active) {
          setPlanning(result);
        }
      });
      setLoadingEvents(true);
      planningService.getLocationPlanning('nijmegen', start, end, true).then((planning) => {
        if (active) {
          setPlanning(planning);
          setLoadingEvents(false);
        }
      });
    }

    return () => {
      active = false;
    };
  }, [planningService, date, reload]);

  const start = date.startOf('week');

  return (
    <>
      <div className="columns subtitle">
        <div className="column planning-title">
          <h1>Planning</h1>
        </div>
      </div>
      <div className="planning-page">
        <div className="columns">
          <div className="column is-narrow">
            <div className="field week-buttons">
              <label className="label">Week {date.weekNumber}</label>
              <div className="buttons">
                <button className="button is-square" onClick={() => setDate(date.minus({ week: 1 }))}>
                  <i className="fas fa-arrow-left" />
                </button>
                <button className="button  is-square" onClick={() => setDate(date.plus({ week: 1 }))}>
                  <i className="fas fa-arrow-right" />
                </button>
              </div>
            </div>
          </div>

          <div className="column">
            <div className="field current-week">
              <label className="label">&nbsp;</label>
              <button
                className="button is-square is-link"
                onClick={() => setDate(DateTime.now())}
                disabled={date.startOf('week').toString() === DateTime.now().startOf('week').toString()}
              >
                Go to current week
              </button>
            </div>
          </div>

          <div className="column column-last">
            <div className="field">
              <label className="label">Sort</label>
              <div className="buttons has-addons">
                <NavLink className={classNames('button', view === 'users' && 'is-link')} to="/team/planning">
                  Users
                </NavLink>
                <NavLink className={classNames('button', view === 'activities' && 'is-link')} to="/office/planning">
                  Activities
                </NavLink>
              </div>
            </div>
          </div>
        </div>
        <div className="table-container">
          <ModalContext.Provider value={modalHandles}>
            {isModalOpen && (
              <PlanningModal
                active={isModalOpen}
                content={modalContent}
                updateParentEvent={() => setReload(!reload)}
                loadingEvents={loadingEvents}
                loadingSelectedUserEvents={loadingSelectedUserEvents}
              ></PlanningModal>
            )}
            <table className={`table ${view === 'users' && 'is-striped'}`}>
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <h2 className="day-long">Monday</h2>
                    <h2 className="day-short">Mon</h2>
                    <div className="date-long">{start.toFormat('yyyy-MM-dd')}</div>
                    <div className="date-short">{start.toFormat('MM-dd')}</div>
                  </th>
                  <th>
                    <h2 className="day-long">Tuesday</h2>
                    <h2 className="day-short">Tue</h2>
                    <div className="date-long">{start.plus({ days: 1 }).toFormat('yyyy-MM-dd')}</div>
                    <div className="date-short">{start.plus({ days: 1 }).toFormat('MM-dd')}</div>
                  </th>
                  <th>
                    <h2 className="day-long">Wednesday</h2>
                    <h2 className="day-short">Wed</h2>
                    <div className="date-long">{start.plus({ days: 2 }).toFormat('yyyy-MM-dd')}</div>
                    <div className="date-short">{start.plus({ days: 2 }).toFormat('MM-dd')}</div>
                  </th>
                  <th>
                    <h2 className="day-long">Thursday</h2>
                    <h2 className="day-short">Thur</h2>
                    <div className="date-long">{start.plus({ days: 3 }).toFormat('yyyy-MM-dd')}</div>
                    <div className="date-short">{start.plus({ days: 3 }).toFormat('MM-dd')}</div>
                  </th>
                  <th>
                    <h2 className="day-long">Friday</h2>
                    <h2 className="day-short">Fri</h2>
                    <div className="date-long">{start.plus({ days: 4 }).toFormat('yyyy-MM-dd')}</div>
                    <div className="date-short">{start.plus({ days: 4 }).toFormat('MM-dd')}</div>
                  </th>
                </tr>
              </thead>
              {view === 'activities' ? (
                <ActivityPlanning planning={planning} users={users} />
              ) : (
                <UserPlanning planning={planning} users={users} />
              )}
              <tfoot></tfoot>
            </table>
          </ModalContext.Provider>
        </div>
      </div>
    </>
  );
};

type ModalContextType = {
  handleOpenModal: (username?: string, weekday?: number) => void;
  handleCloseModal: () => void;
};

export const ModalContext = React.createContext<ModalContextType>({
  handleOpenModal: (username?: string, weekday?: number) => {
    console.warn('handleOpenModal function is not implemented');
  },
  handleCloseModal: () => {
    console.warn('handleCloseModal function is not implemented');
  },
});
