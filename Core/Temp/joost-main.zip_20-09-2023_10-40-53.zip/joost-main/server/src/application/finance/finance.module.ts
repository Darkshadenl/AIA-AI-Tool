import { Logger, Module } from '@nestjs/common';
import { FinanceController } from './finance.controller';
import { FinanceService } from './finance.service';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { SlackModule } from '~/infrastructure/slack/slack.module';

@Module({
  imports: [TimeChimpModule, SlackModule],
  controllers: [FinanceController],
  providers: [Logger, FinanceService],
  exports: [FinanceService],
})
export class FinanceModule {}
