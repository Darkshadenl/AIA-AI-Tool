export class Assignment {
  public id: string;
}
