import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Auth0Config } from '~/configuration';
import { DateTime } from 'luxon';
import { Cache } from 'cache-manager';

interface AccessTokenData {
  accessToken: string;
  expiryTime: DateTime;
}

@Injectable()
export class Auth0Service {
  private readonly config: Auth0Config;
  private accessToken: string;
  private expiryTime: DateTime;

  public constructor(config: ConfigService, private readonly logger: Logger, private cacheManager: Cache) {
    this.config = config.get('auth0');
  }

  public async getAccessToken(audience: string): Promise<string> {
    if (!this.accessToken) {
      const v = await this.cacheManager.get<AccessTokenData>('accessTokenData');
      this.accessToken = v?.accessToken;
      this.expiryTime = DateTime.fromISO(v?.expiryTime.toString());
    }

    if (this.accessToken && DateTime.now() < this.expiryTime) {
      return this.accessToken;
    }
    const tokenData = await this.getAccessTokenFromApi(audience);

    const { access_token, expires_in } = tokenData;

    this.expiryTime = DateTime.now().plus({ seconds: (expires_in ?? 60) - 60 });
    this.accessToken = access_token ?? '';
    await this.cacheManager.set('accessTokenData', { accessToken: this.accessToken, expiryTime: this.expiryTime });

    return this.accessToken;
  }

  private async getAccessTokenFromApi(audience: string) {
    this.logger.debug(`Refreshing access token from ${this.config.url}`);

    try {
      const url = `${this.config.url}/oauth/token`;
      const tokenResponse = await fetch(`${url}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          audience,
          grant_type: 'client_credentials',
          client_id: this.config.clientId,
          client_secret: this.config.clientSecret,
        }),
      });
      const { access_token, expires_in } = await tokenResponse.json();
      return { access_token, expires_in };
    } catch (error) {
      this.logger.error(`Error fetching token: ${error}`);
    }
  }
}
