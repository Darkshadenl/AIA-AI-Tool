import { useUser } from '../hooks/useUserData';
import { AbsenceDto } from '../services/AbsencesService';
import { Planning, Event } from '../services/PlanningService';
import { formatDateLong } from '../utils/date';

export interface Props {
  absence: AbsenceDto;
  planning?: Planning;
  outlook?: Event[];
}

function capitalizeFirstLetter(string: string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

export const AbsenceCard = ({ absence, planning, outlook }: Props) => {
  const user = useUser(absence.userId);
  // Oof = Out-of-Office
  const outlookOofDuration = outlook?.filter((o) => o.isOof).reduce((a, o) => o.duration + a, 0) || 0;
  const absenceDuration = absence.times.reduce((total, time) => total + time.hours, 0);

  const className = !planning
    ? 'error'
    : (planning.dayParts.includes('leave') || planning.dayParts.includes('unavailable')) &&
      outlookOofDuration === absenceDuration
    ? 'ok'
    : 'warning';

  return (
    <div className="absence-card">
      <div className={`box absence-card-${className}`}>
        <div className="columns">
          <div className="column">
            <div className="has-text-weight-bold">{formatDateLong(absence.startDate)}</div>
            <div>{user.displayName}</div>
          </div>
          <div className="column">
            <div>
              <i className={`icon fa-regular fa-clock`}></i>
              {absence.taskName}
            </div>
            <div>
              <i className={`icon fa-regular fa-bee`}></i>

              {planning &&
                '(' +
                  capitalizeFirstLetter(
                    planning.dayParts[0] +
                      (planning.dayParts[0] !== planning.dayParts[1]
                        ? '-' + capitalizeFirstLetter(planning.dayParts[1])
                        : '') +
                      ')'
                  )}
            </div>
            <div>
              <i className={`icon fa-regular fa-calendar`}></i>
              {outlook && outlook.length > 0 && outlook[0].subject}
            </div>
          </div>
          <div className="column">
            <div>
              <span className="hours">{absenceDuration}</span>
            </div>
          </div>
          <div className="column is-one-third outlook">
            {outlook &&
              outlook
                .sort((a, b) => a.startDateTime.diff(b.startDateTime).seconds)
                .map((outlook, index) => (
                  <div key={index}>
                    <div>
                      {outlook.startDateTime && outlook.startDateTime.toFormat('HH:mm')}-
                      {outlook.endDateTime && outlook.endDateTime.toFormat('HH:mm')}
                      <span>{outlook.subject}</span>
                    </div>
                  </div>
                ))}
            <div className="pt-2">
              (absence in outlook: <span className="hours">{outlookOofDuration} hrs</span>)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
