import { PhysicalAddress } from './address.valueObject';
import { CustomerDto } from '~/infrastructure/timechimp';

export interface Organization {
  id: string;
  name: string;
  physicalAddress: PhysicalAddress;
}

export class OrganizationEntity implements Organization {
  public id: string;
  public name: string;
  public physicalAddress: PhysicalAddress;

  private constructor({ id, name, physicalAddress }: Organization) {
    this.id = id;
    this.name = name;
    this.physicalAddress = physicalAddress;
  }

  public static fromTimeChimp(c: CustomerDto) {
    const { id, name, address, postalCode, city, country } = c;
    return new OrganizationEntity({
      id: `timeChimp/${id}`,
      name,
      physicalAddress: { street: address, postalCode, city, country },
    });
  }
}
