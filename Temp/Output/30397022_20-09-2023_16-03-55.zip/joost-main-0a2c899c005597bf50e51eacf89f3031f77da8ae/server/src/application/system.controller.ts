import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';

class PingDto {
  public ping: boolean;
  public version: string;
}

@Controller('api/system')
@ApiTags('Debug')
export class SystemController {
  public constructor(private readonly config: ConfigService) {}

  @Get('ping')
  public ping(): PingDto {
    const result = new PingDto();
    result.ping = true;
    result.version = this.config.get<string>('server.version');
    return result;
  }
}
