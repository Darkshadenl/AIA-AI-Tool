export async function batchPromises<T>(fns: (() => Promise<T>)[], parallel: number): Promise<T[]> {
  // Fail-safe to make sure the function works when there are no elements to await.
  if (fns.length === 0) {
    return [];
  }

  return new Promise((resolve, reject) => {
    const results: T[] = [];
    let resolved = 0;
    let current = 0;

    async function next() {
      const index = current++;

      if (index >= fns.length) {
        return;
      }

      try {
        results[index] = await fns[index]();
      } catch (e) {
        reject(e);
        return;
      }

      resolved++;
      if (resolved === fns.length) {
        resolve(results);
      }

      next();
    }

    for (let i = 0; i < parallel && i < fns.length; i++) {
      next();
    }
  });
}
