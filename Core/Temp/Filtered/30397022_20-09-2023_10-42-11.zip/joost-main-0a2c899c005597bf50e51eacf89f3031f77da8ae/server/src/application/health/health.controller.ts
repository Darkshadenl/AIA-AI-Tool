import { Controller, Get, Param } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiTags } from '@nestjs/swagger';
import { FilesService } from '~/infrastructure/files';
import { Authenticated } from '~/auth/authenticated.decorator';
import { HealthChecksConfig } from '~/configuration';
import { batchPromises } from '~/utils/batchPromises';
import { HealthService } from './health.service';
import { HealthCheckDto } from './healthCheck.dto';
import { HealthCheckFileDto } from './healthCheckFile.dto';

@Authenticated()
@Controller('api/health')
@ApiTags('Health')
export class HealthController {
  private readonly config: HealthChecksConfig;

  public constructor(
    config: ConfigService,
    private readonly healthService: HealthService,
    private readonly fileService: FilesService
  ) {
    this.config = config.get('healthChecks');
  }

  @Get('/checks')
  public async listHealthChecks(): Promise<HealthCheckFileDto[]> {
    const files = await this.fileService.listChildrenByPath(this.config.folder);
    return files
      .map((f) => {
        const newFile = new HealthCheckFileDto();
        newFile.id = f.id;
        newFile.name = f.name;
        newFile.date = f.name.substring(0, 10);
        return newFile;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }

  @Get('/checks/:id')
  public async getHealthCheck(@Param('id') id: string): Promise<HealthCheckDto> {
    const file = await this.fileService.getFileContentsString(id);
    return this.healthService.parseHealthCheck(file);
  }

  @Get('/all')
  public async getAllHealthChecks(): Promise<HealthCheckDto[]> {
    const files = await this.listHealthChecks();
    return batchPromises(
      files.map((f) => async () => {
        const content = await this.fileService.getFileContentsString(f.id);
        const parsedHealthCheck = this.healthService.parseHealthCheck(content);
        parsedHealthCheck.date = f.date;
        return parsedHealthCheck;
      }),
      2
    );
  }
}
