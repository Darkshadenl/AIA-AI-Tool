# Entities

- Vendor: de Organization die de Hours in rekening brengt
- Supplier: de Organization waar de medewerker voor brengt die de Hours heeft uitgevoerd
- Customer: de Organization waar de Invoice voor de Hours naartoe gestuurd wordt
- Organization: rechtspersoon of natuurlijke persoon waar we Invoices naartoe sturen
- Hour: een tijdsregistratie voor een uitgevoerd taak/activiteit
- Invoice: een rekening die betaald moet worden.
- User: ??
- Employer: de Organization waar de medewerker voor werkt
- Person: een persoon
