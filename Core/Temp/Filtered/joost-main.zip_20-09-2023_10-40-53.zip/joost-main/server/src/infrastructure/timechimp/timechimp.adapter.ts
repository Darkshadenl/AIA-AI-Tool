import { HttpService } from '@nestjs/axios';
import { Injectable, Logger, NotFoundException, Scope } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClassConstructor, plainToInstance } from 'class-transformer';
import { DateTime } from 'luxon';
import { firstValueFrom } from 'rxjs';
import { UpdateExpenses } from 'web/src/services/ExpensesService';
import { ExpenseDto, UpdateExpenseStatus } from '~/application/expenses/expense.dto';
import { Mileage, MileageDto, MileageType, UpdateMileageStatus } from '~/application/mileage/mileage.dto';
import { TimeChimpConfig } from '~/configuration';
import { ApiOptions, buildQueryString } from '~/utils/ApiHelpers';
import { memoizePromiseFn } from '~/utils/memoizePromise';
import { CreateTime, TimeDto } from '~/utils/time.dto';
import { SlackService } from '../slack/slack.service';
import { CustomerDto, ProjectDto, TaskDto, TimeChimpUserDto } from './timechimp.dto';
import { DistanceService } from '~/application/distance/distance.service';

const sum = (items: number[]): number => {
  return items.reduce((a, i) => a + i, 0);
};

const groupBy = (items: TimeDto[], grouper: (item: TimeDto) => number) =>
  items.reduce((accu, item) => {
    const group = grouper(item);
    if (!accu[group]) {
      accu[group] = [];
    }
    accu[group].push(item);

    return accu;
  }, {} as Record<number, TimeDto[]>);

@Injectable({ scope: Scope.REQUEST })
export class TimeChimpAdapter {
  public readonly config: TimeChimpConfig;

  private readonly logger: Logger = new Logger(TimeChimpAdapter.name);

  public constructor(
    config: ConfigService,
    private readonly httpClient: HttpService,
    private readonly slackService: SlackService,
    private readonly distanceService: DistanceService
  ) {
    this.config = config.get('timeChimp');
  }

  public getUsers = memoizePromiseFn<TimeChimpUserDto[], []>(() => this.get(TimeChimpUserDto, '/v1/users'));
  public getUser = memoizePromiseFn<TimeChimpUserDto, [number]>(async (userId: number) => {
    const user = await this.get<TimeChimpUserDto>(TimeChimpUserDto, `/v1/users/${userId}`);
    return user;
  });

  public getProjects = memoizePromiseFn<ProjectDto[], []>(() => this.get(ProjectDto, '/v1/projects'));

  public async getProject(projectId: number) {
    const projects = await this.getProjects();
    return projects.find((project) => project.id === projectId);
  }

  public getTasks = memoizePromiseFn<TaskDto[], []>(() => this.get(TaskDto, '/v1/tasks'));

  public async getTask(taskId: number) {
    const tasks = await this.getTasks();
    return tasks.find((task) => task.id === taskId);
  }

  public getInfis = memoizePromiseFn<Record<string, CustomerDto>, []>(async () => {
    const customers = await this.getCustomers();
    return this.config.infiTags.reduce<Record<string, CustomerDto>>(
      (accu, tag) => ({
        [tag]: customers.find((customer) => customer.tagNames.includes(tag) && customer.tagNames.includes('Infi')),
        ...accu,
      }),
      {}
    );
  });

  public async getCustomer(customerId: number) {
    const customers = await this.getCustomers();
    return customers.find((customer) => customer.id === customerId);
  }

  public getProjectsForCustomer(queryParams: { customerId: number }): Promise<ProjectDto[]> {
    return this.get(ProjectDto, `/v1/projects/customer/${queryParams.customerId}`);
  }

  private async getProjectForCustomer(customerName: string, projectName: string): Promise<ProjectDto> {
    const projects = await this.getProjects();
    return projects.find((p) => p.customerName === customerName && p.name === projectName);
  }

  async getInfiCustomers() {
    const customers = await this.getCustomers(false);
    const infiCustomers = customers.filter((c) => c.name.includes('Infi'));
    if (infiCustomers.length === 0) {
      throw new NotFoundException('No projects found for tag Infi');
    }
    return infiCustomers;
  }

  public getTimesForProject(queryParams: { id: number; startDate: DateTime; endDate: DateTime }): Promise<TimeDto[]> {
    const id = queryParams.id;
    const startDate = queryParams.startDate.toISO().slice(0, 10);
    const endDate = queryParams.endDate.toISO().slice(0, 10);
    return this.get(TimeDto, `/v1/time/project/${id}/${startDate}/${endDate}`);
  }

  public getTimes(queryParams: { startDate: DateTime; endDate: DateTime }): Promise<TimeDto[]> {
    const startDate = queryParams.startDate.toISO().slice(0, 10);
    const endDate = queryParams.endDate.toISO().slice(0, 10);
    return this.get(TimeDto, `/v1/time/daterange/${startDate}/${endDate}`);
  }

  public async getAbsences(queryParams: {
    userId?: number;
    startDate: DateTime;
    endDate: DateTime;
  }): Promise<TimeDto[]> {
    const { userId, startDate, endDate } = queryParams;
    const id = this.config.absenceProject;

    const times = await this.getTimesForProject({ id, startDate, endDate });
    const timesByUser = times.filter((a) => Number.isNaN(userId) || a.userId === userId);
    return timesByUser.filter((time) => this.config.absenceTasks.includes(time.taskName));
  }

  public async getBookedHoursByUserId(queryParams: {
    startDate: DateTime;
    endDate: DateTime;
  }): Promise<Record<number, number>> {
    const { startDate, endDate } = queryParams;

    const times = await this.getTimes({
      startDate,
      endDate,
    });

    const timesByUserId = groupBy(times, (time: TimeDto) => time.userId);

    const hoursByUserId = Object.entries(timesByUserId).reduce((accu, [id, items]) => {
      accu[id] = sum(items.map((items) => items.hours));
      return accu;
    }, {} as Record<number, number>);

    return hoursByUserId;
  }

  public postTime(time: CreateTime): Promise<TimeDto> {
    return this.post(TimeDto, `/v1/time`, time);
  }

  public deleteTime(id: number): Promise<void> {
    return this.delete(undefined, `/v1/time`, undefined, { queryParams: { id } });
  }

  public getExpenses(queryParams: { startDate: DateTime; endDate: DateTime }): Promise<ExpenseDto[]> {
    const startDate = queryParams.startDate.toISO().slice(0, 10);
    const endDate = queryParams.endDate.toISO().slice(0, 10);
    return this.get(ExpenseDto, `/v1/expenses/daterange/${startDate}/${endDate}`);
  }

  public updateExpensesStatus(expense: UpdateExpenses): Promise<UpdateExpenseStatus> {
    return this.post(ExpenseDto, `/v1/expenses/changestatusintern`, expense);
  }

  public getMileage(queryParams: { startDate: DateTime; endDate: DateTime }): Promise<MileageDto[]> {
    const startDate = queryParams.startDate.toISO().slice(0, 10);
    const endDate = queryParams.endDate.toISO().slice(0, 10);
    return this.get(MileageDto, `/v1/mileage/daterange/${startDate}/${endDate}`);
  }

  /**
   * Creates mileages on basis of the mileage provided. The homeAddress is used for commute purposes. The <i>from</i> and <i>to</i> addresses are used for business travel.
   * <p> For example the following addresses: homeAddress = example addres 1, from address = example address 2, to address = example address 3 resolves into:
   * <ul>
   *     <li>Mileage 1: From: example address 1. To: example address 2</li>
   *     <li>Mileage 2: From: example address 2. To: example address 3</li>
   * </li>
   * </ul>
   * And when createReturn is true, then also:
   * <ul>
   *     <li>Mileage 3: From: example address 2. To: example address 1</li>
   *     <li>Mileage 4: From: example address 3. To: example address 2</li>
   * </li>
   * </ul></p>
   * Currently for commute travel customer <i>Infi Nijmegen</i> with project <i>Intern</i> is added, so this only works for the Nijmegen branch of Infi.
   *
   * @param mileage The mileage on basis of which the mileages are created.
   * @param createReturn Whether a return mileage should be created for each mileage, which has an opposite from and to address.
   * @param createCommute Whether commuter traffic mileages should be created, from home to from address.
   * @param preview When true not mileages are created, when false actually creates mileages.
   * @param homeAddress The home address from which commute mileages are created.
   * @throws ValidationException When the home address is not valid and could not be found.
   */
  public async createMileages(
    mileage: Mileage,
    createReturn: boolean,
    createCommute: boolean,
    preview: boolean,
    homeAddress: string = undefined
  ): Promise<Mileage[]> {
    let mileages: Mileage[] = [mileage];
    mileage.distance = await this.distanceService.getDistanceInKm(mileage.fromAddress, mileage.toAddress);
    if (createCommute && homeAddress) {
      this.logger.log('Creating commute mileages');
      const project = await this.getProjectForCustomer('Infi Nijmegen B.V.', 'Intern');
      const commute = await this.createCommute(mileage, project, homeAddress);
      commute.distance = await this.distanceService.getDistanceInKm(commute.fromAddress, commute.toAddress);
      await mileages.push(commute);
    }
    if (createReturn) {
      this.logger.log('Creating return mileages');
      mileages = mileages.concat(mileages.map((m) => this.createReturn(m)));
    }

    if (!preview) {
      this.logger.log(`Performing creation of ${mileages.length} mileages`);
      const mileagesCreated = [];
      mileages.forEach((m) => {
        this.logger.log('Performing mileage creation ' + JSON.stringify(m, null, 2));
        mileagesCreated.push(this.post(MileageDto, '/v1/mileage', m));
      });
      return Promise.all(mileagesCreated);
    }
    return mileages;
  }

  private async createCommute(mileage: Mileage, project: ProjectDto, homeAddress: string): Promise<Mileage> {
    const commuteMileage = structuredClone(mileage);
    commuteMileage.fromAddress = homeAddress;
    commuteMileage.projectId = project.id;
    commuteMileage.billable = false;
    commuteMileage.type = MileageType.Commute;
    commuteMileage.distance;
    return commuteMileage;
  }

  private createReturn(mileage: Mileage): Mileage {
    const returnMileage = structuredClone(mileage);
    returnMileage.fromAddress = mileage.toAddress;
    returnMileage.toAddress = mileage.fromAddress;
    return returnMileage;
  }

  public updateMileageStatus(mileage: UpdateMileageStatus): Promise<UpdateMileageStatus> {
    return this.post(MileageDto, `/v1/mileage/changestatusintern`, mileage);
  }

  public async getCustomers(withProjectsOnly = false): Promise<CustomerDto[]> {
    let customers = await this.get<CustomerDto[]>(CustomerDto, '/v1/customers');
    if (withProjectsOnly) {
      const projects = await this.getProjects();
      const projectIdsWithCustomer: number[] = projects.map((p) => p.customerId);
      customers = customers.filter((c) => projectIdsWithCustomer.includes(c.id) === true);
    }
    return customers;
  }

  public async checkDailyWorkedHours(): Promise<void> {
    const timeChimpUsers = await this.getUsers().then((users) =>
      users.filter((user) => user.tagNames.includes('Loondienst'))
    );

    const now = DateTime.now();

    const previousWorkingDay = now.minus({ days: now.weekday === 1 ? 3 : 1 });

    const hoursByUserId = await this.getBookedHoursByUserId({
      startDate: previousWorkingDay.startOf('day'),
      endDate: previousWorkingDay.endOf('day'),
    });

    const responses = timeChimpUsers.map(async (timeChimpUser) => {
      this.logger.debug(`Found ${hoursByUserId[timeChimpUser.id]} hours for user id ${timeChimpUser.id}`);

      const message = this.getHoursMessage(hoursByUserId[timeChimpUser.id], previousWorkingDay);

      if (message) {
        await this.slackService.sendToUserByName(timeChimpUser.displayName, message);
      }
    });

    await Promise.all(responses);
  }

  private getHoursMessage(hours: number, previousWorkingDay: DateTime): string {
    const date = previousWorkingDay.minus({ days: 1 }).toFormat('yyyy-MM-dd');

    if (!hours) {
      return `Je hebt gisteren nog geen uren geboekt. Als je vrij bent en je wilt dit bericht niet krijgen kun je ook van tevoren je vrije uren schrijven in TimeChimp.
https://app.timechimp.com/#/registration/time/day/${date}`;
    }
  }

  private async delete<T, S>(
    cls: ClassConstructor<unknown>,
    path: string,
    body: S,
    options: ApiOptions = {}
  ): Promise<T> {
    const queryString = buildQueryString(options.queryParams);
    const url = `https://api.timechimp.com${path}${queryString}`;
    this.logger.log(`DELETE: ${url}`);

    const response = await firstValueFrom(
      this.httpClient.delete(url, {
        headers: {
          Authorization: `Bearer ${this.config.token}`,
        },
        data: body,
      })
    );

    if (response.status >= 400) {
      const message = `Error response from TimeChimp API (status ${response.status}):\n${JSON.stringify(
        body,
        null,
        2
      )}`;
      this.logger.error(message);
      throw new Error(message);
    }

    if (cls) {
      const responseBody = response.data;

      return plainToInstance(cls, responseBody, {
        excludeExtraneousValues: true,
      }) as T;
    }
  }

  private async post<T, S>(
    cls: ClassConstructor<unknown>,
    path: string,
    body: S,
    options: ApiOptions = {}
  ): Promise<T> {
    const queryString = buildQueryString(options.queryParams);
    const url = `https://api.timechimp.com${path}${queryString}`;
    this.logger.log(`POST: ${url}`);

    const response = await firstValueFrom(
      this.httpClient.post(url, body, {
        headers: {
          Authorization: `Bearer ${this.config.token}`,
        },
      })
    );

    const responseBody = response.data;

    if (response.status >= 400) {
      const message = `Error response from TimeChimp API (status ${response.status}):\n${JSON.stringify(
        body,
        null,
        2
      )}`;
      this.logger.error(message);
      throw new Error(message);
    }

    return plainToInstance(cls, responseBody, {
      excludeExtraneousValues: true,
    }) as T;
  }

  private async get<T>(cls: ClassConstructor<unknown>, path: string, options: ApiOptions = {}): Promise<T> {
    const queryString = buildQueryString(options.queryParams);
    const url = `https://api.timechimp.com${path}${queryString}`;
    this.logger.log(`GET: ${url}`);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const response = await firstValueFrom(
      this.httpClient.get(url, {
        headers: {
          Authorization: `Bearer ${this.config.token}`,
        },
      })
    );

    const body = response.data;

    if (response.status >= 400) {
      throw new Error(
        `Error response from TimeChimp API (status ${response.status}):\n${JSON.stringify(body, null, 2)}`
      );
    }

    return plainToInstance(cls, body, {
      excludeExtraneousValues: true,
    }) as T;
  }
}
