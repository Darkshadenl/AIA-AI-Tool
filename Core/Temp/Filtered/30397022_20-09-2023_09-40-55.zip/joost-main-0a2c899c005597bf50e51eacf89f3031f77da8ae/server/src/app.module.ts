import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { ServeStaticModule } from '@nestjs/serve-static';
import { resolve } from 'path';
import { configuration } from '~/configuration';
import { ApplicationModule } from './application';
import { DetailedValidationPipe } from './detailedValidation.pipe';
import { TransformerInterceptor } from './transformer.interceptor';

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: resolve('./static'),
    }),
    ConfigModule.forRoot({
      load: [configuration],
      isGlobal: true,
    }),
    ScheduleModule.forRoot(),

    ApplicationModule,
  ],
  providers: [
    {
      provide: 'APP_PIPE',
      useValue: new DetailedValidationPipe(),
    },
    {
      provide: 'APP_INTERCEPTOR',
      useValue: new TransformerInterceptor(),
    },
  ],
})
export class AppModule {}
