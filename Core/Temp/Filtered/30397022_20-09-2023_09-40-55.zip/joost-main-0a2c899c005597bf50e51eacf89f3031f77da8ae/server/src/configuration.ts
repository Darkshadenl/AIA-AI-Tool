export interface Configuration {
  server: ServerConfig;
  files: FilesConfig;
  azureAd: AzureAdConfig;
  timeChimp: TimeChimpConfig;
  alpaca: AlpacaConfig;
  financial: FinancialConfig;
  slack: SlackConfig;
  dashboard: DashboardConfig;
  healthChecks: HealthChecksConfig;
  buzzy: BuzzyConfig;
  auth0: Auth0Config;
  mqtt: MqttConfig;
  homeassistant: HomeassistantConfig;
  googleDistance: GoogleDistanceConfig;
}

export interface ServerConfig {
  port: number;
  publicUrl: string;
  secret: string;
  version: string;
}

export interface SlackConfig {
  token: string;
  webhook: string;
}

export interface AzureAdConfig {
  instanceId: string;
  clientId: string;
  clientSecret: string;
}

export interface TimeChimpConfig {
  token: string;
  baseUrl: string;
  defaultUser: number;
  absenceTasks: string[];
  absenceProject: number;
  infiTags: string[];
}

export interface AlpacaConfig {
  baseUrl: string;
}

export interface FinancialConfig {
  costLevel: { startDate: string; level: number }[];
  marginTarget: number;
}

export interface DashboardConfig {
  token: string;
}

export interface HealthChecksConfig {
  folder: string;
}

export interface BuzzyConfig {
  url: string;
}

export interface Auth0Config {
  url: string;
  clientId: string;
  clientSecret: string;
}

export interface MqttConfig {
  url: string;
  username: string;
  password: string;
}

export interface PlantConfig {
  official_name: string;
  friendly_name: string;
  min_temperature?: number;
  max_temperature?: number;
  min_moisture?: number;
  max_moisture?: number;
  min_brightness?: number;
  max_brightness?: number;
  min_conductivity?: number;
  max_conductivity?: number;
}

export interface GoogleDistanceConfig {
  url: string;
  secret: string;
}

export interface HomeassistantConfig {
  plants: {
    [key: string]: PlantConfig;
  };
  climate: string[];
}

export interface FilesConfig {
  siteId: string;
}

export const configuration = (): Configuration => ({
  server: {
    port: parseInt(process.env.PORT || '3001'),
    publicUrl: process.env.SERVER_PUBLIC_URL || 'http://localhost:3000',
    secret: process.env.SERVER_SECRET || 'iamdevelop',
    version: process.env.SOFTWARE_VERSION || 'development',
  },
  files: {
    siteId: process.env.SHAREPOINT_SITE_ID || 'cfe44aed-5c9d-4202-8aea-ca636a6ee83b',
  },
  azureAd: {
    instanceId: process.env.AZURE_AD_INSTANCE_ID || '162f423a-8929-4b50-8501-671c8ccc7aa3',
    clientId: process.env.AZURE_AD_CLIENT_ID || '75495e47-d4f8-42eb-a620-eb53bdd827f0',
    clientSecret: process.env.AZURE_AD_CLIENT_SECRET,
  },
  timeChimp: {
    token: process.env.TIMECHIMP_TOKEN,
    baseUrl: process.env.TIMECHIMP_URL || 'https://api.timechimp.com',
    defaultUser: Number(process.env.TIMECHIMP_DEFAULT_USER) || 157090,
    absenceTasks: process.env.TIMECHIMP_ABSENCE_TASKS
      ? process.env.TIMECHIMP_ABSENCE_TASKS.split(',')
      : ['Verlof', 'Feestdag', 'Bijzonder verlof', 'Ziek'],
    absenceProject: Number(process.env.TIMECHIMP_ABSENCE_PROJECT) || 2725275,
    infiTags: process.env.TIMECHIMP_INFI_TAGS
      ? process.env.TIMECHIMP_INFI_TAGS.split(',')
      : ['Nijmegen', 'Amsterdam', 'Utrecht'],
  },
  alpaca: {
    baseUrl: process.env.ALPACA_URL || 'https://uren_api.infi.nl',
  },
  financial: {
    costLevel: JSON.parse(process.env.COST_LEVEL || 'false') || [
      { startDate: '0001-01-01', level: 0 },
      { startDate: '2021-10-01', level: 336000 },
      { startDate: '2022-01-01', level: 370000 },
    ],
    marginTarget: Number(process.env.MARGIN_TARGET) || 25,
  },
  slack: {
    token: process.env.SLACK_TOKEN || '',
    webhook: process.env.SLACK_WEBHOOK || '',
  },
  dashboard: {
    token: process.env.DASHBOARD_TOKEN || 'local',
  },
  healthChecks: {
    folder: process.env.HEALTH_CHECKS_FOLDER || 'Health-checks',
  },
  buzzy: {
    url: process.env.BUZZY_URL || 'https://buzzy.infi.nl',
  },
  auth0: {
    url: process.env.AUTH0_URL || 'https://infinl.eu.auth0.com',
    clientId: process.env.AUTH0_CLIENT_ID || 'tn2QzKw1RfDAMV91Vaib0zEvP9C5vqzv',
    clientSecret: process.env.AUTH0_CLIENT_SECRET,
  },
  mqtt: {
    url: process.env.MQTT_URL || 'mqtt://joost.infi.nl:1883',
    username: process.env.MQTT_USERNAME || '',
    password: process.env.MQTT_PASSWORD || '',
  },
  homeassistant: {
    plants: {
      '76a4': {
        friendly_name: 'Drakebloedboom',
        official_name: 'strelitzia alba',
      },
      '792c': {
        friendly_name: 'Inficus',
        official_name: 'ficus retusa',
      },
      '7662': {
        friendly_name: 'Calathea Insignis',
        official_name: 'calathea insignis',
      },
      '7a13': {
        friendly_name: 'Paradijsvogelplant',
        official_name: 'strelitzia alba',
      },
    },
    climate: ['houston', 'cupola'],
  },
  googleDistance: {
    url: 'https://maps.googleapis.com/maps/api/distancematrix/json',
    secret: process.env.GOOGLE_DISTANCE_API_KEY,
  },
});
