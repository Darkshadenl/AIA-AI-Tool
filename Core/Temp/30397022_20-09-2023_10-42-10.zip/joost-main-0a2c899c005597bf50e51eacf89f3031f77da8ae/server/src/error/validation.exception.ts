export class ValidationException extends Error {
  constructor(msg: string) {
    super(msg);
  }
}
