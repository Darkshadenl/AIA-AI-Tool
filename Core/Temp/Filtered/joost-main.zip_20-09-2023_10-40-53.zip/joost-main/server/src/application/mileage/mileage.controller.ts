import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Get,
  Param,
  ParseBoolPipe,
  Post,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';
import { DateTime } from 'luxon';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ValidationException } from '~/error/validation.exception';
import { Mileage, MileageDto, UpdateMileageStatus } from './mileage.dto';

@Authenticated()
@Controller('api/mileage')
@ApiTags('Mileage')
export class MileageController {
  public constructor(private readonly timeChimp: TimeChimpAdapter) {}

  @Get('range/:start/:end')
  public async getDateRange(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<MileageDto[]> {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    const mileages = await this.timeChimp.getMileage({ startDate, endDate });
    return mileages.filter((e) => Number.isNaN(userId) || e.userId === userId);
  }

  @Post()
  public createMileages(
    @Body() mileage: Mileage,
    @Query('return') createReturn: boolean,
    @Query('commute') createCommute: boolean,
    @Query('homeAddress') homeAddress: string | undefined,
    @Query('preview', new DefaultValuePipe(true), ParseBoolPipe) preview: boolean
  ): Promise<Mileage[]> {
    return this.timeChimp.createMileages(mileage, createReturn, createCommute, preview, homeAddress).catch((e) => {
      if (e instanceof ValidationException) {
        const errorMsg = `Invalid home address while creating mileages: ${homeAddress}`;
        throw new BadRequestException(errorMsg);
      } else {
        throw e;
      }
    });
  }

  @Post('/status')
  public updateMileageStatus(@Body() mileage: UpdateMileageStatus): Promise<UpdateMileageStatus> {
    return this.timeChimp.updateMileageStatus(mileage);
  }
}
