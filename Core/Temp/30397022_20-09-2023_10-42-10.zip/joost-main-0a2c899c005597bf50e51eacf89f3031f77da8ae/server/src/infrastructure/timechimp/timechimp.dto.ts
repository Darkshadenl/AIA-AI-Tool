import { Expose } from 'class-transformer';
import { IsEnum } from 'class-validator';

export class TimeChimpUserDto {
  @Expose()
  public id: number;

  @Expose()
  public displayName: string;

  @Expose()
  public userName: string;

  @Expose()
  public contractHours: number;

  @Expose()
  public tagNames: string[];
}

export class TaskDto {
  @Expose()
  public id: number;

  @Expose()
  public name: string;

  @Expose()
  public billable: boolean;

  @Expose()
  public hourlyRate: number | null;
}

export class ProjectTaskDto {
  @Expose()
  public id: number;

  @Expose()
  public projectId: number;

  @Expose()
  public taskId: number;

  @Expose()
  public taskName: string;

  @Expose()
  public hourlyRate: number | null;
}

export enum InvoiceMethod {
  NoInvoicing = 1,
  TaskHourlyRate = 2, // Time & Materials
  UserHourlyRate = 3, // Time & Materials
  ProjectHourlyRate = 4, // Time & Materials
  CustomerHourlyRate = 5, // Time & Materials
  ProjectRate = 6, // Fixed Price
  TaskRate = 7, // Fixed Price
  MilestoneRate = 8,
  Subscription = 9,
}

export class ProjectDto {
  @Expose()
  public id: number;

  @Expose()
  public name: string;

  @Expose()
  public customerId: number;

  @Expose()
  public customerName: string;

  @Expose()
  public hourlyRate: number;

  @Expose()
  public projectTasks: ProjectTaskDto[];

  @IsEnum(InvoiceMethod)
  @Expose()
  public invoiceMethod: InvoiceMethod;

  @Expose()
  public tagNames: string[];
}

export class CustomerDto {
  @Expose()
  public id: number;

  @Expose()
  public name: string;

  @Expose()
  public address: string;

  @Expose()
  public city: string;

  @Expose()
  public postalCode: string;

  @Expose()
  public country: string;

  @Expose()
  public tagNames: string[];
}
