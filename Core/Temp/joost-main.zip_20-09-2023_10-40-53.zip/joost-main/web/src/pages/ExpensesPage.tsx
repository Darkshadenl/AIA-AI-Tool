import { useCallback, useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { DateRangeSelector, Range } from '../components/DateRangeSelector';
import { ExpenseCard } from '../components/ExpenseCard';
import { PeopleSelector } from '../components/PeopleSelector';
import { useTimeChimpUser, useUsers } from '../hooks/useUserData';
import { DownloadService } from '../services/DownloadService';
import { Expense, ExpenseAndStatus, ExpensesService, UpdateExpenses } from '../services/ExpensesService';
import { ReportService } from '../services/ReportService';
import { User } from '../services/TimeChimpService';

export const ExpensesPage = () => {
  const users = useUsers();
  const expensesService = useService(ExpensesService);
  const reportService = useService(ReportService);
  const downloadService = useService(DownloadService);

  const [range, setRange] = useState<Range>({});
  const [selectedUser, setSelectedUser] = useState<User | undefined>(useTimeChimpUser());
  const [expenses, setExpenses] = useState<ExpenseAndStatus[]>([]);
  const [overruledExpenses, setOverruledExpenses] = useState<number[]>([]);
  const [previewButtonEnabled, setPreviewButtonEnabled] = useState(true);
  const [submitButtonEnabled, setSubmitButtonEnabled] = useState(false);
  const [expensesPreviewed, setExpensesPreviewed] = useState(false);
  const [allExpensesComplyWithRules, setAllExpensesComplyWithRules] = useState(false);
  const [explanationText, setExplanationText] = useState<string>('');
  const [explanationTextStyle, setExplanationTextStyle] = useState<string>('explanation-text-warning');

  const updateExpenses = useCallback(
    (start: string, end: string) => {
      expensesService.getExpenses(start, end, selectedUser?.id).then((expense) => {
        const filteredExpenses: Expense[] = expense
          .filter((expense) => expense.customerName === 'Infi Nijmegen B.V.' && expense.projectName === 'Intern')
          .filter((expense) => users.find((user) => user.id === expense.userId));

        const newExpenses = filteredExpenses.map((e) => ({
          expense: e,
          needsCheck: !expensesService.confomsToBusinessRules(e) && e.status !== 3,
        }));
        setAllExpensesComplyWithRules(!newExpenses.find((e) => e.needsCheck));
        setExpenses(newExpenses);
      });
    },
    [expensesService, selectedUser?.id, users]
  );

  const shouldEnablePreviewButton = useCallback(() => {
    if (!range.start || !range.end) return false;

    if (!selectedUser) {
      setExplanationText('Are you santa? You cannot submit expenses for everyone at the same time!');
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }
    const openExpenses = expenses.filter((e) => e.expense.status === 0);
    if (openExpenses.length === 0) {
      setExplanationText('No expenses to submit, well done!');
      setExplanationTextStyle('notification explanation-text-correct');
      return false;
    }
    if (!allExpensesComplyWithRules) {
      setExplanationText("Don't be naughty! Not all expenses comply with the business rule, check them!");
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }

    setExplanationText('Absolute legend! You can preview your unsubmitted expenses!');
    setExplanationTextStyle('notification explanation-text-correct');
    return true;
  }, [allExpensesComplyWithRules, expenses, range.end, range.start, selectedUser]);

  const verifiedExpense = useCallback(
    async (expenseId: number) => {
      await setOverruledExpenses([...overruledExpenses, expenseId]);
    },
    [overruledExpenses]
  );

  useEffect(() => {
    setAllExpensesComplyWithRules(
      !expenses.find((e) => {
        return e.needsCheck && !overruledExpenses.find((item) => item === e.expense.id);
      })
    );
  }, [expenses, overruledExpenses]);

  useEffect(() => {
    if (!users || !range.start || !range.end) {
      return;
    }

    updateExpenses(range.start, range.end);
    setExpensesPreviewed(false);
  }, [expensesService, range.end, range.start, selectedUser?.id, updateExpenses, users]);

  useEffect(() => {
    setPreviewButtonEnabled(shouldEnablePreviewButton());
  }, [shouldEnablePreviewButton]);

  useEffect(() => {
    if (allExpensesComplyWithRules && expensesPreviewed) {
      setExplanationText('Even better: You can submit your expenses!');
      setExplanationTextStyle('notification explanation-text-correct');
      setSubmitButtonEnabled(true);
    } else {
      setSubmitButtonEnabled(false);
    }
  }, [allExpensesComplyWithRules, expensesPreviewed]);

  async function getExpenseReport(isPreview: boolean) {
    if (!users || !range.start || !range.end) {
      return;
    }
    const report = await reportService.getExpenseReport(range.start, range.end, isPreview, selectedUser);
    let filename: string;
    if (isPreview) {
      filename = `PREVIEW-DECL ${selectedUser?.displayName} ${range.start} - ${range.end}`;
    } else {
      filename = `DECL ${selectedUser?.displayName} ${range.start} - ${range.end}`;
    }
    downloadService.download(report, filename);
  }

  async function changeSubmittedExpenses() {
    if (!users || !range.start || !range.end) {
      return;
    }
    const ExpensesIds = expenses.filter((e) => e.expense.status !== 3).map((e) => e.expense.id);
    const toBeUpdatedExpenses: UpdateExpenses = {
      registrationIds: ExpensesIds,
      status: 3,
    };
    await expensesService.updateExpenses(toBeUpdatedExpenses);
    await updateExpenses(range.start, range.end);
  }

  function PreviewAndSubmitElement() {
    return (
      <div className="buttons is-right ">
        <div className={explanationTextStyle}> {explanationText} </div>
        <button
          className="button preview-button mx-1"
          disabled={!previewButtonEnabled}
          onClick={() => {
            getExpenseReport(true);
            setExpensesPreviewed(true);
          }}
        >
          Preview
        </button>
        <button
          className="button submit-button mx-1"
          disabled={!submitButtonEnabled}
          onClick={() => {
            getExpenseReport(false);
            changeSubmittedExpenses();
          }}
        >
          Submit
        </button>
      </div>
    );
  }

  return (
    <>
      <div className="columns">
        <div className="column">
          <h1>Expenses</h1>
        </div>
      </div>
      <div className="columns">
        <div className="column">
          <PeopleSelector selectedUser={selectedUser} setSelectedUser={setSelectedUser} />
        </div>
        <DateRangeSelector range={range} onRangeChange={setRange} />
      </div>
      <PreviewAndSubmitElement />
      {expenses.map((e) => (
        <ExpenseCard
          key={e.expense.id}
          expense={e.expense}
          appliesToRules={expensesService.confomsToBusinessRules(e.expense)}
          warningText={expensesService.generateWarningText(e.expense)}
          verifiedExpense={verifiedExpense}
        />
      ))}
      <PreviewAndSubmitElement />
    </>
  );
};
