import { Expose } from 'class-transformer';

import { TimeDto } from '~/utils/time.dto';

export class AbsenceDto {
  @Expose()
  public startDate: Date;

  @Expose()
  public endDate: Date;

  @Expose()
  public taskId: number;

  @Expose()
  public taskName: string;

  @Expose()
  public userId: number;

  @Expose()
  public userDisplayName: string;

  @Expose()
  public times: TimeDto[];
}
