import { Expose } from 'class-transformer';

export interface UpdateMileageStatus {
  registrationIds: number[];
  status: number;
}

export enum MileageType {
  Private = 1, // Personal travel
  Business = 2, // Business
  Commute = 3, // Travel from home to work
}

export interface Mileage {
  id: number;
  userId: number;
  customerId: number;
  projectId: number;
  date: Date;
  fromAddress: string;
  toAddress: string;
  notes: string;
  distance: number;
  billable: boolean;
  type: MileageType;
}

export class MileageDto {
  @Expose()
  public id: number;

  @Expose()
  public userId: number;

  @Expose()
  public userDisplayName: string;

  @Expose()
  public customerName: string;

  @Expose()
  public projectName: string;

  @Expose()
  public fromAddress: string;

  @Expose()
  public toAddress: string;

  @Expose()
  public distance: number;

  @Expose()
  public date: string;

  @Expose()
  public billable: boolean;

  @Expose()
  public status: number;
}
