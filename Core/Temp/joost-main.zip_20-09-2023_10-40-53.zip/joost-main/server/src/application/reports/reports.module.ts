import { Module } from '@nestjs/common';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';
import { PdfModule } from '~/infrastructure/pdf';

@Module({
  imports: [TimeChimpModule, PdfModule],
  controllers: [ReportsController],
  providers: [ReportsService],
  exports: [ReportsService],
})
export class ReportsModule {}
