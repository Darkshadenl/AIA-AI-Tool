import { useUsers } from '../hooks/useUserData';
import { UserPlanning } from '../services/PlanningService';

interface DayColumnProps {
  status: string[];
  daySelector: (userPlanning: UserPlanning) => string;
  planning: UserPlanning[];
  getUserName: (email: string) => string;
}

const DayColumn = ({ planning, daySelector, status, getUserName }: DayColumnProps) => {
  const availabilityCheck = /^(\w+)-?(\w+)?/;
  return (
    <div className="column">
      {planning
        .reduce<(UserPlanning & { matched: RegExpMatchArray })[]>((acc, p) => {
          const matched = daySelector(p).match(availabilityCheck);
          if (matched?.find((s) => status.includes(s))) acc.push({ ...p, matched });
          return acc;
        }, [])
        .map((p) => {
          let halfday = '';
          if (p.matched[2]) {
            if (status.includes(p.matched[1])) halfday = ' (morning)';
            if (status.includes(p.matched[2])) halfday = ' (noon)';
          }
          return <div> {getUserName(p.email) + halfday}</div>;
        })}
    </div>
  );
};

interface Props {
  title: string;
  status: string[];
  planning: UserPlanning[];
}

export const PlanningRow = ({ title, status, planning }: Props) => {
  const users = useUsers();
  const getUserName = (email: string) => users.find((user) => user.userName === email)?.displayName || email;
  return (
    <div className="columns">
      <div className="column">
        <h3>{title}</h3>
      </div>
      <DayColumn planning={planning} daySelector={(p) => p.monday} status={status} getUserName={getUserName} />
      <DayColumn planning={planning} daySelector={(p) => p.tuesday} status={status} getUserName={getUserName} />
      <DayColumn planning={planning} daySelector={(p) => p.wednesday} status={status} getUserName={getUserName} />
      <DayColumn planning={planning} daySelector={(p) => p.thursday} status={status} getUserName={getUserName} />
      <DayColumn planning={planning} daySelector={(p) => p.friday} status={status} getUserName={getUserName} />
    </div>
  );
};
