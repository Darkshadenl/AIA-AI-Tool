import { saveAs } from 'file-saver';
import { useEffect, useState } from 'react';
import { useUser } from '../hooks/useUserData';
import { Expense, expenseStatus } from '../services/ExpensesService';
import { formatDateLong } from '../utils/date';
import { formatEuro } from '../utils/euro';

export interface Props {
  expense: Expense;
  appliesToRules: boolean;
  warningText: string;
  verifiedExpense: (expenseId: number) => void;
}

export const ExpenseCard = ({ expense, appliesToRules, warningText, verifiedExpense }: Props) => {
  const [appliesToBusinessRules, setAppliesToBusinessRules] = useState(appliesToRules);
  const [boxStyling, setBoxStyling] = useState('');
  const [viewedAttachment, setViewedAttachment] = useState(false);
  const [enableVerifiedButton, setEnableVerifiedButton] = useState(false);
  const user = useUser(expense.userId);

  useEffect(() => {
    if (appliesToBusinessRules) {
      setBoxStyling('box ok-line');
    } else {
      setBoxStyling('box warning-line');
    }
  }, [appliesToBusinessRules]);

  useEffect(() => {
    if (viewedAttachment) {
      setEnableVerifiedButton(true);
    } else {
      setEnableVerifiedButton(false);
    }
  }, [viewedAttachment]);

  return (
    <div className={boxStyling}>
      <div className="columns">
        <div className="column">
          <div className="has-text-weight-bold">{formatDateLong(expense.date)}</div>
          <div>{user.displayName}</div>
        </div>
        <div className="column">
          <div>
            {expense.customerName} ({expense.projectName})
          </div>
          <div>{expense.categoryName}</div>
        </div>
        <div className="column">
          <div>{formatEuro(expense.rate)}</div>
          <div>{expense.tax}% VAT</div>
        </div>
        <div className="column is-one-fifth tags are-medium">
          {expense.billable && <span className="tag">Billable</span>}
          {!appliesToBusinessRules && <span className="tag is-danger is-light">{warningText}</span>}
          {expense.status === expenseStatus.invoiced && <span className="tag is-warning is-light">Submitted</span>}
        </div>
        <div className="column is-one-quarter">
          <div className="buttons is-right">
            {!appliesToBusinessRules && (
              <button
                className="button verify-button"
                onClick={() => {
                  setAppliesToBusinessRules(true);
                  verifiedExpense(expense.id);
                }}
                disabled={!enableVerifiedButton && expense.attachment !== null}
              >
                Verify
              </button>
            )}
            {!expense.attachment && (
              <button className="button attachment-button" disabled={true}>
                No Attachment
              </button>
            )}
            {expense.attachment && (
              <button
                className="button attachment-button"
                onClick={() => {
                  saveAs(expense.attachment, expense.id.toString());
                  setViewedAttachment(true);
                }}
              >
                View Attachment
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
