import { Expose } from 'class-transformer';
import { DateTime } from 'luxon';
import { TransformDateTime } from '~/utils/transformDateTime';
import { Hour } from '../hour/hour.entity';
import { Assignment } from './assignment.entity';
import { DayPlanningEntity } from './dayplanning.entity';
import { Event } from './event.entity';

export interface Planning {
  id?: string;
  date: DateTime;
  dayParts: [string, string];
  employer?: string;
  email: string;
  userName?: string;
  assignments?: Assignment[];
  hours?: Hour[];
  events?: Event[];
}

type Mandatory<T, K extends keyof T> = {
  [P in K]-?: T[P];
} & { [P in keyof T]?: T[P] };

export class PlanningAggregate implements Planning {
  public id?: string;

  @Expose({ name: 'dateStr' })
  @TransformDateTime() // TODO check if anything breaks
  // @Transform(({ value }: { value: DateTime }) => value.toFormat('yyyy-MM-dd'))
  public date: DateTime;
  public dayParts: [string, string];
  public weekday: number;
  public employer?: string;
  public email: string;
  public userName?: string;
  public assignments?: Assignment[];
  public events?: Event[];
  public hours?: Hour[];

  private constructor({
    id,
    date,
    dayParts,
    employer,
    email,
    userName,
    events,
    assignments,
    hours,
  }: Mandatory<Planning, 'dayParts' | 'date' | 'email'>) {
    this.id = id;
    this.date = date;

    this.weekday = date.weekday;

    this.dayParts = dayParts;
    this.employer = employer;
    this.email = email;
    this.userName = userName;
    this.events = events;
    this.assignments = assignments;
    this.hours = hours;
  }

  public static Create(day: DayPlanningEntity, events?: Event[], assignments?: Assignment[], hours?: Hour[]): Planning {
    return new PlanningAggregate({
      date: day.date,
      dayParts: day.dayParts,
      email: day.email,
      events,
      assignments,
      hours,
    });
  }
}
