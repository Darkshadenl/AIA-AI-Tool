import { Injectable } from '@nestjs/common';
import { parse } from 'csv-parse/sync';
import { Entry, HealthCheckDto, Score } from './healthCheck.dto';

@Injectable()
export class HealthService {
  public parseHealthCheck(content: string): HealthCheckDto {
    const parsed: Record<string, string>[] = parse(content.trim(), {
      columns: true,
      trim: true,
      from_line: 3,
    });

    const result = new HealthCheckDto();
    result.entries = parsed.map((r) => this.parseEntry(r)).filter((e) => !!e);
    result.dimensions = Object.keys(result.entries[0].dimensions);
    result.healthPercentage = this.healthPercentage(result);
    result.scoreCounts = this.scoreCounts(result);
    return result;
  }

  private parseEntry(row: Record<string, string>): Entry | null {
    const entry: Entry = {
      participant: this.emailToName(row.Participant),
      dimensions: {},
    };

    Object.entries(row).forEach(([k, v]) => {
      if (k === 'Participant' || k.startsWith('Comments: ')) {
        return;
      }

      const s = parseInt(v, 10) + 1;
      entry.dimensions[k] = {
        score: v === '' ? null : ((s === 2 ? 8 : s) as Score),
        comments: row[`Comments: ${k}`],
      };
    });

    if (Object.values(entry.dimensions).every((d) => d.score == null)) {
      return null;
    }

    return entry;
  }

  private emailToName(email: string): string {
    return email
      .split('@')[0]
      .split('.')
      .map((p) => `${p.substring(0, 1).toUpperCase()}${p.substring(1)}`)
      .join(' ');
  }

  private healthPercentage(health: HealthCheckDto): number {
    const maxScore = health.dimensions.length * health.entries.length * 8;
    const score = health.entries
      .flatMap((e) => Object.values(e.dimensions))
      .map((d) => d.score ?? 0)
      .reduce((acc, cur) => acc + cur, 0);
    return Math.round((score / maxScore) * 100);
  }

  private scoreCounts(health: HealthCheckDto): Record<Score, number> {
    const counts: Record<Score, number> = { 0: 0, 1: 0, 8: 0 };
    health.entries.flatMap((e) => Object.values(e.dimensions)).forEach((v) => counts[v.score]++);
    return counts;
  }
}
