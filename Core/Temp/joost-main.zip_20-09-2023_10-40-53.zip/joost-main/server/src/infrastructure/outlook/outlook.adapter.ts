import { Client, ClientOptions } from '@microsoft/microsoft-graph-client';
import { Event } from '@microsoft/microsoft-graph-types';
import { Inject, Injectable, Logger, Scope } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { DateTime } from 'luxon';
import { MSGraphAuthProvider } from '~/auth.provider';

@Injectable({ scope: Scope.REQUEST })
export class OutlookAdapter {
  private readonly logger: Logger;
  private readonly client: Client;

  public constructor(@Inject(REQUEST) readonly request: Request) {
    this.logger = new Logger(OutlookAdapter.name);
    const auth = new MSGraphAuthProvider(request['user']);
    const clientOptions: ClientOptions = {
      authProvider: auth,
    };
    this.client = Client.initWithMiddleware(clientOptions);
  }

  public async getEvents(user: string, startDate: DateTime, endDate: DateTime) {
    const start = startDate.toFormat('yyyy-MM-dd');
    const end = endDate.toFormat('yyyy-MM-dd');
    try {
      return await this.get(`/users/${user}/calendarview?startdatetime=${start}&enddatetime=${end}&top=999`);
    } catch {
      return [];
    }
  }

  private async get(url: string): Promise<Event[]> {
    this.logger.log(`GET: ${url}`);
    try {
      const response = await this.client.api(url).get();

      return response.value;
    } catch (error) {
      if (error.message === 'message Access token has expired or is not yet valid.') {
      } else {
        throw new Error(
          `Error response from Microsoft Graph API (message ${error.message}):\n${JSON.stringify(error, null, 2)}`
        );
      }
    }
  }
}
