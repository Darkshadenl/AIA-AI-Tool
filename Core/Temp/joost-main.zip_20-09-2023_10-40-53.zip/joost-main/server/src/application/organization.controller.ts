import { Controller, Get, Param } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { Organization, OrganizationEntity } from '~/domain';
import { TimeChimpAdapter } from '~/infrastructure/timechimp';

@Authenticated()
@Controller('api/organization')
export class OrganizationController {
  constructor(private readonly timechimp: TimeChimpAdapter) {}

  @Get()
  async getAll(): Promise<Organization[]> {
    return (await this.timechimp.getCustomers()).map((o) => OrganizationEntity.fromTimeChimp(o));
  }

  @Get(':id')
  async get(@Param('id') id: number): Promise<Organization> {
    return OrganizationEntity.fromTimeChimp(await this.timechimp.getCustomer(id));
  }
}
