import { Body, Controller, Get, Post, Redirect, Req, UseGuards } from '@nestjs/common';
import { AuthenticatedRequest, User } from './authenticated.request';
import { LoginGuard } from './login.guard';
import { Authenticated } from './authenticated.decorator';
import { ApiTags } from '@nestjs/swagger';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';

function partBefore(searchFor, searchIn) {
  const index = searchIn.indexOf(searchFor);
  if (index === -1) {
    return '';
  } else {
    return searchIn.substring(0, index);
  }
}

function samePersonEmail(emailOne: string, emailTwo: string) {
  return partBefore('@', emailOne).toLowerCase() === partBefore('@', emailTwo).toLowerCase();
}

@Controller('/auth')
@ApiTags('Authentication')
export class AuthController {
  constructor(private readonly timeChimp: TimeChimpAdapter) {}

  @Get('me')
  @Authenticated()
  public async showMe(
    @Req() req: AuthenticatedRequest
  ): Promise<User & { timeChimpId?: number; contractWorkWeekHours: number }> {
    try {
      const users = await this.timeChimp.getUsers();
      const tcUser = users.find((user) => samePersonEmail(req.user.email, user.userName));
      return {
        ...req.user,
        timeChimpId: tcUser?.id,
        contractWorkWeekHours: tcUser?.contractHours,
      };
    } catch (e) {
      console.error(e);
      throw e;
    }
  }

  @Get('login')
  @UseGuards(LoginGuard)
  @Redirect('/')
  public postLogin(): void {
    // nothing to do, the guard does the work
  }

  @UseGuards(LoginGuard)
  @Redirect('/')
  @Post('/callback')
  loginCallback(@Body('state') state: string) {
    const url = state ?? '/';
    // returning the url overrides the redirect value in the decorator.
    return { url };
  }
}
