import { Logger, Module } from '@nestjs/common';
import { AlpacaController } from './alpaca.controller';
import { AlpacaService } from './alpaca.service';
import { HttpModule, HttpService } from '@nestjs/axios';
import { ConfigService } from '@nestjs/config';

@Module({
  imports: [HttpModule],
  providers: [
    {
      provide: AlpacaService,
      inject: [ConfigService, HttpService],
      useFactory: (config, http) => new AlpacaService(config, http, new Logger(AlpacaService.name)),
    },
  ],
  controllers: [AlpacaController],
})
export class AlpacaModule {}
