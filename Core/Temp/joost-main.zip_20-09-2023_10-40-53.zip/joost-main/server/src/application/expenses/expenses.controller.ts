import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ApiTags } from '@nestjs/swagger';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';
import { DateTime } from 'luxon';
import { ExpenseDto } from './expense.dto';
import { UpdateExpenses } from 'web/src/services/ExpensesService';

@Authenticated()
@Controller('api/expenses')
@ApiTags('Expenses')
export class ExpensesController {
  public constructor(private readonly timeChimp: TimeChimpAdapter) {}

  @Get('range/:start/:end')
  public async getDateRange(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<ExpenseDto[]> {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    const expenses = await this.timeChimp.getExpenses({ startDate, endDate });
    return expenses.filter((e) => Number.isNaN(userId) || e.userId === userId);
  }

  @Post('/updateExpenses')
  public updateExpenses(@Body() expense: UpdateExpenses): Promise<UpdateExpenses> {
    return this.timeChimp.updateExpensesStatus(expense);
  }
}
