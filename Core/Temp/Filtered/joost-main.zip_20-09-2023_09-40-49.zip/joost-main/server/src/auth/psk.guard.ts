import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { IncomingMessage } from 'http';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class StaticAuthentication implements CanActivate {
  private readonly acceptableToken: string;

  constructor(config: ConfigService) {
    this.acceptableToken = config.get('dashboard.token');
  }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request: IncomingMessage = context.switchToHttp().getRequest();
    const header = request.headers.authorization?.split(' ', 2);
    if (header.length !== 2) {
      return false;
    }
    const token = header[1];
    return token === this.acceptableToken;
  }
}
