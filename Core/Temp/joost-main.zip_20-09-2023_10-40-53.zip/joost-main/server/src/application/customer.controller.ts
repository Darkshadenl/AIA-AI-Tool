import { Controller, DefaultValuePipe, Get, ParseBoolPipe, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Authenticated } from '~/auth/authenticated.decorator';
import { CustomerDto, TimeChimpAdapter } from '~/infrastructure/timechimp';

@Authenticated()
@Controller('api/customers')
@ApiTags('Customer')
export class CustomerController {
  public constructor(private readonly timeChimp: TimeChimpAdapter) {}

  @Get()
  public getCustomers(
    @Query('withProjectsOnly', new DefaultValuePipe(false), ParseBoolPipe) withProjectsOnly: boolean
  ): Promise<CustomerDto[]> {
    return this.timeChimp.getCustomers(withProjectsOnly);
  }

  @Get('infi')
  public getInfiCustomers(): Promise<CustomerDto[]> {
    return this.timeChimp.getInfiCustomers();
  }
}
