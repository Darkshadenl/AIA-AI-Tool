import { Module } from '@nestjs/common';
import { BuzzyModule } from '~/infrastructure/buzzy';
import { MqttModule } from '~/infrastructure/mqtt';
import { HomeassistantModule } from '~/infrastructure/homeassistant';
import { TimeChimpModule } from '~/infrastructure/timechimp';
import { FinanceModule } from '../finance/finance.module';
import { CronService } from './cron.service';

@Module({
  imports: [BuzzyModule, TimeChimpModule, FinanceModule, HomeassistantModule, MqttModule],
  providers: [CronService],
})
export class CronModule {}
