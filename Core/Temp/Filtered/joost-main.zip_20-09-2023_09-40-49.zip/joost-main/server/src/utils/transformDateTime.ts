import { Transform } from 'class-transformer';
import { DateTime } from 'luxon';

export const TransformDateTime = () =>
  Transform(({ value }: { value: DateTime }) => value && value.toISO(), { toPlainOnly: true });
