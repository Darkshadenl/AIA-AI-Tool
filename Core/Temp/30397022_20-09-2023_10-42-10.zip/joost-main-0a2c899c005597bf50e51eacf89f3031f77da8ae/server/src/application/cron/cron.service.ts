import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { DateTime } from 'luxon';
import { BuzzyAdapter } from '~/infrastructure/buzzy';
import { MqttService } from '~/infrastructure/mqtt';
import { HomeassistantAdapter } from '~/infrastructure/homeassistant';
import { TimeChimpAdapter } from '~/infrastructure/timechimp';
import { FinanceService } from '../finance/finance.service';

@Injectable()
export class CronService {
  private readonly logger = new Logger(CronService.name);

  public constructor(
    private readonly financeService: FinanceService,
    private readonly timeChimpService: TimeChimpAdapter,
    private readonly homeassistantAdapter: HomeassistantAdapter,
    private readonly buzzyAdapter: BuzzyAdapter,
    private readonly mqttService: MqttService
  ) {}

  /* Monday to Friday at 8:30 */
  @Cron('0 30 08 * * 1-5')
  public async morningMessage(): Promise<void> {
    this.logger.log('running MorningMessage');
    const now = DateTime.now();
    this.logger.debug(
      `Morning task started. UTC: ${now.toISO()}. Local: ${now.toLocaleString(DateTime.DATETIME_FULL)}`
    );
    await this.timeChimpService
      .checkDailyWorkedHours()
      .catch((e) => this.logger.warn(`Error during morning message: ${e}`));
  }

  /* Monday to Thursday hourly */
  @Cron('0 0 * * * 1-4')
  public async hourlyRevenueCheck(): Promise<void> {
    this.logger.log('running hourlyRevenueCheck');
    await this.financeService.checkRevenue().catch((e) => this.logger.warn(`Error during hourly revenue check: ${e}`));
  }

  /* Friday every 5 minutes */
  @Cron('0 */5 * * * 5')
  public async fridayRevenueCheck(): Promise<void> {
    this.logger.log('running fridayRevenueCheck');
    await this.financeService.checkRevenue().catch((e) => this.logger.warn(`Error during Friday revenue check: ${e}`));
  }

  /* Monday 9:00 */
  @Cron('0 0 9 * * 1')
  public async mondayMorningRevenueReport(): Promise<void> {
    this.logger.log('running mondayMorningRevenueReport');
    const lastWeek = DateTime.now().minus({ weeks: 1 });
    await this.financeService
      .reportRevenue(lastWeek)
      .catch((e) => this.logger.warn(`Error during Monday morning revenue report ${e}`));
  }

  /* Monday to Friday 8:00 */
  @Cron('0 0 8 * * 1-5')
  public async weekdayMorningPlantsHealthCheck(): Promise<void> {
    this.logger.log('running weekdayMorningPlantsHealthCheck');
    await this.homeassistantAdapter
      .checkPlantsHealth()
      .catch((e) => this.logger.warn(`Error during daily morning plants health check: ${e}`));
  }

  @Cron('0 */30 * * * *')
  public async sendBuzzyCountsToMqtt(): Promise<void> {
    const dayCounts = await this.buzzyAdapter.getDayCounts('nijmegen', DateTime.now());

    this.mqttService.publish(`buzzy/today/nijmegen`, dayCounts);
  }
}
