import { Test } from '@nestjs/testing';
import { AlpacaController } from './alpaca.controller';
import { AlpacaService, AlpacaProject, AlpacaTask, AlpacaItem, parseDate } from './alpaca.service';
import { ConfigService } from '@nestjs/config';
import { Logger } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';

describe('AlpacaController', () => {
  let alpacaController: AlpacaController;
  let alpacaService: AlpacaService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [AlpacaController],
      imports: [HttpModule],
      providers: [ConfigService, Logger, AlpacaService],
    }).compile();

    alpacaService = moduleRef.get<AlpacaService>(AlpacaService);
    alpacaController = moduleRef.get<AlpacaController>(AlpacaController);
  });

  describe('getProjects', () => {
    it('should return an array of projects', async () => {
      const result: AlpacaProject[] = [
        {
          id: 1,
          name: 'My First Project',
        },
      ];
      jest.spyOn(alpacaService, 'getProjects').mockImplementation(() => Promise.resolve(result));
      expect(await alpacaController.getProjects()).toBe(result);
    });
  });

  describe('getTasks', () => {
    it('should return an array of tasks', async () => {
      const result: AlpacaTask[] = [];
      const spy = jest.spyOn(alpacaService, 'getProjectTasks').mockImplementation(() => Promise.resolve(result));

      expect(await alpacaController.getTasks(1)).toBe(result);
      expect(spy).toBeCalledWith([1]);
    });
  });

  describe('getWeek', () => {
    it('should return an array of items', async () => {
      const result: AlpacaItem[] = [];
      const spy = jest.spyOn(alpacaService, 'getProjectItems').mockImplementation(() => Promise.resolve(result));
      const project = 23;
      const startDate = '2011-10-09';
      const endDate = '2012-12-22';

      expect(await alpacaController.getWeek(project, startDate, endDate)).toBe(result);
      expect(spy).toBeCalledWith([project], parseDate(startDate), parseDate(endDate));
    });

    it('error', async () => {
      const expected = 'there is something rotten in the state of Danmark';
      jest.spyOn(alpacaService, 'getProjectItems').mockImplementation(() => Promise.reject(new Error(expected)));
      const project = 23;
      const startDate = '2011-10-09';
      const endDate = '2012-12-22';

      alpacaController
        .getWeek(project, startDate, endDate)
        .then(() => fail('should fail'))
        .catch((actual) => expect(actual.message).toEqual(expected));
    });
  });
});
