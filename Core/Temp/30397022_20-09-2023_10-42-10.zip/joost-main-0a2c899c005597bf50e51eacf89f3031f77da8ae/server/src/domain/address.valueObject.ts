export interface PhysicalAddress {
  postalCode?: string;
  street?: string;
  city?: string;
  country?: string;
}
