import { Injectable } from '@nestjs/common';
import { DateTime } from 'luxon';
import { HourFactory } from '../hour';
import { BuzzyAdapter } from '~/infrastructure/buzzy';
import { OutlookAdapter } from '~/infrastructure/outlook';
import { TimeChimpAdapter } from '~/infrastructure/timechimp';
import { groupBy } from '~/utils/groupBy';
import { DayPlanningEntity } from './dayplanning.entity';
import { EventEntity } from './event.entity';
import { PlanningAggregate } from './planning.aggregate';

@Injectable()
export class PlanningService {
  constructor(
    private readonly buzzy: BuzzyAdapter,
    private readonly outlookAdapter: OutlookAdapter,
    private readonly timeChimpAdapter: TimeChimpAdapter,
    private readonly hourFactory: HourFactory
  ) {}

  public async getLocationPlanning(location: string, startDate: DateTime, endDate: DateTime, includeEvents = false) {
    const buzzyDays = await this.buzzy.getLocationPlanning(location, startDate, endDate);
    return Promise.all(
      buzzyDays.map(async (buzzy) => {
        const outlookEvents = !includeEvents
          ? []
          : await this.outlookAdapter.getEvents(buzzy.email, startDate, endDate);
        const day = DayPlanningEntity.FromBuzzy(buzzy);
        const events = outlookEvents.map((e) => EventEntity.FromOutlookEvent(e));
        const eventGroups = groupBy(events, (event) => event.startDateTime.toFormat('yyyy-MM-dd'));

        return PlanningAggregate.Create(day, eventGroups[day.date.toFormat('yyyy-MM-dd')] ?? []);
      })
    );
  }

  public async getUserPlanning(email: string, startDate: DateTime, endDate: DateTime) {
    const buzzyPromise = this.buzzy.getUserPlanning(email, startDate, endDate);
    const outlookPromise = this.outlookAdapter.getEvents(email, startDate, endDate);
    const timeChimpPromise = this.timeChimpAdapter.getTimes({ startDate, endDate });
    const [buzzyDays, outlookEvents, timeChimpTimes] = await Promise.all([
      buzzyPromise,
      outlookPromise,
      timeChimpPromise,
    ]);

    const days = buzzyDays.map((d) => DayPlanningEntity.FromBuzzy(d));
    const events = outlookEvents.map((e) => EventEntity.FromOutlookEvent(e));
    const hours = await Promise.all(timeChimpTimes.map(async (t) => await this.hourFactory.fromTimeChimp(t)));
    const hourGroups = groupBy(hours, (hour) => hour.startDateTime.toFormat('yyyy-MM-dd'));
    const eventGroups = groupBy(events, (event) => event.startDateTime.toFormat('yyyy-MM-dd'));

    return days.map((day) =>
      PlanningAggregate.Create(
        day,
        eventGroups[day.date.toFormat('yyyy-MM-dd')] ?? [],
        [],
        hourGroups[day.date.toFormat('yyyy-MM-dd')] ?? []
      )
    );
  }
}
