import { Injectable, Logger } from '@nestjs/common';
import { createWriteStream } from 'fs';
import * as fs from 'fs/promises';
import * as handlebars from 'handlebars';
import { DateTime } from 'luxon';
import { tmpdir } from 'os';
import * as path from 'path';
import { Readable } from 'stream';
import { finished } from 'stream/promises';
import * as streamWeb from 'stream/web';
import { ExpenseDto } from '~/application/expenses/expense.dto';
import { MileageDto } from '~/application/mileage/mileage.dto';
import { PdfService } from '~/infrastructure/pdf';
import { TimeChimpAdapter } from '~/infrastructure/timechimp';

@Injectable()
export class ReportsService {
  private readonly logger = new Logger(ReportsService.name);

  public constructor(private readonly timeChimpService: TimeChimpAdapter, private readonly pdfService: PdfService) {}

  public async generateMileageReport(start: string, end: string, userId: number, preview = false) {
    const mileages = await this.getMileages(start, end, userId);
    const title = (preview ? 'PREVIEW ' : '') + `Kilometer declaratie ${start} - ${end}`;
    const htmlReport = await this.populateMileageHtmlFile(start, end, mileages, title);
    const folder = await this.createTempFolder(title);
    const attachments = [];
    return await this.generatePdfFile(folder, htmlReport, attachments);
  }

  private async createTempFolder(title: string) {
    const folder = path.join(tmpdir(), Date.now().toString() + ' ' + title);
    await fs.mkdir(folder, { recursive: true });
    return folder;
  }

  private async generatePdfFile(folder: string, htmlReport: string, attachments: string[]) {
    const htmlFileName = path.join(folder, 'report.html');
    const pdfFileName = path.join(folder, 'report.pdf');
    await fs.writeFile(htmlFileName, htmlReport);
    await this.pdfService.htmlToPdf(htmlFileName, pdfFileName);
    await this.pdfService.concatPdf([pdfFileName, ...attachments], folder + '.pdf');
    await fs.rm(folder, { recursive: true });
    const contents = await fs.readFile(folder + '.pdf');
    await fs.rm(folder + '.pdf');
    return contents;
  }

  private async getMileages(start: string, end: string, userId: number) {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    const mileages = await this.timeChimpService.getMileage({ startDate, endDate });
    return mileages
      .filter((mileage) => mileage.customerName === 'Infi Nijmegen B.V.' && mileage.projectName === 'Intern')
      .filter((mileage) => mileage.userId === userId && mileage.status === 0)
      .sort((a, b) => {
        if (a.date < b.date) {
          return -1;
        } else if (a.date > b.date) {
          return 1;
        }
        return 0;
      });
  }

  private async populateMileageHtmlFile(
    start: string,
    end: string,
    filteredMileages: MileageDto[],
    title: string
  ): Promise<string> {
    const name = filteredMileages[0].userDisplayName;
    const initials = name.match(/\b([A-Z])/g).join('');
    const period = `${start} - ${end}`;

    const collected = filteredMileages.reduce<{ rows: string[]; total: number }>(
      (acc, mileage) => {
        const cost = +(mileage.distance * 0.21).toFixed(2);
        acc.rows.push(`
      <tr>
          <td>${mileage.date.split('T')[0]}</td>
          <td>${mileage.fromAddress}</td>
          <td>${mileage.toAddress}</td>
          <td>${mileage.distance} km</td>
          <td class="right">€${cost}</td>
      </tr>
      `);
        acc.total += mileage.distance * 0.21;
        return acc;
      },
      { rows: [], total: 0 }
    );

    const template = await fs.readFile('templates/mileageReportTemplate.html', 'utf-8');
    const compiledTemplate = handlebars.compile(template);
    return compiledTemplate({
      Title: title,
      Initials: initials,
      Period: period,
      Total: collected.total.toFixed(2),
      Name: name,
      mileageRows: collected.rows.join(''),
    });
  }

  public async generateExpenseReport(start: string, end: string, userId: number, preview = false) {
    const expenses = await this.getExpenses(start, end, userId);
    const title = (preview ? 'PREVIEW ' : '') + `Onkosten declaratie ${start} - ${end}`;
    const htmlReport = await this.populateExpenseHtmlFile(start, end, expenses, title);
    const folder = await this.createTempFolder(title);
    const attachments = await this.prepareAttachments(expenses, folder);
    return await this.generatePdfFile(folder, htmlReport, attachments);
  }

  private async prepareAttachments(expenses: ExpenseDto[], folder: string) {
    this.logger.debug('prepareAttachments');
    return await Promise.all(
      expenses
        .filter((expense) => !!expense.attachment)
        .map(async (expense) => {
          const attachment = expense.attachment;
          const fileName = attachment.substring(attachment.lastIndexOf('/') + 1);
          const destination = path.resolve(folder, fileName);
          this.logger.debug(`downloading ${attachment} to ${destination}`);

          const fileStream = createWriteStream(destination, { flags: 'wx' });
          const { body } = await fetch(attachment);
          await finished(Readable.fromWeb(body as streamWeb.ReadableStream).pipe(fileStream));

          if (destination.endsWith('.pdf')) {
            return destination;
          }

          await this.pdfService.imageToPdf(destination, destination + '.pdf');

          return destination + '.pdf';
        })
    );
  }

  private async getExpenses(start: string, end: string, userId: number) {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    const expenses = await this.timeChimpService.getExpenses({ startDate, endDate });
    return expenses
      .filter((expense) => expense.customerName === 'Infi Nijmegen B.V.' && expense.projectName === 'Intern')
      .filter((expense) => expense.userId === userId && expense.status === 0)
      .sort((a, b) => {
        if (a.date < b.date) {
          return -1;
        } else if (a.date > b.date) {
          return 1;
        }
        return 0;
      });
  }

  private async populateExpenseHtmlFile(
    start: string,
    end: string,
    filteredExpenses: ExpenseDto[],
    title: string
  ): Promise<string> {
    const name = filteredExpenses[0]?.userDisplayName;
    const initials = name.match(/\b([A-Z])/g).join('');
    const period = `${start} - ${end}`;

    const collected = filteredExpenses.reduce<{ rows: string[]; total: number }>(
      (acc, expense) => {
        acc.rows.push(`<tr>
          <td>${expense.date.split('T')[0]}</td>
          <td>${expense.notes}</td>
          <td>${expense.categoryName}</td>
          <td class="right">${expense.tax}%</td>
          <td class="right">€ ${expense.rate.toFixed(2)}</td>
      </tr>`);
        acc.total += expense.rate;
        return acc;
      },
      { rows: [], total: 0 }
    );

    const template = await fs.readFile('templates/expensesReportTemplate.html', 'utf-8');
    const compiledTemplate = handlebars.compile(template);
    return compiledTemplate({
      Title: title,
      Initials: initials,
      Period: period,
      Total: collected.total.toFixed(2),
      Name: name,
      expenseRows: collected.rows.join(''),
    });
  }
}
