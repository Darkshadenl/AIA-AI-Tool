import { useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { AbsenceCard } from '../components/AbsenceCard';
import { AbsenceInput } from '../components/AbsenceInput';
import { DateRangeSelector, Range } from '../components/DateRangeSelector';
import { PeopleSelector } from '../components/PeopleSelector';
import { useTimeChimpUser } from '../hooks/useUserData';
import { AbsenceDto, AbsenceService } from '../services/AbsencesService';

import { Planning, PlanningService } from '../services/PlanningService';
import { User } from '../services/TimeChimpService';
import { DateTime } from 'luxon';

export const AbsencesPage = () => {
  const currentUser = useTimeChimpUser();
  const absencesService = useService(AbsenceService);
  const planningService = useService(PlanningService);
  const [range, setRange] = useState<Range>({});
  const [selectedUser, setSelectedUser] = useState<User | undefined>(currentUser);
  const [absences, setAbsences] = useState<AbsenceDto[]>([]);
  const [planning, setPlanning] = useState<Planning[]>();
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (!range.start || !range.end) {
      return;
    }

    absencesService.getAbsences(range.start, range.end, selectedUser?.id).then(setAbsences);
  }, [absencesService, range.end, range.start, selectedUser?.id]);

  useEffect(() => {
    if (selectedUser) {
      if (!range.start || !range.end) {
        return;
      }
      planningService.getUserPlanning(selectedUser.userName, range.start, range.end).then(setPlanning);
    }
  }, [planningService, selectedUser, range.end, range.start]);
  useEffect(() => {
    console.log(planning);
  }, [planning]);
  return (
    <>
      <div className="columns">
        <div className="column">
          <h1>Absences</h1>
        </div>
      </div>
      <div className="columns">
        <div className="column">
          <PeopleSelector selectedUser={selectedUser} setSelectedUser={setSelectedUser} />
        </div>
        <DateRangeSelector range={range} onRangeChange={setRange} />
      </div>
      <div className="absence-card absence-card-header">
        <div className="box">
          <div className="columns">
            <div className="column has-text-weight-bold">Date</div>
            <div className="column has-text-weight-bold">
              <div>
                <i className={`icon fa-regular fa-clock`}></i>
                Timechimp
              </div>
              <div>
                <i className={`icon fa-regular fa-bee`}></i>
                Buzzy
              </div>
              <div>
                <i className={`icon fa-regular fa-calendar`}></i>
                Outlook
              </div>
            </div>
            <div className="column has-text-weight-bold">Duration</div>
            <div className="column has-text-weight-bold is-one-third">Outlook</div>
          </div>
        </div>
      </div>
      {planning &&
        absences.map((a, index) => {
          const p = planning.find(
            (planning) => DateTime.fromISO(a.startDate).toFormat('yyyy-MM-dd') === planning.date.toFormat('yyyy-MM-dd')
          );
          const o = p?.events || [];
          return <AbsenceCard key={index} absence={a} planning={p} outlook={o} />;
        })}
      {showModal && (
        <div className="modal is-active">
          <div className="modal-background"></div>
          <div className="modal-card">
            <header className="modal-card-head">
              <p className="modal-card-title">Absentie toevoegen</p>
              <button className="delete" aria-label="close" onClick={() => setShowModal(false)}></button>
            </header>
            <section className="modal-card-body">
              <AbsenceInput />
            </section>
            <footer className="modal-card-foot">
              <button className="button is-info">Save changes</button>
              <button className="button" onClick={() => setShowModal(false)}>
                Cancel
              </button>
            </footer>
          </div>
        </div>
      )}
      {/* {selectedUser && currentUser && selectedUser.id === currentUser.id && (
        <button onClick={() => setShowModal(true)} className="button is-info">
          +
        </button>
      )} */}
    </>
  );
};
