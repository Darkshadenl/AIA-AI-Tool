import { Module } from '@nestjs/common';
import { AuthModule } from '~/auth/auth.module';
import { BuzzyAdapter } from './buzzy.adapter';

@Module({
  imports: [AuthModule],
  providers: [BuzzyAdapter],
  exports: [BuzzyAdapter],
})
export class BuzzyModule {}
