import { Module } from '@nestjs/common';
import { DomainModule } from '~/domain';
import { HomeassistantModule } from '~/infrastructure/homeassistant';
import { MqttModule } from '~/infrastructure/mqtt';
import { AbsencesModule } from './absences/absences.module';
import { CronModule } from './cron/cron.module';
import { CustomerController } from './customer.controller';
import { DashboardModule } from './dashboard/dashboard.module';
import { ExpensesModule } from './expenses/expenses.module';
import { FinanceModule } from './finance/finance.module';
import { HealthModule } from './health/health.module';
import { HourController } from './hours.controller';
import { MileageModule } from './mileage/mileage.module';
import { OfficeController } from './office.controller';
import { OrganizationController } from './organization.controller';
import { PlanningController } from './planning.controller';
import { ReportsModule } from './reports/reports.module';
import { SystemController } from './system.controller';
import { HoursModule } from './timechimp-hours/hours.module';
import { UsersController } from './users.controller';
import { TimeChimpModule } from '~/infrastructure/timechimp';
import { BuzzyModule } from '~/infrastructure/buzzy';
import { AlpacaModule } from './alpaca/alpaca.module';
import { DistanceModule } from '~/application/distance/distance.module';

@Module({
  imports: [
    AbsencesModule,
    AlpacaModule,
    BuzzyModule,
    CronModule,
    DashboardModule,
    DomainModule,
    ExpensesModule,
    FinanceModule,
    HealthModule,
    HoursModule,
    MileageModule,
    MqttModule,
    HomeassistantModule,
    ReportsModule,
    TimeChimpModule,
    DistanceModule,
  ],
  controllers: [
    HourController,
    UsersController,
    CustomerController,
    OrganizationController,
    PlanningController,
    OfficeController,
    SystemController,
  ],
})
export class ApplicationModule {}
