import { useBuzzyUser, useTimeChimpUser, useAuthUser } from '../hooks/useUserData';

export const ProfilePage = () => {
  const timeChimp = useTimeChimpUser();
  const buzzy = useBuzzyUser();
  const outlook = useAuthUser();
  return (
    <>
      <div className="columns">
        <div className="column">
          <h1>Profile</h1>
        </div>
      </div>
      <div>
        <div>
          <h2>Outlook</h2>
          <pre>{JSON.stringify(outlook, null, 2)}</pre>
        </div>
        <div>
          <h2>Buzzy</h2>
          <pre>{JSON.stringify(buzzy, null, 2)}</pre>
        </div>
        <div>
          <h2>Timechimp</h2>
          <div>
            <pre>{JSON.stringify(timeChimp, null, 2)}</pre>
          </div>
        </div>
      </div>
    </>
  );
};
