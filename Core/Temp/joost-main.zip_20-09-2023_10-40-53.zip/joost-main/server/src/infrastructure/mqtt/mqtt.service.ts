import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { MqttClient, connect } from 'mqtt';
import { MqttConfig } from '~/configuration';

export type MqttPayload = { entity: string; key: string; data: string | number };
type MqttHandler = (topic: string, payload: MqttPayload) => void;

@Injectable()
export class MqttService {
  private readonly logger = new Logger(MqttService.name);

  private readonly config: MqttConfig;

  private mqttClient: MqttClient;

  constructor(config: ConfigService) {
    this.config = config.get('mqtt');
    this.mqttClient = connect(this.config.url, { username: this.config.username, password: this.config.password });

    this.mqttClient.on('connect', () => {
      this.logger.log('Connected to MQTT');
    });

    this.mqttClient.once('error', (err) => {
      this.logger.error('Error in connecting to MQTT', err);
    });
  }

  subscribe(subcribeToTopic: string, callback: MqttHandler): void {
    this.mqttClient.subscribe(subcribeToTopic);

    this.mqttClient.on('message', (topic, payload) => {
      let data = payload.toString();
      try {
        // Auto parses single string values to numbers
        data = JSON.parse(payload.toString());
      } catch {}

      const path = topic.split('/');
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const [_, type, entity, key] = path;
      if (topic.startsWith(subcribeToTopic.slice(0, -1))) {
        callback(type, { entity, key, data });
      }
    });
  }

  publish(topic: string, payload: unknown): void {
    this.mqttClient.publish(topic, JSON.stringify(payload));
  }
}
