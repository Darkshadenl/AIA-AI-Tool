import { Injectable } from '@nestjs/common';
import { User } from '~/domain';

@Injectable()
export class UsersService {
  async findAll(): Promise<User[]> {
    return [];
  }

  async find(email: string): Promise<User> {
    return (await this.findAll()).find((user) => user.email === email);
  }
}
