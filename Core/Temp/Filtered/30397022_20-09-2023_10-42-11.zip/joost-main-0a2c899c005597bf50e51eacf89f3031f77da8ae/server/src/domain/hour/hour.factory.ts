import { Injectable } from '@nestjs/common';
import { DateTime } from 'luxon';
import { HourEntity } from '~/domain';
import { InvoiceMethod, ProjectDto, ProjectTaskDto, TaskDto, TimeChimpAdapter } from '~/infrastructure/timechimp';
import { TimeDto } from '~/utils/time.dto';

@Injectable()
export class HourFactory {
  constructor(private readonly timechimp: TimeChimpAdapter) {}

  private getHourlyRate(project: ProjectDto, task: TaskDto, projectTask: ProjectTaskDto): number {
    if (!task.billable) {
      return 0;
    }
    switch (project.invoiceMethod) {
      case InvoiceMethod.NoInvoicing:
        return 0;
      case InvoiceMethod.TaskHourlyRate:
        return projectTask.hourlyRate === null ? task.hourlyRate ?? 0 : projectTask.hourlyRate;
      case InvoiceMethod.ProjectHourlyRate:
        return project.hourlyRate;
      default:
        throw Error(`Unhandled invoicemethod ${project.invoiceMethod}`);
    }
  }

  async fromTimeChimp(time: TimeDto) {
    const {
      id,
      customerId,
      customerName,
      projectId,
      projectName,
      userId,
      userDisplayName,
      date,
      start,
      end,
      hours,
      taskId,
      taskName,
      projectTaskId,
    } = time;
    const project = await this.timechimp.getProject(projectId);
    const task = await this.timechimp.getTask(taskId);
    const projectTask = project.projectTasks.find((projectTask) => projectTask.id === projectTaskId);
    const projectTag = project.tagNames.find((tag) => this.timechimp.config.infiTags.includes(tag));
    const vendor = (await this.timechimp.getInfis())[projectTag];
    const user = await this.timechimp.getUser(userId);
    if (!user) {
      console.log('NO USER', { userId, user, time });
    }
    const userTag = user.tagNames.find((tag) => this.timechimp.config.infiTags.includes(tag));
    const supplier = (await this.timechimp.getInfis())[userTag];
    const rate = this.getHourlyRate(project, task, projectTask);

    return new HourEntity({
      id: `timeChimp/${id}`,
      customerId: `timeChimp/${customerId}`,
      customerName,
      projectId: `timeChimp/${projectId}`,
      projectName,
      employeeId: `timeChimp/${userId}`,
      employeeName: userDisplayName,
      startDateTime: start ? DateTime.fromISO(start) : DateTime.fromISO(date),
      endDateTime: end ? DateTime.fromISO(end) : undefined,
      durationHours: hours,
      isInvoiced: false,
      rate: rate,
      serviceId: `timeChimp/${taskId}`,
      serviceName: taskName,
      supplierId: String(supplier?.id || ''),
      supplierMyOrganizationProfileId: String(supplier?.id || ''),
      supplierName: supplier?.name || 'No supplier',
      typeId: '',
      typeLabel: '',
      vendorId: String(vendor?.id || ''),
      vendorName: vendor?.name || 'No vendor',
    });
  }
}
