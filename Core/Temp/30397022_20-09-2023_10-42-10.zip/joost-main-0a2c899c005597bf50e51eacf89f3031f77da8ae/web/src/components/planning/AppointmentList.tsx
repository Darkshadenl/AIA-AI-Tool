import { DateTime, DateTimeFormatOptions } from 'luxon';
import { useEffect, useState } from 'react';
import { v4 } from 'uuid';
import { Event } from '../../services/PlanningService';

interface AppointmentListProps {
  appointments: Event[];
}

interface AppointmentWithFormatting extends Event {
  formatStart: () => DateTime;
  formatEnd: () => DateTime;
}

export const AppointmentList = ({ appointments }: AppointmentListProps) => {
  const [formattedAppointments, setAppointments] = useState([] as AppointmentWithFormatting[]);

  const dateFormatOptions: DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long',
    hour: 'numeric',
    minute: 'numeric',
  };

  useEffect(() => {
    const appointmentsWithFormatting: AppointmentWithFormatting[] = appointments.map((appointment) => ({
      ...appointment,
      formatStart: () => DateTime.fromISO(appointment.startDateTime.toString()),
      formatEnd: () => DateTime.fromISO(appointment.endDateTime.toString()),
    }));
    setAppointments(appointmentsWithFormatting);
  }, [appointments]);

  if (formattedAppointments.length === 0) {
    return <div>No appointments found</div>;
  }
  return (
    <div className="appointmentContainer">
      <span className="appointmentCounter">
        <i>{formattedAppointments.length} appointments found</i>
      </span>
      {formattedAppointments.map((appointment) => (
        <div key={v4()}>
          <b className="appointmentHeader">
            {appointment.subject} {appointment.isOof ? '- De hele dag' : ''}
          </b>
          <br></br>
          <b>Organizer(s)</b> - <span>{appointment.organizerName}</span> <br></br>{' '}
          <span className="app app_start">
            <b>Start:&nbsp;</b>
            {appointment.formatStart().toLocaleString(dateFormatOptions)}
          </span>
          <span className="app app_end">
            <b>End:&nbsp;</b>
            {appointment.formatEnd().toLocaleString(dateFormatOptions)}
          </span>
        </div>
      ))}
    </div>
  );
};
