import { Controller, Get, Logger, Param, Query } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ApiTags } from '@nestjs/swagger';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';
import { DateTime } from 'luxon';
import { AbsenceDto } from './absence.dto';

@Authenticated()
@Controller('api/absences')
@ApiTags('Absences')
export class AbsencesController {
  public constructor(private readonly timeChimp: TimeChimpAdapter, private readonly logger: Logger) {}

  @Get('range/:start/:end')
  public async getDateRange(
    @Param('start') start: string,
    @Param('end') end: string,
    @Query('userId') userId: number
  ): Promise<AbsenceDto[]> {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd');
    const absences = await this.timeChimp.getAbsences({ userId, startDate, endDate });
    const sortedAbsences = absences.sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return dateB - dateA;
    });

    const absenceGroups: AbsenceDto[] = [];
    for (const absence of sortedAbsences) {
      const { date, userId, userDisplayName, taskName, taskId } = absence;

      absenceGroups.push({
        startDate: DateTime.fromISO(date).toJSDate(),
        endDate: DateTime.fromISO(date).toJSDate(),
        userId,
        taskName,
        taskId,
        userDisplayName,
        times: [absence],
      });
    }
    return absenceGroups;
  }
}
