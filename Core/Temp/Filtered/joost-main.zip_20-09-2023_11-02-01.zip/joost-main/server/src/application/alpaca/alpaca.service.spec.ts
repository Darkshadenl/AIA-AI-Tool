import { DateTime } from 'luxon';
import { AlpacaItem, AlpacaProject, AlpacaService, AlpacaTask, parseDate } from './alpaca.service';

import { ConfigService } from '@nestjs/config';
import { Logger } from '@nestjs/common';

import { HttpService } from '@nestjs/axios';
import { Observable, of, throwError } from 'rxjs';
import { AxiosHeaders, AxiosResponse } from 'axios';

jest.mock('@nestjs/axios');

const httpService = new HttpService();
const getMock = jest.spyOn(httpService, 'get');

function getMockResponse<T>(data: T, status = 200, statusText = 'OK'): Observable<AxiosResponse> {
  return of({
    data,
    headers: {},
    config: { headers: new AxiosHeaders(), url: '' },
    status,
    statusText,
  });
}

describe('parseDate', () => {
  it('should parse correct dates', () => {
    const expected = DateTime.fromISO('2016-05-25T00:00:00.000+02:00', { zone: 'Europe/Amsterdam' });
    const actual = parseDate('2016-05-25');
    expect(actual.invalidReason).toBeNull();
    expect(actual).toEqual(expected);
  });

  it('should parse correct date times', () => {
    const expected = DateTime.fromISO('2016-05-25T09:12:34.000+02:00', { zone: 'Europe/Amsterdam' });
    const actual = parseDate('2016-05-25 09:12:34');
    expect(actual.invalidReason).toBeNull();
    expect(actual).toEqual(expected);
  });

  it('should return invalid date on incorrect dates', () => {
    const incorrectDate = '2016-23-25';
    const expected = `Invalid datetime "${incorrectDate}"`;
    expect(() => parseDate(incorrectDate)).toThrowError(expected);
  });

  it('should return null on incorrect times', () => {
    const incorrectTime = '2016-05-25 25:12:34';
    const expected = `Invalid datetime "${incorrectTime}"`;
    expect(() => parseDate(incorrectTime)).toThrowError(expected);
  });
});

describe('AlpacaService', () => {
  let alpacaService: AlpacaService;
  let logger: Logger;

  beforeEach(() => {
    const config = new ConfigService({ alpaca: { baseURL: '' } });
    logger = new Logger();
    alpacaService = new AlpacaService(config, httpService, logger);
  });

  describe('getProjects', () => {
    it('should return projects', async () => {
      const data = [
        { project_id: 42, naam: 'test 1' },
        { project_id: 37, naam: 'test 2' },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: AlpacaProject[] = [
        { id: 42, name: 'test 1' },
        { id: 37, name: 'test 2' },
      ];

      const actual = await alpacaService.getProjects();
      expect(actual).toEqual(expected);
    });

    describe('errorhandling', () => {
      it('should return error message when request returns error string', async () => {
        getMock.mockReturnValue(throwError(() => 'my error'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca projects';

        alpacaService
          .getProjects()
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith('Could not load alpaca projects', { message: 'my error' });
          });
      });

      it('should return error message when request returns error object', async () => {
        getMock.mockReturnValue(throwError(() => 'some error'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca projects';

        alpacaService
          .getProjects()
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'some error' });
          });
      });

      it('should return error message when request returns unknown error', async () => {
        getMock.mockReturnValue(throwError(() => undefined));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca projects';

        alpacaService
          .getProjects()
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'unknown error' });
          });
      });
    });
  });

  describe('getProjectTasks', () => {
    it('should return tasks', async () => {
      const data = [
        { project_id: 42, taak_id: 197, naam: 'test 1' },
        { project_id: 42, taak_id: 234, naam: 'test 2' },
        { project_id: 58, taak_id: 701, naam: 'test 3' },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: AlpacaTask[] = [
        { projectId: 42, id: 197, name: 'test 1' },
        { projectId: 42, id: 234, name: 'test 2' },
        { projectId: 58, id: 701, name: 'test 3' },
      ];

      const actual = await alpacaService.getProjectTasks([37, 42]);
      expect(actual).toEqual(expected);
    });

    describe('errorhandling', () => {
      it('should return error message when request returns error string', async () => {
        getMock.mockReturnValue(throwError(() => 'project task error'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca tasks';

        alpacaService
          .getProjectTasks([7])
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'project task error' });
          });
      });

      it('should return error message when request returns error object', async () => {
        getMock.mockReturnValue(throwError(() => 'other error'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca tasks';

        alpacaService
          .getProjectTasks([8])
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'other error' });
          });
      });

      it('should return error message when request returns unknown error', async () => {
        getMock.mockReturnValue(throwError(() => undefined));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca tasks';

        alpacaService
          .getProjectTasks([])
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'unknown error' });
          });
      });
    });
  });

  describe('getProjectItems', () => {
    it('should return items', async () => {
      const data = [
        {
          gebruiker_id: 1,
          gebruikersnaam: 'schaap',
          project_id: 2,
          taak_id: 3,
          duur: 374.123 * 3600,
          datum: '2012-01-21 10:00:37',
          omschrijving: 'work hard, play hard',
          facturabel: 1,
        },
      ];
      getMock.mockReturnValue(getMockResponse(data));

      const expected: AlpacaItem[] = [
        {
          userId: 1,
          userName: 'schaap',
          projectId: 2,
          taskId: 3,
          duration: 374.123,
          datetime: '2012-01-21 10:00',
          description: 'work hard, play hard',
          billable: true,
        },
      ];

      const actual = await alpacaService.getProjectItems([37, 42], DateTime.now(), DateTime.now());
      expect(actual).toEqual(expected);
    });

    describe('datamapping', () => {
      it('should throw on invalid date', async () => {
        const data = [
          {
            gebruiker_id: 1,
            gebruikersnaam: 'schaap',
            project_id: 2,
            taak_id: 3,
            duur: 374.123 * 3600,
            datum: 'something is wrong',
            omschrijving: 'work hard, play hard',
          },
        ];
        getMock.mockReturnValue(getMockResponse(data));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca items';

        alpacaService
          .getProjectItems([1], DateTime.now(), DateTime.now())
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'Invalid datetime "something is wrong"' });
          });
      });
    });

    describe('errorhandling', () => {
      it('should return error message when request returns error string', async () => {
        getMock.mockReturnValue(throwError(() => 'item retrieval error'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca items';

        alpacaService
          .getProjectItems([1], DateTime.now(), DateTime.now())
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'item retrieval error' });
          });
      });

      it('should return error message when request returns error object', async () => {
        getMock.mockReturnValue(throwError(() => 'fout'));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca items';

        alpacaService
          .getProjectItems([2], DateTime.now(), DateTime.now())
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'fout' });
          });
      });

      it('should return error message when request returns unknown error', async () => {
        getMock.mockReturnValue(throwError(() => undefined));

        const spy = jest.spyOn(logger, 'error').mockImplementation();

        const expected = 'Could not load alpaca items';

        alpacaService
          .getProjectItems([3], DateTime.now(), DateTime.now())
          .then(() => fail('should be rejected'))
          .catch((actual) => {
            expect(actual.message).toEqual(expected);
            expect(spy).toBeCalledWith(expected, { message: 'unknown error' });
          });
      });
    });
  });
});
