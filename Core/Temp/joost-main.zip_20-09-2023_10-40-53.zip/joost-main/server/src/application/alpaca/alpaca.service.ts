import { DateTime } from 'luxon';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AlpacaConfig } from '~/configuration';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

interface AlpacaItemDto {
  gebruiker_id: number;
  gebruikersnaam: string;
  project_id: number;
  taak_id: number;
  duur: number;
  datum: string;
  omschrijving: string;
  facturabel: number;
}

export interface AlpacaItem {
  userId: number;
  userName: string;
  projectId: number;
  taskId: number;
  duration: number;
  datetime: string;
  description: string;
  billable: boolean;
}

interface AlpacaProjectDto {
  project_id: number;
  naam: string;
}

export interface AlpacaProject {
  id: number;
  name: string;
}

interface AlpacaTaakDto {
  project_id: number;
  taak_id: number;
  naam: string;
}

export interface AlpacaTask {
  projectId: number;
  id: number;
  name: string;
}

function formatDate(date: DateTime): string {
  return date.toFormat('yyyy-MM-dd HH:mm:ss');
}

function errorMessage(error: unknown): string | undefined {
  if (typeof error === 'object' && !!error && 'message' in error) {
    return (error as { message: string }).message;
  }
  if (typeof error === 'string') {
    return error;
  }
  return undefined;
}

export function parseDate(date: string): DateTime {
  const dt = DateTime.fromFormat(date, 'yyyy-MM-dd HH:mm:ss', {
    zone: 'Europe/Amsterdam',
  });

  if (dt.invalidReason) {
    const dt = DateTime.fromFormat(date, 'yyyy-MM-dd', {
      zone: 'Europe/Amsterdam',
    });

    if (dt.invalidReason) {
      throw new Error(`Invalid datetime "${date}"`);
    }

    return dt;
  }

  return dt;
}

function mapAlpacaProjectItem(data: AlpacaItemDto): AlpacaItem {
  const { gebruiker_id, gebruikersnaam, project_id, taak_id, duur, datum, omschrijving, facturabel } = data;
  return {
    userId: gebruiker_id,
    userName: gebruikersnaam,
    projectId: project_id,
    taskId: taak_id,
    duration: duur / 3600,
    datetime: parseDate(datum).toFormat('yyyy-MM-dd HH:mm'),
    description: omschrijving,
    billable: facturabel === 1,
  };
}

function mapAlpacaProject(data: AlpacaProjectDto): AlpacaProject {
  const { project_id, naam } = data;
  return {
    id: project_id,
    name: naam,
  };
}

function mapAlpacaProjectTask(data: AlpacaTaakDto): AlpacaTask {
  const { project_id, taak_id, naam } = data;
  return {
    projectId: project_id,
    id: taak_id,
    name: naam,
  };
}

@Injectable()
export class AlpacaService {
  private readonly config: AlpacaConfig;

  public constructor(config: ConfigService, private readonly httpClient: HttpService, private readonly logger: Logger) {
    this.config = config.get('alpaca');
  }

  async getProjects(): Promise<AlpacaProject[]> {
    try {
      const response = await firstValueFrom(
        this.httpClient.get<AlpacaProjectDto[]>('/projecten.php', {
          baseURL: this.config.baseUrl,
        })
      );
      return response.data.map(mapAlpacaProject);
    } catch (error) {
      this.logger.error('Could not load alpaca projects', { message: errorMessage(error) || 'unknown error' });
      throw new Error('Could not load alpaca projects');
    }
  }

  async getProjectTasks(project_ids: number[]): Promise<AlpacaTask[]> {
    try {
      const response = await firstValueFrom(
        this.httpClient.get<AlpacaTaakDto[]>('/projecttaken.php', {
          baseURL: this.config.baseUrl,
          params: {
            projecten: project_ids.join(','),
          },
        })
      );
      return response.data.map(mapAlpacaProjectTask);
    } catch (error) {
      this.logger.error('Could not load alpaca tasks', { message: errorMessage(error) || 'unknown error' });
      throw new Error('Could not load alpaca tasks');
    }
  }

  async getProjectItems(projects: number[], startDate: DateTime, endDate: DateTime): Promise<AlpacaItem[]> {
    const params: Record<string, string> = {
      startdate: formatDate(startDate),
      enddate: formatDate(endDate),
    };

    if (projects.length > 0) {
      params.projecten = projects.join(',');
    }

    try {
      const response = await firstValueFrom(
        this.httpClient.get<AlpacaItemDto[]>('/export.php', {
          baseURL: this.config.baseUrl,
          params,
        })
      );
      return response.data.map(mapAlpacaProjectItem);
    } catch (error) {
      this.logger.error('Could not load alpaca items', { message: errorMessage(error) || 'unknown error' });
      throw new Error('Could not load alpaca items');
    }
  }
}
