export interface Identifiable {
  id: number;
  name: string;
  customerName?: string;
}
