import { Expose } from 'class-transformer';

export class HealthCheckDto {
  @Expose()
  public date?: string;

  @Expose()
  public dimensions: string[];

  @Expose()
  public entries: Entry[];

  @Expose()
  public healthPercentage: number;

  @Expose()
  public scoreCounts: Record<Score, number>;
}

export type Score = null | 0 | 1 | 8;

export interface Entry {
  participant: string;
  dimensions: Record<string, DimensionValue>;
}

export interface DimensionValue {
  score: Score;
  comments: string;
}
