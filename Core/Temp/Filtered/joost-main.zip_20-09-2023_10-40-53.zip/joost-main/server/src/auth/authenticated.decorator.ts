import { applyDecorators, UseGuards } from '@nestjs/common';
import { AuthenticatedGuard } from './authenticated.guard';

export function Authenticated(): MethodDecorator & ClassDecorator {
  return applyDecorators(UseGuards(AuthenticatedGuard));
}
