import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DateTime } from 'luxon';
import { PlantConfig } from '~/configuration';
import { MqttPayload, MqttService } from '~/infrastructure/mqtt';
import { SlackService } from '~/infrastructure/slack';
import { ClimateDto, PlantDto, WeatherDto } from './homeassistant.dto';
import { Plant } from './plant';

export interface Climate {
  room: string;
  current_temperature: number;
  temperature: number;
  current_humidity: number;
  hvac_action: string;
  friendly_name: string;
}

export interface WeatherForecast {
  datetime: string;
  isoDate: DateTime;
  precipitation: number;
  condition: string;
  temperature: number;
}

export interface Weather {
  state?: string;
  temperature?: number;
  humidity?: number;
  forecast?: WeatherForecast[];
  friendly_name?: string;
}

@Injectable()
export class HomeassistantAdapter {
  private readonly logger = new Logger(HomeassistantAdapter.name);

  private readonly _plants: Record<string, Plant> = {};
  private readonly _climate: Record<string, Partial<Climate>> = {};
  private readonly _weather: Weather = {};

  constructor(
    config: ConfigService,
    private readonly mqttService: MqttService,
    private readonly slackService: SlackService
  ) {
    this.initPlants(config.get('homeassistant').plants);
    this.initClimate(config.get('homeassistant').climate);
    this.initWeather();
  }

  private async initPlants(config: { [key: string]: PlantConfig }) {
    Object.entries(config).forEach(([name, entry]) => {
      this._plants[name] = new Plant(entry.friendly_name, entry);
    });
    await Promise.all(Object.values(this._plants).map((p) => p.init()));
    this.mqttService.subscribe('homeassistant/plant/#', (...args) => this.plantUpdate(...args));
  }

  private initClimate(config: string[]) {
    config.forEach((entry) => {
      this._climate[entry] = { room: entry };
    });
    this.mqttService.subscribe('homeassistant/climate/#', (...args) => this.climateUpdate(...args));
  }

  private initWeather() {
    this.mqttService.subscribe('homeassistant/weather/forecast_home_hourly/#', (...args) =>
      this.weatherUpdate(...args)
    );
  }

  private climateUpdate(_: string, payload: MqttPayload): void {
    if (payload.entity in this._climate) {
      this._climate[payload.entity][payload.key] = payload.data;
    }
  }
  private weatherUpdate(_: string, payload: MqttPayload): void {
    this._weather[payload.key] = payload.data;
  }

  private plantUpdate(_: string, payload: MqttPayload): void {
    if (payload.entity in this._plants) {
      this._plants[payload.entity][payload.key] = payload.data;
    } else {
      this.logger.error('Update for unknown plant ' + payload.entity);
    }
  }

  public get plants(): PlantDto[] {
    return Object.values(this._plants).map(plantToDto);
  }

  public get climate(): ClimateDto[] {
    return Object.values(this._climate).map(climateToDto);
  }

  public get weather(): WeatherDto[] {
    return [weatherToDto(this._weather)];
  }

  public async checkPlantsHealth(): Promise<void> {
    const thirsty = this.plants.filter((plant) => !plant.status.moisture.ok).map((plant) => plant.friendlyName);
    if (thirsty.length > 0) {
      let plantsMsg = '';
      if (thirsty.length > 1) {
        plantsMsg = thirsty.slice(0, -1).join(', ') + ' en ' + thirsty.slice(-1) + ' hebben';
      } else {
        plantsMsg = thirsty.at(0) + ' heeft';
      }

      await this.slackService.sendToWebhook(`Goedemorgen! ${plantsMsg} dorst :potted_plant:`);
    }
  }
}

function plantToDto(plant: Plant): PlantDto {
  const { name, officialName, info, status, happiness } = plant;
  return {
    friendlyName: name,
    officialName,
    happiness,
    info,
    status,
  };
}

function climateToDto(climate: Climate): ClimateDto {
  const { room, current_humidity, current_temperature, friendly_name, hvac_action, temperature } = climate;
  return {
    room,
    friendlyName: friendly_name,
    status: hvac_action,
    targetTemperature: temperature,
    currentHumidity: current_humidity,
    currentTemperature: current_temperature,
  };
}

function weatherToDto(weather: Weather): WeatherDto {
  const { friendly_name, state, humidity, forecast, temperature } = weather;
  return {
    friendlyName: friendly_name,
    status: state,
    temperature,
    humidity,
    forecast,
    forecastMsg: createForecastMessage(forecast),
  };
}

function createForecastMessage(forecast: WeatherForecast[]): string {
  const out = forecast
    .map((forecastAtHour) => ({ ...forecastAtHour, isoDate: DateTime.fromISO(forecastAtHour.datetime) }))
    .filter(
      (forecastAtHour) => forecastAtHour.isoDate.hasSame(DateTime.now(), 'day') && forecastAtHour.isoDate.hour < 20
    )
    .reduce((acc, forecastAtHour) => {
      if (forecastAtHour.precipitation > 0) {
        const found = acc.find((a) => forecastAtHour.isoDate.minus({ hour: 1 }).equals(a.at(-1).isoDate));
        if (found) found.push(forecastAtHour);
        else acc.push([forecastAtHour]);
      }
      return acc;
    }, [])
    .map((forecastHourGroup: WeatherForecast[]) => forecastHourGroup.map((forecastAtHour) => forecastAtHour.isoDate))
    .map((isoDateGroup: DateTime[]) => {
      const beginEnd = [isoDateGroup.at(0)];
      if (isoDateGroup.length > 1) beginEnd.push(isoDateGroup.at(-1).plus({ hour: 1 }));
      else beginEnd.push(isoDateGroup.at(0).plus({ hour: 1 }));
      return beginEnd.map((be) => be.toFormat('HH:mm')).join('-');
    });
  if (out.length > 1) {
    return "It's going to rain between " + out.slice(0, -1).join(', ') + ' and ' + out.slice(-1);
  } else if (out.length === 1) {
    return "It's going to rain between " + out.at(0);
  } else {
    return 'No rain expected';
  }
}
