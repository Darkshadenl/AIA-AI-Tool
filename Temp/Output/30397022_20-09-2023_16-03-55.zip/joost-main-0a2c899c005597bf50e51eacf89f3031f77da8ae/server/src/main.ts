import { NestFactory, Reflector } from '@nestjs/core';
import { AppModule } from './app.module';
import { ConfigService } from '@nestjs/config';
import * as session from 'express-session';
import * as passport from 'passport';
import * as cookieParser from 'cookie-parser';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import * as SessionFileStore from 'session-file-store';
import { Logger, ClassSerializerInterceptor } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = app.get(Logger);
  const config = app.get(ConfigService);
  const FileStore = SessionFileStore(session);
  const fileStoreOptions: SessionFileStore.Options = {
    ttl: 60 * 60 * 24,
    secret: config.get<string>('server.secret'),
    path: 'sessions',
    logFn: (message) => logger.error(message),
  };
  const sessionOptions: session.SessionOptions = {
    secret: config.get<string>('server.secret'),
    resave: false,
    saveUninitialized: false,
    store: new FileStore(fileStoreOptions),
  };
  app.use(session(sessionOptions));
  app.use(cookieParser());
  app.use(passport.initialize());
  app.use(passport.session());
  app.enableShutdownHooks();

  SwaggerModule.setup(
    'api',
    app,
    SwaggerModule.createDocument(
      app,
      new DocumentBuilder()
        .setTitle('Joost')
        .setDescription(
          'These are the api endpoints. To be able to use them you should create a session first. Create one by going <a href="/auth/login">here</a>.'
        )
        .setVersion(config.get<string>('server.version'))
        .build()
    )
  );

  app.useGlobalInterceptors(new ClassSerializerInterceptor(app.get(Reflector)));

  await app.listen(config.get<number>('server.port'));
}

bootstrap();
