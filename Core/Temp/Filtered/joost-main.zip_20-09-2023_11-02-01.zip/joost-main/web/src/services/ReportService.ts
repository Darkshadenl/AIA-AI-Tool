import { ApiService } from './ApiService';
import { Injector } from 'react-service-injector';
import { Buffer } from 'buffer';
import { User } from './TimeChimpService';

export class ReportService {
  public static readonly NAME = 'ReportService';

  private readonly api: ApiService;

  public constructor(injector: Injector) {
    this.api = injector.resolve(ApiService);
  }

  public async getMileageReport(start: string, end: string, isPreview: boolean, selectedUser: User | undefined) {
    if (isPreview) {
      return Buffer.from(await this.generateMileagePreviewReport(start, end, selectedUser?.id));
    } else {
      return Buffer.from(await this.generateMileageReport(start, end, selectedUser?.id));
    }
  }

  public generateMileageReport(start: string, end: string, userId?: number): Promise<Buffer> {
    return this.api.jsonGet(`/reports/mileage/range/${start}/${end}`, { userId });
  }

  public generateMileagePreviewReport(start: string, end: string, userId?: number): Promise<Buffer> {
    return this.api.jsonGet(`/reports/mileage/preview/range/${start}/${end}`, { userId });
  }

  public async getExpenseReport(start: string, end: string, isPreview: boolean, selectedUser: User | undefined) {
    if (isPreview) {
      return Buffer.from(await this.generateExpensePreviewReport(start, end, selectedUser?.id));
    } else {
      return Buffer.from(await this.generateExpenseReport(start, end, selectedUser?.id));
    }
  }

  public generateExpenseReport(start: string, end: string, userId?: number): Promise<Buffer> {
    return this.api.jsonGet(`/reports/expense/range/${start}/${end}`, { userId });
  }

  public generateExpensePreviewReport(start: string, end: string, userId?: number): Promise<Buffer> {
    return this.api.jsonGet(`/reports/expense/preview/range/${start}/${end}`, { userId });
  }
}
