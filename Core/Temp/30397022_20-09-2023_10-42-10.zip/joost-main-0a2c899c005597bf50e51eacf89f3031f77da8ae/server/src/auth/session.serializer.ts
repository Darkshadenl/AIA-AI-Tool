import { PassportSerializer } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';
import { User } from './authenticated.request';

@Injectable()
export class SessionSerializer extends PassportSerializer {
  serializeUser(user: User, done: (err: Error, user: string) => void): void {
    done(null, JSON.stringify(user));
  }
  deserializeUser(payload: string, done: (err: Error, payload: User) => void): void {
    done(null, JSON.parse(payload));
  }
}
