import { Expose } from 'class-transformer';
import { DateTime } from 'luxon';
import { TransformDateTime } from '~/utils/transformDateTime';

export interface Hour {
  id: string;
  durationHours: number;
  startDateTime: DateTime;
  endDateTime?: DateTime;
  employeeId: string;
  employeeName: string;
  customerId: string;
  customerName: string;
  projectId: string;
  projectName: string;
  rate: number;
  serviceId: string;
  serviceName: string;
  supplierId: string;
  supplierName: string;
  typeId: string;
  typeLabel: string;
  supplierMyOrganizationProfileId: string;
  isInvoiced: boolean;
  vendorId: string;
  vendorName: string;
}

export class HourEntity implements Hour {
  public id: string;
  public durationHours: number;

  @Expose({ name: 'startDateTimeStr' })
  @TransformDateTime()
  public startDateTime: DateTime;

  @Expose({ name: 'endDateTimeStr' })
  @TransformDateTime()
  public endDateTime?: DateTime;

  public employeeId: string;
  public employeeName: string;
  public customerId: string;
  public customerName: string;
  public projectId: string;
  public projectName: string;
  public rate: number;
  public serviceId: string;
  public serviceName: string;
  public supplierId: string;
  public supplierName: string;
  public typeId: string;
  public typeLabel: string;
  public supplierMyOrganizationProfileId: string;
  public isInvoiced: boolean;
  public vendorId: string;
  public vendorName: string;

  public constructor(hour: Hour) {
    this.id = hour.id;
    this.durationHours = hour.durationHours;
    this.startDateTime = hour.startDateTime;
    this.endDateTime = hour.endDateTime;
    this.employeeId = hour.employeeId;
    this.employeeName = hour.employeeName;
    this.customerId = hour.customerId;
    this.customerName = hour.customerName;
    this.projectName = hour.projectName;
    this.rate = hour.rate;
    this.serviceId = hour.serviceId;
    this.serviceName = hour.serviceName;
    this.supplierId = hour.supplierId;
    this.supplierName = hour.supplierName;
    this.typeId = hour.typeId;
    this.typeLabel = hour.typeLabel;
    this.supplierMyOrganizationProfileId = hour.supplierMyOrganizationProfileId;
    this.isInvoiced = hour.isInvoiced;
    this.vendorId = hour.vendorId;
    this.vendorName = hour.vendorName;
  }
}
