import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DateTime } from 'luxon';
import { FinancialConfig } from '~/configuration';
import { SlackService } from '~/infrastructure/slack';
import { InvoiceMethod, ProjectDto, ProjectTaskDto, TaskDto, TimeChimpAdapter } from '~/infrastructure/timechimp';
import { TimeDto } from '~/utils/time.dto';
import { ResultsDto } from './results.dto';

@Injectable()
export class FinanceService {
  private readonly config: FinancialConfig;

  public constructor(
    config: ConfigService,
    private readonly timeChimpService: TimeChimpAdapter,
    private readonly slackService: SlackService,
    private readonly logger: Logger
  ) {
    this.config = config.get('financial');
  }

  private static calculateMargin(revenue: number, costs: number): number {
    return revenue && ((revenue - costs) / revenue) * 100;
  }

  public async getResultsByDate(startDate: DateTime, endDate: DateTime): Promise<ResultsDto> {
    const [internalRevenue, externalRevenue] = await this.getRevenue({ startDate, endDate });
    const [internalBillableHours, externalBillableHours] = await this.getBillableHours({ startDate, endDate });

    const costs = await this.getCosts({ startDate, endDate });

    return FinanceService.calculateResults(
      startDate,
      endDate,
      internalRevenue,
      externalRevenue,
      costs,
      internalBillableHours,
      externalBillableHours
    );
  }

  public async getResults(
    date: DateTime,
    period: 'week' | 'month' | 'year',
    partialCosts?: boolean
  ): Promise<ResultsDto> {
    const startDate = date.startOf(period);
    const endDate = date.endOf(period);
    const [internalRevenue, externalRevenue] = await this.getRevenue({ startDate, endDate });
    const [internalBillableHours, externalBillableHours] = await this.getBillableHours({ startDate, endDate });

    let costs = await this.getCosts({ startDate, endDate });

    if (partialCosts && DateTime.local().startOf(period).equals(startDate)) {
      const elapsedDays = Math.floor(DateTime.local().diff(startDate, 'days').days + 1);
      const partialDays =
        period === 'week' && elapsedDays > 5
          ? 5
          : period === 'month' && elapsedDays > 30
          ? 30
          : period === 'year' && elapsedDays > 365
          ? 365
          : elapsedDays;

      const totalDays = period === 'week' ? 5 : period === 'month' ? 30 : 365;

      costs = (costs * partialDays) / totalDays;
    }
    return FinanceService.calculateResults(
      startDate,
      endDate,
      internalRevenue,
      externalRevenue,
      costs,
      internalBillableHours,
      externalBillableHours
    );
  }

  public static calculateResults(
    startDate: DateTime,
    endDate: DateTime,
    internalRevenue: number,
    externalRevenue: number,
    costs: number,
    internalBillableHours: number,
    externalBillableHours: number
  ): ResultsDto {
    return {
      startDate: startDate.toFormat('yyyy-MM-dd'),
      endDate: endDate.toFormat('yyyy-MM-dd'),
      internal: {
        billableHours: internalBillableHours,
        revenue: internalRevenue,
        costs: costs,
        marginPercentage: this.calculateMargin(internalRevenue, costs),
        hourlyRate: internalRevenue / internalBillableHours,
      },
      external: {
        billableHours: externalBillableHours,
        revenue: externalRevenue,
        costs: externalRevenue,
        marginPercentage: this.calculateMargin(internalRevenue, costs),
        hourlyRate: externalRevenue / externalBillableHours,
      },
      total: {
        billableHours: internalBillableHours + externalBillableHours,
        revenue: internalRevenue + externalRevenue,
        costs: costs + externalRevenue,
        marginPercentage: this.calculateMargin(internalRevenue + externalRevenue, costs + externalRevenue),
        hourlyRate: (internalRevenue + externalRevenue) / (internalBillableHours + externalBillableHours),
      },
    };
  }

  private getHourlyRate(project: ProjectDto, task: TaskDto, projectTask: ProjectTaskDto): number {
    if (!task.billable) {
      return 0;
    }
    switch (project.invoiceMethod) {
      case InvoiceMethod.NoInvoicing:
        return 0;
      case InvoiceMethod.TaskHourlyRate:
        return projectTask.hourlyRate === null ? task.hourlyRate ?? 0 : projectTask.hourlyRate;
      case InvoiceMethod.ProjectHourlyRate:
        return project.hourlyRate;
      default:
        throw Error(`Unhandled invoicemethod ${project.invoiceMethod}`);
    }
  }

  public async getRevenue(range: { startDate: DateTime; endDate: DateTime }): Promise<[number, number]> {
    const getexternalRevenueUsers = this.timeChimpService.getUsers();
    const getProjects = this.timeChimpService.getProjects();
    const getTimes = this.timeChimpService.getTimes(range);
    const getTasks = this.timeChimpService.getTasks();
    const internalUsers = (await getexternalRevenueUsers)
      .filter((user) => user.tagNames.includes('Loondienst'))
      .map((user) => user.id);
    const projects = await getProjects;
    const times = await getTimes;
    const tasks = await getTasks;

    const calculateTotal = (total: number, time: TimeDto) => {
      const project = projects.find((project) => project.id == time.projectId);
      if (!project) {
        this.logger.warn(`item without project: ${time.date} ${time.userDisplayName} ${time.customerName}`);
        return total;
      }

      const projectTask = project.projectTasks.find((projectTask) => projectTask.id == time.projectTaskId);
      const task = tasks.find((task) => task.id == time.taskId);
      if (!task) {
        this.logger.warn(
          `item without task: ${time.taskId} ${time.taskName} ${time.date} ${time.userDisplayName} ${time.customerName} ${project.name}`
        );
        return total;
      }

      const hourlyRate = this.getHourlyRate(project, task, projectTask);
      return total + time.hours * hourlyRate;
    };

    return [
      times.filter((time) => internalUsers.includes(time.userId)).reduce(calculateTotal, 0),
      times.filter((time) => !internalUsers.includes(time.userId)).reduce(calculateTotal, 0),
    ];
  }

  private async getBillableHours(range: { startDate: DateTime; endDate: DateTime }): Promise<[number, number]> {
    const getexternalRevenueUsers = this.timeChimpService.getUsers();
    const getTasks = this.timeChimpService.getTasks();
    const getTimes = this.timeChimpService.getTimes(range);
    const internalUsers = (await getexternalRevenueUsers)
      .filter((user) => user.tagNames.includes('Loondienst'))
      .map((user) => user.id);
    const times = await getTimes;
    const tasks = await getTasks;

    const [internalTimes, externalTimes] = [
      times.filter((time) => internalUsers.includes(time.userId)),
      times.filter((time) => !internalUsers.includes(time.userId)),
    ];

    return [
      FinanceService.calculateBillableHours(internalTimes, tasks),
      FinanceService.calculateBillableHours(externalTimes, tasks),
    ];
  }

  public static calculateBillableHours(times: TimeDto[], tasks: TaskDto[]): number {
    return times.reduce((partialSum, time) => {
      if (tasks.find((task) => task.id == time.taskId && task.billable)) {
        return partialSum + time.hours;
      } else {
        return partialSum;
      }
    }, 0);
  }

  public async getCosts(range: { startDate: DateTime; endDate: DateTime }): Promise<number> {
    // TODO: Currently from config, we need to figure out how to retrieve the costs for a date range.
    // Maybe we can get it from a google spreadsheet

    const { startDate, endDate } = range;
    const targetDate = startDate.toFormat('yyyy-MM-dd');
    const days = Math.floor(endDate.diff(startDate, 'days').days) + 1;

    const { level } = [...this.config.costLevel.sort((a, b) => (a.startDate < b.startDate ? 1 : -1))].find(
      ({ startDate }) => startDate <= targetDate
    ) || { level: 0 };

    return Promise.resolve((days * level) / 365);
  }

  private reportedEvents = { week: 0, breakEven: false, target: false };

  public async reportRevenue(startDate: DateTime): Promise<void> {
    const results = await this.getResults(startDate, 'week');
    await this.slackService.sendToWebhook(
      `Afgelopen week hebben we een omzet behaald van *€ ${(Math.round(results.internal.revenue * 100) / 100).toFixed(
        2
      )}*. Dat is *${results.internal.marginPercentage.toFixed(1)}%* marge.`
    );
  }

  public async checkRevenue(): Promise<void> {
    const now = DateTime.now();

    if (this.reportedEvents.week !== now.weekNumber) {
      this.reportedEvents.week = now.weekNumber;
      this.reportedEvents.breakEven = false;
      this.reportedEvents.target = false;
    }

    if (this.reportedEvents.breakEven && this.reportedEvents.target) {
      return;
    }

    const results = await this.getResults(now, 'week');
    if (!this.reportedEvents.breakEven && results.internal.marginPercentage > 0) {
      await this.slackService.sendToWebhook(
        `Met een omzet van *€ ${results.internal.revenue.toFixed(2)}* hebben we zojuist *breakeven* bereikt!`
      );
      this.reportedEvents.breakEven = true;
    } else if (!this.reportedEvents.target && results.internal.marginPercentage > this.config.marginTarget) {
      await this.slackService.sendToWebhook(
        `Met een omzet van *€ ${results.internal.revenue.toFixed(
          2
        )}* hebben we zojuist *${results.internal.marginPercentage.toFixed(1)}%* marge bereikt!`
      );
      this.reportedEvents.target = true;
    }
  }
}
