import { Controller, DefaultValuePipe, Get, Param, ParseBoolPipe, Query } from '@nestjs/common';
import { Authenticated } from '~/auth/authenticated.decorator';
import { DateTime } from 'luxon';
import { ApiTags } from '@nestjs/swagger';
import { ResultsDto } from './results.dto';
import { FinanceService } from './finance.service';

@Authenticated()
@Controller('api/finance')
@ApiTags('Time Tracking')
export class FinanceController {
  public constructor(private readonly financeService: FinanceService) {}

  @Get('/date/:startDate/:endDate')
  public async getResultsByDate(
    @Param('startDate') startDateStr: string,
    @Param('endDate') endDateStr: string
  ): Promise<ResultsDto> {
    const startDate = DateTime.fromFormat(startDateStr, 'yyyy-MM-dd').startOf('day');
    const endDate = DateTime.fromFormat(endDateStr, 'yyyy-MM-dd').endOf('day');
    return this.financeService.getResultsByDate(startDate, endDate);
  }

  @Get('/week/:weekYear/:weekNumber')
  public async getResultsByWeek(
    @Param('weekYear') weekYear: number,
    @Param('weekNumber') weekNumber: number,
    @Query('partial', new DefaultValuePipe(false), ParseBoolPipe) partial: boolean
  ): Promise<ResultsDto> {
    const date = DateTime.fromObject({ weekYear, weekNumber });
    return this.financeService.getResults(date, 'week', !!partial);
  }

  @Get('/month/:year/:month')
  public async getResultsByMonth(
    @Param('year') year: number,
    @Param('month') month: number,
    @Query('partial', new DefaultValuePipe(false), ParseBoolPipe) partial: boolean
  ): Promise<ResultsDto> {
    const date = DateTime.fromObject({ year, month, day: 1 });
    return this.financeService.getResults(date, 'month', !!partial);
  }

  @Get('/year/:year')
  public getResultsByYear(@Param('year') year: number): Promise<ResultsDto> {
    const date = DateTime.fromObject({ year, month: 1, day: 1 });
    return this.financeService.getResults(date, 'year');
  }
}
