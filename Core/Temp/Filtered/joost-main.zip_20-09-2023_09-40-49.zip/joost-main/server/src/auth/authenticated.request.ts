import { Request } from '@nestjs/common';

export interface User {
  email: string;
  firstName: string;
  lastName: string;
  picture: string;
  accessToken: string;
  refreshToken: string;
}

export interface AuthenticatedRequest extends Request {
  user: User;
}
