import { Module } from '@nestjs/common';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { ExpensesController } from './expenses.controller';

@Module({
  imports: [TimeChimpModule],
  controllers: [ExpensesController],
})
export class ExpensesModule {}
