import { Logger, Module } from '@nestjs/common';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { MileageController } from './mileage.controller';

@Module({
  imports: [TimeChimpModule],
  providers: [Logger],
  controllers: [MileageController],
})
export class MileageModule {}
