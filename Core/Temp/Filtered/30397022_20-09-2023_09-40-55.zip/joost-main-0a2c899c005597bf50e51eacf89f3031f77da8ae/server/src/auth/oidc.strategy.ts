import { PassportStrategy } from '@nestjs/passport';
import { Issuer, Strategy, TokenSet, BaseClient } from 'openid-client';
import { ConfigService } from '@nestjs/config';
import { User } from './authenticated.request';

export async function buildOpenIdClient(config: ConfigService): Promise<BaseClient> {
  const TrustIssuer = await Issuer.discover(
    `https://login.microsoftonline.com/${config.get('azureAd.instanceId')}/v2.0/.well-known/openid-configuration`
  );
  return new TrustIssuer.Client({
    client_id: config.get('azureAd.clientId'),
    client_secret: config.get('azureAd.clientSecret'),
  });
}

export class OICDStrategy extends PassportStrategy(Strategy, 'oidc') {
  constructor(config: ConfigService, client: BaseClient) {
    super({
      client: client,
      // Parameters are filled in according to https://learn.microsoft.com/en-us/azure/active-directory/develop/v2-protocols-oidc
      params: {
        client_id: config.get('azureAd.clientId'),
        code_challenge_method: 'S256',
        prompt: 'select_account',
        redirect_uri: config.get('server.publicUrl') + '/auth/callback',
        response_mode: 'form_post',
        response_type: 'code',
        scope:
          'profile email openid User.Read Files.Read.All Calendars.ReadWrite Calendars.ReadWrite.Shared offline_access',
      },
      passReqToCallback: false,
      usePKCE: true,
    });
  }

  // Passport does not use a more specific type then any.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  authenticate(req: any, options?: any): void {
    options.state = req.query?.redirect ?? '/';
    super.authenticate(req, options);
  }

  async validate(tokenset: TokenSet, done: (error: boolean, user: User) => void): Promise<void> {
    const user: {
      email: string;
      given_name: string;
      surname: string;
      picture: string;
    } = await fetch('https://graph.microsoft.com/oidc/userinfo', {
      headers: {
        Authorization: 'Bearer ' + tokenset.access_token,
      },
    }).then((response) => response.json());

    if (!user?.email) {
      // User does not have a email associated with its account, thus cannot be logged in.
      done(false, null);
    }

    const userInfo: User = {
      email: user.email,
      firstName: user.given_name,
      lastName: user.surname,
      picture: user.picture,
      accessToken: tokenset.access_token,
      refreshToken: tokenset.refresh_token,
    };
    return done(null, userInfo);
  }
}
