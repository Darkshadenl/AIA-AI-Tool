import { Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { TimeChimpModule } from '~/infrastructure/timechimp/timechimp.module';
import { FinanceModule } from '../finance/finance.module';

@Module({
  imports: [TimeChimpModule, FinanceModule],
  controllers: [DashboardController],
})
export class DashboardModule {}
