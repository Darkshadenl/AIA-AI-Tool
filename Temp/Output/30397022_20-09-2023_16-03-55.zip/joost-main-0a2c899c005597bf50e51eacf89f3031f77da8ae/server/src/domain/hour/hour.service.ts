import { Injectable, Scope } from '@nestjs/common';
import { DateTime } from 'luxon';
import { HourFactory } from './hour.factory';
import { TimeChimpAdapter } from '~/infrastructure/timechimp';

@Injectable({ scope: Scope.REQUEST })
export class HourService {
  constructor(private readonly timechimp: TimeChimpAdapter, private readonly hourFactory: HourFactory) {}

  async find(startDate: DateTime, endDate: DateTime) {
    const hours = await this.timechimp.getTimes({ startDate, endDate });

    return Promise.all(hours.map(async (hour) => this.hourFactory.fromTimeChimp(hour)));
  }
}
