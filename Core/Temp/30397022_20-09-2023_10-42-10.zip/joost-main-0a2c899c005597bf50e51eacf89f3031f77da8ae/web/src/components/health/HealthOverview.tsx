import { useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { HealthChart } from '../../charts/HealthChart';
import { HealthCheck, HealthService } from '../../services/HealthService';

export const HealthOverview = () => {
  const healthService = useService(HealthService);
  const [checks, setChecks] = useState<HealthCheck[]>();

  useEffect(() => {
    healthService.getAllHealthChecks().then((c) => setChecks(c.reverse()));
  }, [healthService]);

  return (
    <div className="health-overview">
      {checks ? <HealthChart healthChecks={checks} /> : <i className="fas fa-spin fa-refresh" />}
    </div>
  );
};
