export interface SensorStatus {
  min?: number;
  max?: number;
  value: number;
  ok: boolean;
}

interface Options {
  unit?: string;
  min?: number;
  max?: number;
  maxMessage?: string;
  minMessage?: string;
  backToGoodMessage?: string;
  update?: (message: string) => void;
}

function capitalizeFirstLetter(string: string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

export class Sensor {
  private _hasValue = false;
  private _value: number;
  private _min: number;
  private _max: number;
  public readonly unit: string;
  private maxMessage: string;
  private minMessage: string;
  private backToGoodMessage: string;
  private _outsideRange: boolean;
  private update: (message: string) => void;

  public constructor(public readonly name: string, options: Options) {
    this._min = options.min ?? 0;
    this._max = options.max ?? Number.MAX_VALUE;
    this.unit = options.unit ?? '';
    this.maxMessage = options.maxMessage ?? ':exclamation: ' + capitalizeFirstLetter(name) + ' too high';
    this.minMessage = options.minMessage ?? ':x: ' + capitalizeFirstLetter(name) + ' too low';
    this.backToGoodMessage = options.backToGoodMessage ?? ':thumbsup: ' + capitalizeFirstLetter(name) + ' ok now';
    this.update =
      options.update ??
      ((message: string) => {
        console.log(message);
      });
  }

  toString(): string {
    return `${this.value} ${this.unit}`;
  }

  get hasValue(): boolean {
    return this._hasValue;
  }

  get outsideRange(): boolean {
    return this._outsideRange;
  }

  get status(): SensorStatus {
    return { min: this.min, max: this.max, value: this.value, ok: !this.outsideRange };
  }

  get value(): number {
    return this._value;
  }

  set value(value: number | string | null) {
    if (typeof value !== 'number') {
      return;
    }

    this._hasValue = true;
    if (value !== this._value) {
      this._value = value;
      if (value < this.min) {
        if (!this._outsideRange) {
          this._outsideRange = true;
          this.update(`${this.minMessage}: ${value}${this.unit}, but wanted ${this.min}`);
        }
        return;
      }
      if (value > this.max) {
        if (!this._outsideRange) {
          this._outsideRange = true;
          this.update(`${this.maxMessage}: ${value}${this.unit}, can only handle ${this.max}`);
        }
        return;
      }

      if (this._outsideRange) {
        this._outsideRange = false;
        this.update(`${this.backToGoodMessage}: That ${this.name} (${value}${this.unit}) is what I needed!`);
      }
    }
  }

  public get min(): number {
    return this._min;
  }

  public set min(value: number | null) {
    this._min = value;
  }

  public get max(): number {
    return this._max;
  }

  public set max(value: number | null) {
    this._max = value;
  }
}
