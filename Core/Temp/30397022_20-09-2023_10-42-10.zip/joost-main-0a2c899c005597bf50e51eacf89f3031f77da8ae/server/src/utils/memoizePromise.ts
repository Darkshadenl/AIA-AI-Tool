export function memoizePromiseFn<T = unknown, S extends Array<unknown> = unknown[]>(
  fn: (...args: S) => Promise<T>
): (...args: S) => Promise<T> {
  const cache = new Map();

  return (...args: S) => {
    const key = JSON.stringify(args);

    if (!cache.has(key)) {
      const result = new Promise((resolve, reject) =>
        fn(...args)
          .catch((error) => {
            cache.delete(key);
            reject(error);
          })
          .then((value) => resolve(value))
      );
      cache.set(key, result);
    }

    return cache.get(key);
  };
}
