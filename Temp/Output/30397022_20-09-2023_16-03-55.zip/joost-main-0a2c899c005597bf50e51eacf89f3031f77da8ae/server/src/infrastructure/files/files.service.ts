import { Inject, Injectable, Logger, Scope } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Client, ResponseType } from '@microsoft/microsoft-graph-client';
import { ConfigService } from '@nestjs/config';
import { ClientSecretCredential } from '@azure/identity';
import { TokenCredentialAuthenticationProvider } from '@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials';
import { DriveItem } from '@microsoft/microsoft-graph-types';

@Injectable({ scope: Scope.REQUEST })
export class FilesService {
  private readonly logger: Logger;
  private readonly client: Client;
  private readonly siteId: string;

  public constructor(@Inject(REQUEST) private readonly request: Request, private readonly config: ConfigService) {
    this.logger = new Logger(FilesService.name);

    this.siteId = this.config.get('files.siteId');

    this.client = Client.initWithMiddleware({
      authProvider: new TokenCredentialAuthenticationProvider(
        new ClientSecretCredential(
          this.config.get('azureAd.instanceId'),
          this.config.get('azureAd.clientId'),
          this.config.get('azureAd.clientSecret')
        ),
        {
          scopes: ['https://graph.microsoft.com/.default'],
        }
      ),
    });
  }

  public async listChildrenByPath(...path: string[]): Promise<DriveItem[]> {
    const encPath = encodeURIComponent(path.join('/'));
    return (await this.client.api(`/sites/${this.siteId}/drive/root:/${encPath}:/children`).get()).value;
  }

  public getFileContentsString(fileId: string): Promise<string> {
    return this.client.api(`/sites/${this.siteId}/drive/items/${fileId}/content`).responseType(ResponseType.TEXT).get();
  }
}
