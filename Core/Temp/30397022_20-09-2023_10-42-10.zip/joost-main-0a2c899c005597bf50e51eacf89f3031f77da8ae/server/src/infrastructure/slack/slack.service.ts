import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { LogLevel, WebClient } from '@slack/web-api';
import { SlackConfig } from '~/configuration';

interface SlackUser {
  id?: string;
  real_name?: string;
}

@Injectable()
export class SlackService {
  private readonly logger = new Logger(SlackService.name);
  private readonly config: SlackConfig;
  private readonly slackClient: WebClient;

  public constructor(config: ConfigService) {
    this.config = config.get('slack');

    this.slackClient = new WebClient(this.config.token, {
      logger: {
        info: this.logger.log,
        debug: this.logger.debug,
        warn: this.logger.warn,
        error: this.logger.error,
        setLevel: () => undefined,
        getLevel: () => LogLevel.DEBUG,
        setName: () => undefined,
      },
      logLevel: LogLevel.DEBUG,
    });
  }

  private async getAllUsers(): Promise<SlackUser[]> {
    const result = await this.slackClient.users.list();
    return result.members;
  }

  public async sendToWebhook(message: string): Promise<void> {
    const hook = this.config.webhook;
    try {
      this.logger.debug(`Send '${message}' to Slack`);
      if (process.env.NODE_ENV === 'production') {
        await fetch(hook, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ blocks: [{ type: 'section', text: { type: 'mrkdwn', text: message } }] }),
        });
      }
    } catch (error) {
      this.logger.error(`Could not post message to hook ${hook} : ${error}`);
    }
  }

  public async sendToUserByName(userName: string, message: string): Promise<void> {
    const slackUser = (await this.getAllUsers()).find((user) => user.real_name === userName);
    if (slackUser) {
      this.sendToUser(slackUser, message);
    } else {
      this.logger.warn(`Could not match userName ${userName} to existing Slack realName`);
    }
  }

  public async sendToUser(slackUser: SlackUser, message: string): Promise<void> {
    try {
      if (process.env.NODE_ENV === 'production') {
        await this.slackClient.chat.postMessage({
          channel: slackUser.id,
          blocks: [{ type: 'section', text: { type: 'mrkdwn', text: message } }],
          unfurl_links: false,
          unfurl_media: false,
        });
      } else {
        this.logger.debug(`Send '${message}' to ${slackUser.real_name} via Slack`);
      }
    } catch (error) {
      this.logger.error(`Could not post message to user ${slackUser.real_name} (${slackUser.id}): ${error}`);
    }
  }
}
