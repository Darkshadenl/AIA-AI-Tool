import { Controller, Get, Param, Post, Query } from '@nestjs/common';
import { DateTime } from 'luxon';
import { Authenticated } from '~/auth/authenticated.decorator';
import { Hour, HourService } from '~/domain';

interface CrossInvoiceServiceHours {
  name: string;
  totalAmount: number;
  totalDuration: number;
  hours: Hour[];
}
interface CrossInvoiceProjectHours {
  name: string;
  totalAmount: number;
  totalDuration: number;
  services: CrossInvoiceServiceHours[];
}
interface CrossInvoiceHours {
  vendorId: string;
  vendorName: string;
  supplierId: string;
  supplierName: string;
  supplierMyOrganizationProfileId: string;
  totalAmount: number;
  totalDuration: number;
  projects: CrossInvoiceProjectHours[];
}

@Authenticated()
@Controller('api/hours')
export class HourController {
  constructor(private readonly service: HourService) {}
  @Get('date/:start/:end')
  getRange(@Param('start') start: string, @Param('end') end: string) {
    const startDate = DateTime.fromFormat(start, 'yyyy-MM-dd');
    const endDate = DateTime.fromFormat(end, 'yyyy-MM-dd').endOf('day');

    return this.service.find(startDate, endDate);
  }

  @Get('week/:weekYear/:weekNumber')
  getWeek(@Param('weekYear') weekYear: number, @Param('weekNumber') weekNumber: number) {
    const startDate = DateTime.fromObject({ weekYear, weekNumber }).startOf('week');
    const endDate = startDate.endOf('week');

    return this.service.find(startDate, endDate);
  }

  @Get('month/:year/:month')
  async getMonth(@Param('year') year: number, @Param('month') month: number) {
    const startDate = DateTime.fromObject({ year, month, day: 1 });
    const endDate = startDate.endOf('month');

    return this.service.find(startDate, endDate);
  }

  @Post('cross/invoices/:year/:month')
  async createInvoices(@Param('year') year: number, @Param('month') month: number): Promise<void> {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const invoiceData = await this.collectInvoiceData(year, month);
    // await Promise.all(invoiceData.invoices.map((data) => this.simplicate.postInvoice(data)));
    throw new Error('not implemented');
  }

  @Get('cross/invoices/:year/:month')
  async collectInvoiceData(
    @Param('year') year: number,
    @Param('month') month: number
  ): Promise<{
    invoiced: CrossInvoiceHours[];
    uninvoiced: CrossInvoiceHours[];
    //  invoices: InvoiceDto[] }
  }> {
    const invoiced = await this.getCross(year, month, { invoiced: true });
    const uninvoiced = await this.getCross(year, month, { uninvoiced: true });
    // const invoices = await Promise.all(
    //   invoiced.map(async (cross) => {
    //     const my_organization_profile_id = cross.supplierMyOrganizationProfileId;
    //     const organization = await this.simplicate.getOrganization(cross.vendorId);
    //     const payment_term_id = organization.debtor?.payment_term.id;
    //     const vat_class = await this.simplicate.getVatClass('0%');
    //     const status = await this.simplicate.getInvoiceStatus('Draft');
    //     const revenue_group = await this.simplicate.getRevenueGroup('Algemeen');
    //     const invoice_lines: CreateInvoiceLineDto[] = cross.projects.flatMap((project) =>
    //       project.services.map((service) => ({
    //         date: DateTime.now().toFormat('yyyy-MM-dd'),
    //         description: project.name + ': ' + service.name,
    //         amount: service.totalDuration,
    //         price: service.totalAmount / service.totalDuration,
    //         vat_class_id: vat_class.id,
    //         revenue_group_id: revenue_group.id,
    //       }))
    //     );
    //     const organization_id = cross.vendorId;
    //     const status_id = status.id;
    //     const invoice: CreateInvoiceDto = {
    //       date: DateTime.now().toFormat('yyyy-MM-dd'),
    //       subject: `Werkzaamheden van ${cross.supplierName} voor ${cross.vendorName} in ${year}-${month}`,
    //       reference: `INF-CROSS-${year}-${month}`,
    //       my_organization_profile_id,
    //       organization_id,
    //       payment_term_id,
    //       invoice_lines,
    //       status_id,
    //       sending_method: 'email',
    //     };
    //     return invoice;
    //   })
    // );
    // return { invoiced, uninvoiced, invoices };
    return { invoiced, uninvoiced };
  }

  @Get('cross/:year/:month')
  async getCross(
    @Param('year') year: number,
    @Param('month') month: number,
    @Query() query: { invoiced?: unknown; uninvoiced?: unknown }
  ): Promise<CrossInvoiceHours[]> {
    const startDate = DateTime.fromObject({ year, month, day: 1 });
    const endDate = startDate.endOf('month');
    const showInvoicedOnly = 'invoiced' in query;
    const showUninvoicedOnly = 'uninvoiced' in query;
    const hours = await this.service.find(startDate, endDate);
    return hours
      .filter(
        (hour) =>
          hour.vendorId &&
          hour.vendorId !== hour.supplierId &&
          (!(showInvoicedOnly || showUninvoicedOnly) ||
            (showInvoicedOnly && hour.isInvoiced) ||
            (showUninvoicedOnly && !hour.isInvoiced))
      )
      .reduce<CrossInvoiceHours[]>((accu, hour) => {
        let invoice = accu.find((i) => i.vendorName === hour.vendorName && i.supplierName === hour.supplierName);
        if (!invoice) {
          invoice = {
            vendorId: hour.vendorId,
            vendorName: hour.vendorName,
            supplierName: hour.supplierName,
            supplierId: hour.supplierId,
            supplierMyOrganizationProfileId: hour.supplierMyOrganizationProfileId,
            totalAmount: 0,
            totalDuration: 0,
            projects: [],
          };
          accu.push(invoice);
        }
        let project = invoice.projects.find((p) => p.name === hour.customerName + ':' + hour.projectName);
        if (!project) {
          project = {
            name: hour.customerName + ':' + hour.projectName,
            totalDuration: 0,
            totalAmount: 0,
            services: [],
          };
          invoice.projects.push(project);
        }
        let service = project.services.find((s) => s.name == hour.serviceName + ' @ ' + hour.rate);
        if (!service) {
          service = { name: hour.serviceName + ' @ ' + hour.rate, totalDuration: 0, totalAmount: 0, hours: [] };
          project.services.push(service);
        }

        const { durationHours, rate } = hour;
        invoice.totalAmount += durationHours * rate;
        invoice.totalDuration += durationHours;
        project.totalAmount += durationHours * rate;
        project.totalDuration += durationHours;
        service.totalAmount += durationHours * rate;
        service.totalDuration += durationHours;
        service.hours.push(hour);

        return accu;
      }, []);
  }
}
