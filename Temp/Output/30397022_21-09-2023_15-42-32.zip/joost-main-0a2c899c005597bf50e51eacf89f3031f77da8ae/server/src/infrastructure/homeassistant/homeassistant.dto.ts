import { Expose } from 'class-transformer';
import { PlantInfo, PlantStatus } from './plant';
import { WeatherForecast } from './homeassistant.adapter';

export class PlantDto {
  @Expose()
  public friendlyName: string;

  @Expose()
  public officialName: string;

  @Expose()
  public happiness: string;

  @Expose()
  public status: PlantStatus;

  @Expose()
  public info: PlantInfo;
}

export class ClimateDto {
  @Expose()
  public room: string;

  @Expose()
  public friendlyName: string;

  @Expose()
  public status: string;

  @Expose()
  public targetTemperature: number;

  @Expose()
  public currentTemperature: number;

  @Expose()
  public currentHumidity: number;
}

export class WeatherDto {
  @Expose()
  public friendlyName: string;

  @Expose()
  public status: string;

  @Expose()
  public temperature: number;

  @Expose()
  public humidity: number;

  @Expose()
  public forecast: WeatherForecast[];

  @Expose()
  public forecastMsg: string;
}
