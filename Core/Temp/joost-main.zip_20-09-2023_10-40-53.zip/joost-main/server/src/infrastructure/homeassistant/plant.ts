import { PlantConfig } from '~/configuration';
import { Sensor, SensorStatus } from './sensor';

async function getPlantData(name: string) {
  const response = await fetch(
    'https://raw.githubusercontent.com/vrachieru/plant-database/master/json/' + name + '.json'
  );

  return await response.json();
}

export interface PlantStatus {
  [key: string]: SensorStatus;
}

export interface PlantInfo {
  pid: string;
  image: string;
  imageUrl: string;
  parameter: {
    min_soil_moist: number;
    max_soil_moist: number;
    min_temp: number;
    max_temp: number;
    min_soil_ec: number;
    max_soil_ec: number;
    min_light_lux: number;
    max_light_lux: number;
  };
}

export class Plant {
  private _moisture: Sensor;
  private _conductivity: Sensor;
  private _temperature: Sensor;
  private _brightness: Sensor;
  private _battery: Sensor;
  private readonly sensorList: Sensor[] = [];
  private readonly _official_name: string;
  private _plantDatabaseEntry: PlantInfo;

  public constructor(public readonly name: string, private readonly config: PlantConfig) {
    this._official_name = config.official_name;
  }

  public async init(): Promise<void> {
    await this.updateDB();
    await this.setSensors();
    this.sensorList.push(...[this._moisture, this._brightness, this._conductivity, this._temperature, this._battery]);
  }

  private async updateDB() {
    if (!this._plantDatabaseEntry) {
      this._plantDatabaseEntry = await getPlantData(this._official_name);
      this._plantDatabaseEntry.imageUrl =
        'https://infiofficeautomation.blob.core.windows.net/plants/' +
        encodeURIComponent(this._plantDatabaseEntry.pid) +
        '.jpg';
      this.config.min_moisture = this._plantDatabaseEntry.parameter.min_soil_moist;
      this.config.max_moisture = this._plantDatabaseEntry.parameter.max_soil_moist;
      this.config.min_temperature = this._plantDatabaseEntry.parameter.min_temp;
      this.config.max_temperature = this._plantDatabaseEntry.parameter.max_temp;
      this.config.min_conductivity = this._plantDatabaseEntry.parameter.min_soil_ec;
      this.config.max_conductivity = this._plantDatabaseEntry.parameter.max_soil_ec;
      this.config.min_brightness = this._plantDatabaseEntry.parameter.min_light_lux;
      this.config.max_brightness = this._plantDatabaseEntry.parameter.max_light_lux;
    }
  }

  private async setSensors() {
    this._temperature = new Sensor('temperature', {
      unit: '°C',
      min: this.config.min_temperature,
      max: this.config.max_temperature,
      minMessage: ":snowflake: It's cold!",
      maxMessage: ":fire: It's hot!",
      update: (message: string) => this.createAndSend(message),
    });

    this._moisture = new Sensor('moisture', {
      unit: '%',
      min: this.config.min_moisture,
      max: this.config.max_moisture,
      minMessage: ":droplet: I'm thirsty!",
      maxMessage: ":ocean: I'm drowning!",
      update: (message: string) => this.createAndSend(message),
    });

    this._brightness = new Sensor('brightness', {
      min: this.config.min_brightness,
      max: this.config.max_brightness,
      unit: 'lx',
      minMessage: ":new_moon_with_face: It's dark!",
      maxMessage: ":umbrella_on_ground: It's too bright!",
      update: (message: string) => this.createAndSend(message),
    });

    this._battery = new Sensor('battery', {
      min: 15,
      max: 100,
      unit: '%',
      minMessage: ':low_battery: Getting tired!',
      update: (message: string) => this.createAndSend(message),
    });

    this._conductivity = new Sensor('conductivity', {
      min: this.config.min_conductivity,
      max: this.config.max_conductivity,
      unit: 'μS/cm',
      minMessage: ":baby_bottle: I'm hungry! ",
      maxMessage: ":face_vomiting: I'm overfed! ",
      update: (message: string) => this.createAndSend(message),
    });
  }

  public createAndSend(title: string): void {
    console.log('DO UPDATE', this.name, title);
  }

  get happiness(): string {
    const numberOfWrongs = this.sensorList.filter((s) => s.outsideRange).length;

    if (numberOfWrongs == 0) {
      return 'good';
    }
    if (numberOfWrongs > 1) {
      return 'danger';
    }
    return 'warning';
  }

  get status(): PlantStatus {
    const res = {};
    this.sensorList.forEach((sensor) => {
      res[sensor.name] = sensor.status;
    });
    return res;
  }

  get brightness(): number {
    return this._brightness.value;
  }

  set brightness(value: number | string | null) {
    this._brightness.value = value;
  }

  get temperature(): number {
    return this._temperature.value;
  }

  set temperature(value: number | string | null) {
    this._temperature.value = value;
  }

  get moisture(): number {
    return this._moisture.value;
  }

  set moisture(value: number | string | null) {
    this._moisture.value = value;
  }

  get conductivity(): number {
    return this._conductivity.value;
  }

  set conductivity(value: number | string | null) {
    this._conductivity.value = value;
  }

  get battery(): number {
    return this._battery.value;
  }

  set battery(value: number | string | null) {
    this._battery.value = value;
  }

  get info(): PlantInfo {
    return this._plantDatabaseEntry;
  }

  get officialName(): string {
    return this._official_name;
  }

  toString(): string {
    return this.name + ' : ' + this.sensorList.map((s) => s.toString()).join(' | ');
  }
}
