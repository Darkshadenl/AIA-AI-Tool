import { BadRequestException, ValidationError, ValidationPipe } from '@nestjs/common';

interface ErrorInfo {
  property: string;
  constraints: Record<string, string>;
}

/**
 * This pipe validates incoming requests and reports errors per invalid (recursive) property.
 */
export class DetailedValidationPipe extends ValidationPipe {
  public constructor() {
    super({
      transform: true,
      whitelist: true,
      exceptionFactory: DetailedValidationPipe.handle,
    });
  }

  private static handle(errors: ValidationError[]): BadRequestException {
    return new BadRequestException({
      statusCode: 400,
      message: 'Bad Request',
      errors: DetailedValidationPipe.flattenErrors(errors, []),
    });
  }

  public static flattenErrors(errors: ValidationError[], path: string[]): ErrorInfo[] {
    // we start with all root errors
    const result: ErrorInfo[] = errors
      .filter((err) => err.children === undefined || err.children.length === 0)
      .map((error) => ({
        property: [...path, error.property].join('.'),
        constraints: error.constraints,
      }));

    // and append children
    errors
      .filter((err) => err.children && err.children.length >= 1)
      .forEach((err) => result.push(...DetailedValidationPipe.flattenErrors(err.children, [...path, err.property])));

    return result;
  }
}
