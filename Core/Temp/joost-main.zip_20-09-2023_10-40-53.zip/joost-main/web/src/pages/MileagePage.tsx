import { useCallback, useEffect, useState } from 'react';
import { useService } from 'react-service-injector';
import { CustomerSelector } from '../components/CustomerSelector';
import { DateRangeSelector, Range } from '../components/DateRangeSelector';
import { DateSelector } from '../components/DateSelector';
import { HomeAddress } from '../components/HomeAddress';
import { MileageCard } from '../components/MileageCard';
import { Modal } from '../components/Modal';
import { PeopleSelector } from '../components/PeopleSelector';
import { ProjectSelector } from '../components/ProjectSelector';
import { useTimeChimpUser, useUsers } from '../hooks/useUserData';
import { DownloadService } from '../services/DownloadService';
import { Mileage, MileageService, MileageStatus, MileageType, UpdateMileageStatus } from '../services/MileageService';
import { ReportService } from '../services/ReportService';
import { Customer, Project, TimeChimpService, User } from '../services/TimeChimpService';
import { classNames } from '../utils/classNames';

interface MileageAndStatus {
  mileage: Mileage;
  needsCheck: boolean;
}

export const MileagePage = () => {
  const users = useUsers();
  const mileageService = useService(MileageService);
  const reportService = useService(ReportService);
  const downloadService = useService(DownloadService);
  const timeChimpService = useService(TimeChimpService);
  const [range, setRange] = useState<Range>({});
  const [selectedUser, setSelectedUser] = useState<User | undefined>(useTimeChimpUser());
  const [showInstruction, setShowInstruction] = useState<boolean>(true);
  const [mileage, setMileage] = useState<MileageAndStatus[]>([]);
  const [dateSelected, setDateSelected] = useState<Date>(new Date());
  const [homeAddress, setHomeAddress] = useState<string>('');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerSelected, setCustomerSelected] = useState<Customer | undefined>();
  const [infiCustomers, setInfiCustomers] = useState<Customer[] | undefined>(undefined);
  const [infiCustomerSelected, setInfiCustomerSelected] = useState<Customer | undefined>();
  const [projects, setProjects] = useState<Project[]>([]);
  const [projectSelected, setProjectSelected] = useState<Project | undefined>();
  const [notes, setNotes] = useState<string>('');
  const [createReturn, setCreateReturn] = useState<boolean>(true);
  const [reviewButtonEnabled, setReviewButtonEnabled] = useState<boolean>(false);
  const [mileagesToCreate, setMileagesToCreate] = useState<Mileage[]>([]);
  const [mileageReviewed, setMileageReviewed] = useState<boolean>(false);
  const [mileagePreviewed, setMileagePreviewed] = useState<boolean>(false);
  const [submitButtonEnabled, setSubmitButtonEnabled] = useState<boolean>(false);
  const [allMileagesComplyWithRules, setAllMileagesComplyWithRules] = useState<boolean>(true);
  const [explanationText, setExplanationText] = useState<string>('');
  const [explanationTextStyle, setExplanationTextStyle] = useState<string>('explanation-text-warning');
  const [includeBillable, setIncludeBillable] = useState<boolean>(false);
  const [addMileagePrompt, setAddMileagePrompt] = useState<boolean>(false);
  const [mileageCreationError, setMileageCreationError] = useState<string | undefined>(undefined);

  const updateMileages = useCallback(
    (start: string, end: string) => {
      console.log('Updating mileages');
      mileageService.getMileage(start, end, selectedUser?.id).then((mileages) => {
        let filteredMileages: Mileage[] = mileages.filter((mileage) =>
          users.find((user) => user.id === mileage.userId)
        );
        if (!includeBillable) {
          filteredMileages = filteredMileages.filter(
            (mileage) => mileage.customerName === 'Infi Nijmegen B.V.' && mileage.projectName === 'Intern'
          );
        }

        const newMileages = filteredMileages.map((m) => ({
          mileage: m,
          needsCheck: !mileageService.appliesToBusinessRules(m) && m.status !== 3,
        }));

        setAllMileagesComplyWithRules(!newMileages.find((m) => m.needsCheck));
        setMileage(newMileages);
      });
    },
    [includeBillable, mileageService, selectedUser?.id, users]
  );

  const shouldEnableReviewButton = useCallback(() => {
    if (!range.start || !range.end) return false;

    const openMileages = mileage.filter((m) => m.mileage.status === 0);
    const startMonth = range.start.substring(5, range.start.lastIndexOf('-'));
    const startYear = range.start.substring(0, 4);
    const endMonth = range.end.substring(5, range.end.lastIndexOf('-'));
    const endYear = range.end.substring(0, 4);
    const now = new Date();
    const currentYear = now.getFullYear().toString();
    const currentMonth = ('0' + (now.getMonth() + 1)).slice(-2);
    const currentDate = now.toISOString().substring(0, now.toISOString().lastIndexOf('T'));
    if (includeBillable) {
      setExplanationText(`don't be greedy! you cannot submit billable mileages!`);
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }
    if (!selectedUser) {
      setExplanationText('Are you santa? You cannot submit mileages for everyone at the same time!');
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }
    if (openMileages.length === 0) {
      setExplanationText('No mileages to submit, well done!');
      setExplanationTextStyle('notification explanation-text-correct');
      return false;
    }
    if (
      (currentMonth === startMonth && currentYear === startYear) ||
      (currentMonth === endMonth && currentYear === endYear)
    ) {
      setExplanationText('Review before submitting! The current month is not yet finished');
      setExplanationTextStyle('notification has-text-white explanation-text-danger');
      return true;
    }
    if (currentDate < range.end) {
      setExplanationText('Are you a fortune teller? you cannot submit mileages for future dates!');
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }

    if (!allMileagesComplyWithRules) {
      setExplanationText("Don't be naughty! Not all mileages comply with the business rule, check them!");
      setExplanationTextStyle('notification has-text-white explanation-text-warning');
      return false;
    }

    setExplanationText('Absolute legend! You can review your unsubmitted mileages!');
    setExplanationTextStyle('notification explanation-text-correct');
    return true;
  }, [allMileagesComplyWithRules, includeBillable, mileage, range.end, range.start, selectedUser]);

  useEffect(() => {
    if (!range.start || !range.end) {
      return;
    }
    updateMileages(range.start, range.end);
  }, [timeChimpService, range.end, range.start, selectedUser, updateMileages, mileagesToCreate]);

  useEffect(() => {
    if (users.length === 0 || infiCustomers) {
      return;
    }
    timeChimpService.getInfiCustomers().then((customers) => {
      setInfiCustomers(customers);
      const infiCustomer =
        customers.find((c) => c.city === 'Nijmegen' && selectedUser?.tagNames.includes('Nijmegen')) || customers[0];
      setInfiCustomerSelected(infiCustomer);
    });
  }, [users.length, selectedUser, timeChimpService, infiCustomers]);

  useEffect(() => {
    timeChimpService.getCustomers(true).then((customers) => {
      const customersWithoutInfi = customers.filter((c) => c.id !== infiCustomerSelected?.id);
      setCustomers(customersWithoutInfi);
      if (customersWithoutInfi) {
        setCustomerSelected(customersWithoutInfi[0]);
      }
    });
  }, [infiCustomerSelected, timeChimpService]);

  useEffect(() => {
    if (customerSelected) {
      timeChimpService.getProjectsForCustomer(customerSelected.id).then(setProjects);
    }
  }, [customerSelected, timeChimpService]);

  useEffect(() => {
    const projectSelected = projects.length ? projects[0] : undefined;
    setProjectSelected(projectSelected);
  }, [projects]);

  useEffect(() => {
    setMileagePreviewed(false);
  }, [homeAddress, projectSelected, createReturn, dateSelected]);

  useEffect(() => {
    setReviewButtonEnabled(shouldEnableReviewButton());
  }, [shouldEnableReviewButton]);

  useEffect(() => {
    if (reviewButtonEnabled && mileageReviewed) {
      setExplanationText('Even better: You can submit your mileages!');
      setExplanationTextStyle('notification explanation-text-correct');
      setSubmitButtonEnabled(true);
    } else {
      setSubmitButtonEnabled(false);
    }
  }, [reviewButtonEnabled, mileageReviewed]);

  async function getMileageReport(isReview: boolean) {
    if (!users || !range.start || !range.end) {
      return;
    }
    const report = await reportService.getMileageReport(range.start, range.end, isReview, selectedUser);
    const filename = `${isReview ?? 'REVIEW-'}REIS ${selectedUser?.displayName} ${range.start} - ${range.end}`;
    downloadService.download(report, filename);
  }

  async function changeSubmittedMileages() {
    if (!users || !range.start || !range.end) {
      return;
    }
    const mileageIds = mileage.filter((m) => m.mileage.status !== 3).map((m) => m.mileage.id);
    const toBeUpdatedMileages: UpdateMileageStatus = {
      registrationIds: mileageIds,
      status: 3,
    };
    await mileageService.updateMileageStatuses(toBeUpdatedMileages);
    await updateMileages(range.start, range.end);
  }

  function generateMileages(preview: boolean) {
    if (!selectedUser || !customerSelected || !projectSelected || !infiCustomerSelected) {
      throw new Error('Not all preconditions met, cancelling');
    }
    const mileage = {
      userId: selectedUser?.id,
      customerId: customerSelected.id.toString(),
      projectId: projectSelected.id.toString(),
      homeAddress: homeAddress ?? undefined,
      fromAddress: infiCustomerSelected.address,
      toAddress: customerSelected.address,
      commute: !!homeAddress,
      date: dateSelected,
      billable: true,
      distance: 0,
      status: MileageStatus.open,
      type: MileageType.Business,
      id: 0,
      customerName: '',
      projectName: '',
      notes: notes,
    };

    console.log(`${preview ? 'Previewing' : 'Creating'} mileages on basis of ${JSON.stringify(mileage)}`);
    mileageService
      .createMilages(mileage, preview, createReturn, mileage.commute, mileage.homeAddress)
      .then((mileages) => {
        setMileagesToCreate(mileages);
      })
      .catch((e) => {
        setMileagePreviewed(false);
        setMileageCreationError(e);
      });
    if (!preview) {
      setAddMileagePrompt(false);
    }
    setMileagePreviewed(!mileagePreviewed);
  }

  function ReviewAndSubmitElement() {
    return (
      <div className="buttons is-right ">
        <div className={explanationTextStyle}> {explanationText} </div>
        <button
          className="button preview-button mx-1"
          disabled={!reviewButtonEnabled}
          onClick={() => {
            getMileageReport(true);
            setMileageReviewed(true);
          }}
        >
          Review
        </button>
        <button
          className="button submit-button mx-1"
          disabled={!submitButtonEnabled}
          onClick={() => {
            getMileageReport(false);
            changeSubmittedMileages();
          }}
        >
          Submit
        </button>
        <button
          className="button submit-button mx-1"
          onClick={() => {
            setAddMileagePrompt(true);
          }}
        >
          Add
        </button>
      </div>
    );
  }

  return (
    <>
      <div className="columns">
        <div className="column">
          <h1>Mileage</h1>
        </div>
      </div>
      <div className="columns">
        <div className="column">
          <PeopleSelector selectedUser={selectedUser} setSelectedUser={setSelectedUser} />
        </div>
        <DateRangeSelector range={range} onRangeChange={setRange} />
        <div className="column">
          <div className="field">
            <label className="label">Include billable </label>
            <input
              id="includeBillable"
              className="switch"
              type="checkbox"
              checked={includeBillable}
              onChange={(e) => setIncludeBillable(e.target.checked)}
            />
            <label htmlFor="includeBillable" />
          </div>
        </div>
      </div>
      <ReviewAndSubmitElement />
      {mileage.map((m) => (
        <MileageCard key={m.mileage.id} mileage={m.mileage} customers={customers} needsCheck={m.needsCheck} />
      ))}
      <ReviewAndSubmitElement />

      {addMileagePrompt && (
        <Modal onClose={() => setAddMileagePrompt(false)}>
          <div className="card">
            <div className="card-header">
              <h2 className="card-header-title">Add mileage</h2>
            </div>
            <div className="card-content">
              {showInstruction && (
                <div className={classNames('notification', 'is-info')}>
                  <button className="delete" onClick={() => setShowInstruction(false)} />
                  Make sure to provide an Infi and a customer address and a project. Provide a home address when you
                  want to create commute mileages. Check return when you would like to register return trips. Check the
                  preview and add when ok.
                </div>
              )}
              {mileageCreationError && (
                <div className={classNames('notification', 'is-danger')}>
                  <button className="delete" onClick={() => setMileageCreationError(undefined)} />
                  Bad request, probably the home address could not be resolved to an actual address.
                </div>
              )}
              <DateSelector startDate={dateSelected} setDateSelected={setDateSelected} />
              <HomeAddress setHomeAddress={setHomeAddress} />
              <CustomerSelector
                label={'Infi Address'}
                customers={infiCustomers ?? []}
                customerSelected={infiCustomerSelected}
                setCustomerSelected={setInfiCustomerSelected}
              />
              <CustomerSelector
                label={'Customer'}
                customers={customers}
                customerSelected={customerSelected}
                setCustomerSelected={setCustomerSelected}
              />
              <ProjectSelector projects={projects} setProjectSelected={setProjectSelected} />
              <div className="field">
                <label className="label">Notes</label>
                <textarea
                  id="notes"
                  className="textarea"
                  placeholder="Omschrijving?"
                  onChange={(e) => setNotes(e.target.value)}
                />
                <label htmlFor="notes" />
              </div>
              <div className="field">
                <label className="label">Return</label>
                <input
                  id="return"
                  className="switch"
                  type="checkbox"
                  defaultChecked={createReturn}
                  onChange={(e) => setCreateReturn(e.target.checked)}
                />
                <label htmlFor="return" />
              </div>
              {mileagePreviewed && <label className="label">Preview</label>}
              {mileagePreviewed && (
                <ol type="1">
                  {mileagesToCreate.map((mileage, index) => (
                    <li key={index}>
                      {mileage.fromAddress} - {mileage.toAddress} - {mileage.distance} km
                    </li>
                  ))}
                </ol>
              )}
              <button className="button" onClick={() => generateMileages(true)} disabled={mileagePreviewed}>
                Preview
              </button>

              <button className="button" onClick={() => generateMileages(false)} disabled={!mileagePreviewed}>
                Add
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
};
