import { Expose } from 'class-transformer';

export interface UpdateExpenseStatus {
  registrationIds: number[];
  status: number;
}

export class ExpenseDto {
  @Expose()
  public id: number;

  @Expose()
  public userId: number;

  @Expose()
  public userDisplayName: string;

  @Expose()
  public customerName: string;

  @Expose()
  public projectName: string;

  @Expose()
  public categoryName: string;

  @Expose()
  public date: string;

  @Expose()
  public notes: string;

  @Expose()
  public billable: boolean;

  @Expose()
  public rate: number;

  @Expose()
  public tax: number;

  @Expose()
  public status: number;

  @Expose()
  public attachment: string;
}
