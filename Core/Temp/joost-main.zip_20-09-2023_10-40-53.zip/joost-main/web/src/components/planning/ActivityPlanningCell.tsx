import { Planning } from '../../services/PlanningService';
import { User } from '../../services/TimeChimpService';

interface Props {
  planning: Planning[];
  users: User[];
  weekday: number;
  activity: string;
}

export const ActivityPlanningCell = ({ planning, users, weekday, activity }: Props) => (
  <td>
    {planning
      .filter((planning) => planning.weekday === weekday && planning.dayParts.includes(activity))
      .map((planning) => {
        const user = users.find((user) => planning.email === user.userName) ?? {
          displayName: planning.email,
        };
        return (
          <>
            <div className="activity-planning-name-mobile" key={user.displayName + 'm'}>
              {user.displayName.includes(' ')
                ? user.displayName.split(' ')[0] + '...'
                : user.displayName.slice(0, 6) + '...'}
            </div>
            <div className="activity-planning-name-above-mobile" key={user.displayName}>
              {user.displayName}
            </div>
          </>
        );
      })}
  </td>
);
