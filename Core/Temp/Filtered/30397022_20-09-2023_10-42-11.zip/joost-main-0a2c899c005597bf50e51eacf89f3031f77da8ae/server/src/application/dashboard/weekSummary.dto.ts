export interface WeekSummaryDto {
  billablePercent: number;
  marginPercent: number;
  profitProgress: number;
  projectHours: Record<string, number>;
}
