import { Project } from '../services/TimeChimpService';

export interface Props {
  projects: Project[];
  setProjectSelected: (project: Project) => void;
}

export const ProjectSelector = ({ projects, setProjectSelected }: Props) => {
  if (projects.length === 0) {
    return null;
  }
  return (
    <div className="field">
      <label className="label">Project</label>
      <div className="select">
        <select
          className="select"
          onChange={(e) => {
            if (!projects) {
              return;
            }
            projects.filter((p) => p.id === parseInt(e.target.value)).map((p) => setProjectSelected(p));
          }}
        >
          {projects.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
