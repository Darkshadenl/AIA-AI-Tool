import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Authenticated } from '~/auth/authenticated.decorator';
import { ClimateDto, HomeassistantAdapter, PlantDto, WeatherDto } from '~/infrastructure/homeassistant';

@Authenticated()
@Controller('/api/office')
@ApiTags('Office')
export class OfficeController {
  public constructor(private readonly homeassistantAdapter: HomeassistantAdapter) {}

  @Get('plants')
  getPlants(): PlantDto[] {
    return this.homeassistantAdapter.plants;
  }

  @Get('climate')
  getClimate(): ClimateDto[] {
    return this.homeassistantAdapter.climate;
  }

  @Get('weather')
  getWeather(): WeatherDto[] {
    return this.homeassistantAdapter.weather;
  }
}
