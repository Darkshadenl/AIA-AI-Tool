import { Expose } from 'class-transformer';

export interface CreateTime {
  projectId: number;
  projectTaskId: number;
  userId: number;
  notes: string;
  date: string;
  hours: number;
  start: string;
  end: string;
}

export class TimeDto {
  @Expose()
  public id: number;

  @Expose()
  public customerId: number;

  @Expose()
  public customerName: string;

  @Expose()
  public projectId: number;

  @Expose()
  public projectName: string;

  @Expose()
  public projectTaskId: number;

  @Expose()
  public taskId: number;

  @Expose()
  public taskName: string;

  @Expose()
  public userId: number;

  @Expose()
  public userDisplayName: string;

  // "userTags": [],

  @Expose()
  public date: string;

  @Expose()
  public hours: number;

  @Expose()
  public notes: string;

  @Expose()
  public startEnd: string;

  @Expose()
  public start: string;

  @Expose()
  public end: string;

  // "pause": 0,
  // "externalName": "string",
  // "externalUrl": "string",
  // "status": 0,
  // "statusIntern": 0,
  // "statusExtern": 0,
  // "tags": [],

  @Expose()
  public modified: string;

  // "submitForApprovals": []
}
