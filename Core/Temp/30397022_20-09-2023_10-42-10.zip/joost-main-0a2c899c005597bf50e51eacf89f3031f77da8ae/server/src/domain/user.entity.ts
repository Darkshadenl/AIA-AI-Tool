export class User {
  public email: string;
  public name: string;
  public timeChimp?: unknown;
  public buzzy?: unknown;
  public outlook?: unknown;
}
