import { Injectable, Logger } from '@nestjs/common';
import { GoogleDistanceConfig } from '~/configuration';
import { ConfigService } from '@nestjs/config';
import { HttpService } from '@nestjs/axios';
import { ClassConstructor, plainToInstance } from 'class-transformer';
import { firstValueFrom } from 'rxjs';
import { GoogleDistanceDto, NOT_FOUND } from '~/infrastructure/timechimp/distance';
import { ValidationException } from '~/error/validation.exception';

@Injectable()
export class DistanceService {
  private readonly METERS_IN_KM = 1000;

  private readonly googleDistanceConfig: GoogleDistanceConfig;

  private readonly logger: Logger = new Logger(DistanceService.name);

  public constructor(config: ConfigService, private readonly httpClient: HttpService) {
    this.googleDistanceConfig = config.get('googleDistance');
  }

  /**
   * Get distance in km on basis of the from address and to address provided.
   * @param fromAddress The from address.
   * @param toAddress The to address.
   * @throws ValidationException whenever either the from address or the to address can not be found, most likely because it's incorrect.
   */
  public async getDistanceInKm(fromAddress: string, toAddress: string): Promise<number> {
    const distance = await this.getDistance(GoogleDistanceDto, fromAddress, toAddress);
    const element = distance.rows.flatMap((r) => r.elements).find((e) => e.status !== NOT_FOUND, {});
    if (!element) {
      throw new ValidationException(`Unable to find distance for mileage from ${fromAddress} to ${toAddress}`);
    }
    return this.toKm(element.distance.value);
  }

  private async getDistance<DistanceDto>(
    cls: ClassConstructor<DistanceDto>,
    origins: string,
    destinations: string
  ): Promise<DistanceDto> {
    let url =
      `${this.googleDistanceConfig.url}?destinations=${encodeURIComponent(destinations)}&origins=` +
      `${encodeURIComponent(origins)}&units=metric&key=`;
    this.logger.log(`GET: ${url}{secret}`);
    url += this.googleDistanceConfig.secret; // Add secret afterwards so it's not logged
    const response = await firstValueFrom(this.httpClient.get(url));
    this.logger.debug(response.data);
    return plainToInstance(cls, response.data, {
      excludeExtraneousValues: true,
    });
  }

  private toKm(distanceInMeters: string) {
    const distanceKm = Number(distanceInMeters) / this.METERS_IN_KM;
    return Number(distanceKm.toFixed(2));
  }
}
