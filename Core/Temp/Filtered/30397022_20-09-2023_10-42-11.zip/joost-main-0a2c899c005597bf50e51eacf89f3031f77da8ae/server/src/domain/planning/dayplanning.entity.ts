import { Expose } from 'class-transformer';
import { DateTime } from 'luxon';
import { BuzzyPlanningDto } from '~/infrastructure/buzzy';
import { TransformDateTime } from '~/utils/transformDateTime';

export interface DayPlanning {
  date: DateTime;
  dayParts: [string, string];
  email: string;
}

export class DayPlanningEntity {
  @Expose({ name: 'dateStr' })
  @TransformDateTime()
  public date: DateTime;

  public dayParts: [string, string];

  public email: string;

  private constructor({ date, dayParts, email }: DayPlanning) {
    this.email = email;
    this.date = date;
    this.dayParts = dayParts;
  }

  public static FromBuzzy(buzzy: BuzzyPlanningDto) {
    const s = buzzy.planning.split('-');
    const dayParts: [string, string] = [s[0], s[1] ?? s[0]];
    const date = DateTime.fromFormat(buzzy.date, 'yyyy-MM-dd');
    const { email } = buzzy;
    return new DayPlanningEntity({ date, dayParts, email });
  }
}
