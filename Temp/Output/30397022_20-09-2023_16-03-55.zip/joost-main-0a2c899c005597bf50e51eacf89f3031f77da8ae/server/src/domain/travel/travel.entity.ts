import { PhysicalAddress } from '../address.valueObject';
import { DateTime } from 'luxon';

export class TripEntity {
  date: DateTime;
  start: PhysicalAddress;
  end: PhysicalAddress;
  distanceInKm: number;
  isRoundTrip: boolean;
}

export class TravelAggregate {
  date: DateTime;
  actual: TripEntity[];
  virtual?: TripEntity[];
  customerId?: string;
  customerName?: string;
  projectId?: string;
  projectName?: string;
}
