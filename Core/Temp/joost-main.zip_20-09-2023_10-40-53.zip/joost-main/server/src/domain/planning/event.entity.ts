import { DateTimeTimeZone, Event as OutlookEvent } from '@microsoft/microsoft-graph-types';
import { Expose } from 'class-transformer';
import { DateTime } from 'luxon';
import { TransformDateTime } from '~/utils/transformDateTime';
import { PhysicalAddress } from '../address.valueObject';

export type FreeBusy = 'unknown' | 'free' | 'tentative' | 'busy' | 'oof' | 'workingElsewhere';

export interface Event {
  iCalUId: string;
  subject: string;
  startDateTime: DateTime;
  endDateTime: DateTime;
  body: string;
  freeBusy: FreeBusy;
  webLink: string;
  locationAddress: PhysicalAddress;
  locationName: string;
  organizerName: string;
  organizerEmail: string;
  isOof: boolean;
  duration: number;
}

export class EventEntity implements Event {
  public readonly iCalUId: string;

  @Expose({ name: 'startDateTimeStr' })
  @TransformDateTime()
  public readonly startDateTime: DateTime;

  @Expose({ name: 'endDateTimeStr' })
  @TransformDateTime()
  public readonly endDateTime: DateTime;

  public readonly subject: string;

  public readonly body: string;

  public readonly freeBusy: FreeBusy;

  public readonly webLink: string;

  public readonly locationAddress: PhysicalAddress;

  public readonly locationName: string;

  public readonly organizerName: string;

  public readonly organizerEmail: string;

  public readonly isOof: boolean;

  public readonly duration: number;

  private constructor({
    iCalUId,
    startDateTime,
    endDateTime,
    subject,
    body,
    freeBusy,
    webLink,
    locationAddress,
    locationName,
    organizerName,
    organizerEmail,
    isOof,
    duration,
  }: Event) {
    this.iCalUId = iCalUId;
    this.startDateTime = startDateTime;
    this.endDateTime = endDateTime;
    this.subject = subject;
    this.body = body;
    this.freeBusy = freeBusy;
    this.webLink = webLink;
    this.locationAddress = locationAddress;
    this.locationName = locationName;
    this.organizerEmail = organizerEmail;
    this.organizerName = organizerName;
    this.isOof = isOof;
    this.duration = duration;
  }

  private static OutlookDateToDateTime(date: DateTimeTimeZone) {
    return DateTime.fromISO(date.dateTime, { zone: date.timeZone });
  }

  public static FromOutlookEvent(outlook: OutlookEvent): Event {
    const { iCalUId, subject, start, end, body, showAs, webLink, location, organizer } = outlook;
    const isOof = showAs === 'oof';
    const startDateTime = EventEntity.OutlookDateToDateTime(start);
    const endDateTime = EventEntity.OutlookDateToDateTime(end);
    const duration = startDateTime && endDateTime ? endDateTime.diff(startDateTime, ['hours']).hours : 0;

    return new EventEntity({
      iCalUId,
      subject,
      startDateTime,
      endDateTime,
      body: body?.content || '',
      freeBusy: showAs,
      webLink,
      locationAddress: location.address || {},
      locationName: location.displayName ?? '',
      organizerName: organizer?.emailAddress?.name ?? '',
      organizerEmail: organizer?.emailAddress?.address ?? '',
      isOof: isOof,
      duration,
    });
  }
}
