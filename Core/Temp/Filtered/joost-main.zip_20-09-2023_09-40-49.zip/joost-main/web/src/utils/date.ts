export function formatDateLong(date: Date | string): string {
  return Intl.DateTimeFormat('en-GB', {
    dateStyle: 'full',
  }).format(new Date(date));
}

export function formatDateDayMonth(date: Date | string): string {
  return Intl.DateTimeFormat('nl-NL', {
    day: 'numeric',
    month: 'long',
  }).format(new Date(date));
}

export function getDayName(date: string): string {
  const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
  return dayOfWeek.toLowerCase();
}
