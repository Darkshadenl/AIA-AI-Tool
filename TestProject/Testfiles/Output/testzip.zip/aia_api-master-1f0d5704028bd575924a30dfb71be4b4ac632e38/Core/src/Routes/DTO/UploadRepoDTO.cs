namespace aia_api.Routes.DTO;

public class UploadRepoDTO
{
    public string projectId { get; set; }
    public string apiToken { get; set; }
}
