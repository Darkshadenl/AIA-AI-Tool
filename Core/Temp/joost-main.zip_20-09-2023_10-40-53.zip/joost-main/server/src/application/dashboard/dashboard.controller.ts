import { Controller, Get, UseGuards } from '@nestjs/common';
import { DateTime } from 'luxon';
import { StaticAuthentication } from '~/auth/psk.guard';
import { TimeChimpAdapter } from '~/infrastructure/timechimp/timechimp.adapter';
import { FinanceService } from '../finance/finance.service';
import { WeekSummaryDto } from './weekSummary.dto';

@UseGuards(StaticAuthentication)
@Controller('api/dashboards')
export class DashboardController {
  constructor(private readonly timechimp: TimeChimpAdapter, private readonly finance: FinanceService) {}

  @Get('week')
  public async getWeekSummary(): Promise<WeekSummaryDto> {
    const startOfThisWeek = DateTime.now().set({
      weekday: 1,
    });
    const endOfThisWeek = DateTime.now().set({
      weekday: 7,
    });
    const timesThisWeek = await this.timechimp.getTimes({
      startDate: startOfThisWeek,
      endDate: endOfThisWeek,
    });

    const projectHours: Record<string, number> = {};

    let billableHours = 0;
    let nonBillableHours = 0;
    timesThisWeek.forEach((item) => {
      if (item.taskName === 'Intern' || item.projectName === 'Intern') {
        nonBillableHours += item.hours;
      } else {
        billableHours += item.hours;
      }

      projectHours[item.projectName] = (projectHours[item.projectName] || 0) + item.hours;
    });

    const results = await this.finance.getResults(DateTime.now(), 'week');

    return {
      billablePercent: (100 * billableHours) / (billableHours + nonBillableHours),
      projectHours,
      marginPercent: results.internal.marginPercentage,
      profitProgress: (100 * results.internal.revenue) / results.internal.costs,
    };
  }
}
