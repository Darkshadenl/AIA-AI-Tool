import { Injectable, Logger } from '@nestjs/common';
import { exec } from 'child_process';

@Injectable()
export class PdfService {
  private readonly logger = new Logger(PdfService.name);

  public htmlToPdf(htmlFileName: string, pdfFileName: string) {
    return this.execCmdline(`wkhtmltopdf --orientation landscape --page-size A4 "${htmlFileName}" "${pdfFileName}"`);
  }

  public imageToPdf(imageFileName: string, pdfFileName: string) {
    return this.execCmdline(`convert -quality 75 -background white -page a4 "${imageFileName}" "${pdfFileName}"`);
  }

  public concatPdf(fileNames: string[], target: string) {
    return this.execCmdline(`pdftk ${fileNames.map((name) => `"${name}"`).join(' ')} cat output "${target}"`);
  }

  private execCmdline(cmdline: string) {
    this.logger.debug(cmdline);
    return new Promise<void>((resolve, reject) => {
      exec(cmdline, {}, (error, stdout, stderr) => {
        if (!error) {
          resolve();
          return;
        }
        if (stdout) {
          this.logger.log(stdout);
        }
        if (stderr) {
          this.logger.error(stderr);
        }
        reject(error);
      });
    });
  }
}
